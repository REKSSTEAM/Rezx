import 'dart:async';

import '../../models/addon/addon.dart';
import '../../models/movie/movie_section.dart';
import '../metadata/metadata_service.dart';

/// Extra, ordered rows for the Home page (top rated + genre rows).
///
/// Uses the Cinemeta catalogs (IMDb ids), so cards, details and "See all"
/// work exactly like the rows coming from the installed addons.
abstract final class ExtraHomeSections {
  static const String _base = 'https://v3-cinemeta.strem.io';

  static const List<String> _genres = [
    'Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime',
    'Documentary', 'Drama', 'Family', 'Fantasy', 'History', 'Horror',
    'Mystery', 'Romance', 'Sci-Fi', 'Sport', 'Thriller', 'War', 'Western',
  ];

  // title, subtitle, type, catalog id, genre (optional) — in display order.
  static const List<(String, String, String, String, String?)> _defs = [
    ('Top Rated Movies', 'Highest IMDb rating', 'movie', 'imdbRating', null),
    ('Top Rated Series', 'Highest IMDb rating', 'series', 'imdbRating', null),
    ('Action Movies', 'Action', 'movie', 'top', 'Action'),
    ('Comedy Movies', 'Comedy', 'movie', 'top', 'Comedy'),
    ('Sci-Fi Movies', 'Sci-Fi', 'movie', 'top', 'Sci-Fi'),
    ('Horror Movies', 'Horror', 'movie', 'top', 'Horror'),
    ('Thriller Movies', 'Thriller', 'movie', 'top', 'Thriller'),
    ('Romance Movies', 'Romance', 'movie', 'top', 'Romance'),
    ('Animation Movies', 'Animation', 'movie', 'top', 'Animation'),
    ('Drama Series', 'Drama', 'series', 'top', 'Drama'),
    ('Crime Series', 'Crime', 'series', 'top', 'Crime'),
    ('Animation Series', 'Animation & Anime-style', 'series', 'top', 'Animation'),
    ('Documentaries', 'Documentary', 'movie', 'top', 'Documentary'),
  ];

  /// Streams the rows in order as they load. Failed/empty rows are skipped.
  static Stream<MovieSection> stream() async* {
    final futures = <Future<MovieSection?>>[
      for (final d in _defs) _load(d.$1, d.$2, d.$3, d.$4, d.$5),
    ];
    for (final f in futures) {
      final section = await f;
      if (section != null) yield section;
    }
  }

  static Future<MovieSection?> _load(
    String title,
    String subtitle,
    String type,
    String catalogId,
    String? genre,
  ) async {
    try {
      final movies = await MetadataService.fetchCatalog(
        baseUrl: _base,
        type: type,
        catalogId: catalogId,
        genre: genre,
      );
      if (movies.isEmpty) return null;
      return MovieSection(
        title: title,
        subtitle: subtitle,
        contentType: type,
        addonBaseUrl: _base,
        catalog: AddonCatalog(
          type: type,
          id: catalogId,
          name: title,
          genres: _genres,
          supportsSearch: false,
          supportsSkip: true,
        ),
        movies: movies.take(30).toList(),
        initialExtras: genre == null ? const {} : {'genre': genre},
      );
    } catch (_) {
      return null;
    }
  }
}
