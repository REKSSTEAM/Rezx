import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:vector_math/vector_math_64.dart' show Matrix4;

import '../../services/player/web_video_style.dart';

/// Applies the Video-panel settings to whatever is drawn *behind* it (the
/// video): colour changes through a backdrop colour filter, and VR mode
/// through a zoom + gyroscope pan. Put it right above the video and below the
/// controls so the buttons and subtitles are not affected.
class WebVideoEffects extends StatefulWidget {
  const WebVideoEffects({super.key});

  @override
  State<WebVideoEffects> createState() => _WebVideoEffectsState();
}

class _WebVideoEffectsState extends State<WebVideoEffects> {
  StreamSubscription<GyroscopeEvent>? _gyro;
  double _yaw = 0; // pixels
  double _pitch = 0; // pixels
  DateTime? _last;

  static const double _zoom = 2.2;

  late final Listenable _all = Listenable.merge([
    WebVideoStyle.brightness,
    WebVideoStyle.contrast,
    WebVideoStyle.saturation,
    WebVideoStyle.vrMode,
  ]);

  @override
  void initState() {
    super.initState();
    WebVideoStyle.vrMode.addListener(_vrChanged);
    _vrChanged();
  }

  @override
  void dispose() {
    WebVideoStyle.vrMode.removeListener(_vrChanged);
    _gyro?.cancel();
    super.dispose();
  }

  void _vrChanged() {
    if (WebVideoStyle.vrMode.value) {
      _gyro ??= gyroscopeEventStream().listen((e) {
        final now = DateTime.now();
        final dt = _last == null
            ? 0.0
            : now.difference(_last!).inMicroseconds / 1e6;
        _last = now;
        if (dt <= 0 || dt > 0.2 || !mounted) return;
        // rad/s → pixels (roughly 1 rad ≈ 420 px)
        const px = 420.0;
        setState(() {
          _yaw -= e.y * dt * px;
          _pitch -= e.x * dt * px;
        });
      }, onError: (_) {});
    } else {
      _gyro?.cancel();
      _gyro = null;
      _last = null;
      _yaw = 0;
      _pitch = 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _all,
        builder: (context, _) {
          final vr = WebVideoStyle.vrMode.value;
          final color = WebVideoStyle.hasColorChange;
          if (!vr && !color) return const SizedBox.expand();

          return LayoutBuilder(
            builder: (context, box) {
              Widget layer = const SizedBox.expand();
              if (color) {
                layer = BackdropFilter(
                  filter: ui.ColorFilter.matrix(WebVideoStyle.colorMatrix()),
                  child: layer,
                );
              }
              if (vr) {
                final w = box.maxWidth, h = box.maxHeight;
                final maxX = w * (_zoom - 1) / 2;
                final maxY = h * (_zoom - 1) / 2;
                _yaw = _yaw.clamp(-maxX, maxX);
                _pitch = _pitch.clamp(-maxY, maxY);
                final m = Matrix4.identity()
                  ..translate(w / 2 + _yaw, h / 2 + _pitch)
                  ..scale(_zoom)
                  ..translate(-w / 2, -h / 2);
                layer = BackdropFilter(
                  filter: ui.ImageFilter.matrix(
                    Float64List.fromList(m.storage),
                  ),
                  child: layer,
                );
              }
              return layer;
            },
          );
        },
      ),
    );
  }
}
