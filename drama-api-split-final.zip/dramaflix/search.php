<?php
require __DIR__.'/common.php';
try { $q=trim((string)($_GET['q']??'')); if($q==='') out(array_merge(commonOptions('search.php'),['items'=>[],'total'=>0])); [$html,$status,$type]=vdRequest(VD_BASE.'/ar/browse?q='.rawurlencode($q),'text/html,application/xhtml+xml'); $items=parseCards($html,'reelshort'); out(array_merge(commonOptions('search.php'),['query'=>$q,'items'=>$items,'total'=>count($items),'upstream_http'=>$status,'content_type'=>$type])); } catch(Throwable $e) { fail('search.php',$e); }
