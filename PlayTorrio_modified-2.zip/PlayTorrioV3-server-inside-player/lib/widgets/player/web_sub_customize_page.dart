import 'package:flutter/material.dart';

import '../../services/player/web_sub_style.dart';
import 'web_player_panels.dart';

/// "Customize Subtitles" page: Quick Styles, Quick Adjustments and the
/// collapsible Advanced Settings, all bound to [WebSubStyle].
class WebSubCustomizePage extends StatefulWidget {
  final double delay;
  final ValueChanged<double> onDelay;
  final VoidCallback onBack;

  const WebSubCustomizePage({
    super.key,
    required this.delay,
    required this.onDelay,
    required this.onBack,
  });

  @override
  State<WebSubCustomizePage> createState() => _WebSubCustomizePageState();
}

class _WebSubCustomizePageState extends State<WebSubCustomizePage> {
  static const Color _tile = Color(0xFF141414);
  static const Color _tileOn = Color(0xFF2E2E30);
  static const Color _accent = Color(0xFF80CBC4);

  String _preset = 'Default';
  bool _advanced = true;
  late double _delay;

  static const List<int> _textColors = [
    0xFFFFFFFF,
    0xFF7C8CDE,
    0xFFE8D44D,
    0xFF4CAF50,
  ];
  static const List<int> _bgColors = [0xFF000000, 0xFF1A1A1A, 0xFF2E2E2E];

  @override
  void initState() {
    super.initState();
    _delay = widget.delay;
    WebSubStyle.load();
  }

  void _setDelay(double v) {
    final b = v < -10.0 ? -10.0 : (v > 10.0 ? 10.0 : v);
    final c = (b * 10).round() / 10.0;
    setState(() => _delay = c);
    widget.onDelay(c);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(title: 'Customize Subtitles', onBack: widget.onBack),
        Expanded(
          child: ValueListenableBuilder<int>(
            valueListenable: WebSubStyle.changed,
            builder: (context, _, __) => ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              children: [
                _title('Quick Styles'),
                _quickStyles(),
                const SizedBox(height: 18),
                _title('Quick Adjustments'),
                _label('Text Size'),
                _textSizeButtons(),
                const SizedBox(height: 12),
                _label('Position'),
                _positionButtons(),
                const SizedBox(height: 12),
                _label('Background'),
                _backgroundButtons(),
                const SizedBox(height: 14),
                _advancedHeader(),
                if (_advanced) ..._advancedBody(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── small pieces ───────────────────────────────────────────────────────
  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 10),
        child: Text(t,
            style: const TextStyle(
                color: WebPlayerColors.white92,
                fontSize: 19,
                fontWeight: FontWeight.w400)),
      );

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(t,
            style: const TextStyle(
                color: WebPlayerColors.white92,
                fontSize: 15,
                fontWeight: FontWeight.w500)),
      );

  Widget _choice(String text, bool on, VoidCallback tap,
      {double size = 15, double height = 46}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Material(
          color: on ? _tileOn : _tile,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: tap,
            child: SizedBox(
              height: height,
              child: Center(
                child: Text(text,
                    style: TextStyle(
                        color: on ? Colors.white : WebPlayerColors.white60,
                        fontSize: size,
                        fontWeight: on ? FontWeight.w700 : FontWeight.w500)),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Quick styles ───────────────────────────────────────────────────────
  Widget _quickStyles() {
    Widget tile(String name) {
      final on = _preset == name;
      TextStyle st;
      Color? bg;
      BoxBorder? border;
      switch (name) {
        case 'Clean':
          st = const TextStyle(color: Colors.white, fontSize: 14);
          bg = null;
          break;
        case 'High Contrast':
          st = const TextStyle(
              color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700);
          bg = Colors.black;
          border = Border.all(color: Colors.white, width: 1.5);
          break;
        case 'Cinema':
          st = const TextStyle(
              color: Color(0xFFFFEB3B), fontSize: 14, fontFamily: 'serif');
          bg = Colors.black;
          break;
        default:
          st = const TextStyle(color: Colors.white, fontSize: 14);
          bg = const Color(0xFF0C0C0C);
      }
      return Expanded(
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: Material(
            color: on ? _tileOn : _tile,
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                setState(() => _preset = name);
                WebSubStyle.applyPreset(name);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: bg,
                        borderRadius: BorderRadius.circular(8),
                        border: border,
                      ),
                      child: Text('Sample Text', style: st),
                    ),
                    const SizedBox(height: 8),
                    Text(name,
                        style: const TextStyle(
                            color: WebPlayerColors.white92, fontSize: 14)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    return Column(
      children: [
        Row(children: [tile('Default'), tile('Clean')]),
        Row(children: [tile('High Contrast'), tile('Cinema')]),
      ],
    );
  }

  // ── Quick adjustments ──────────────────────────────────────────────────
  Widget _textSizeButtons() {
    const sizes = [0.8, 1.0, 1.3];
    const fonts = [13.0, 17.0, 22.0]; // visibly different "A" sizes
    final cur = WebSubStyle.textScale.value;
    return Row(
      children: [
        for (var i = 0; i < 3; i++)
          _choice('A', (cur - sizes[i]).abs() < 0.06,
              () => WebSubStyle.setTextScale(sizes[i]),
              size: fonts[i]),
      ],
    );
  }

  Widget _positionButtons() {
    final p = WebSubStyle.position.value;
    return Row(
      children: [
        _choice('Bottom', p == 'bottom' || p == 'very_bottom',
            () => WebSubStyle.setPosition('bottom')),
        _choice('Middle', p == 'mid', () => WebSubStyle.setPosition('mid')),
      ],
    );
  }

  Widget _backgroundButtons() {
    final o = WebSubStyle.bgOpacity.value;
    final none = o < 0.05;
    final light = !none && o < 0.65;
    final dark = !none && !light;
    return Row(
      children: [
        _choice('None', none, () => WebSubStyle.setBgOpacity(0.0)),
        _choice('Light', light, () {
          WebSubStyle.setBgColor(0xFF000000);
          WebSubStyle.setBgOpacity(0.5);
        }),
        _choice('Dark', dark, () {
          WebSubStyle.setBgColor(0xFF000000);
          WebSubStyle.setBgOpacity(0.85);
        }),
      ],
    );
  }

  // ── Advanced ───────────────────────────────────────────────────────────
  Widget _advancedHeader() {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => setState(() => _advanced = !_advanced),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 14),
        child: Row(
          children: [
            const Expanded(
              child: Text('Advanced Settings',
                  style: TextStyle(
                      color: WebPlayerColors.white92,
                      fontSize: 18,
                      fontWeight: FontWeight.w500)),
            ),
            Icon(
              _advanced
                  ? Icons.keyboard_arrow_up_rounded
                  : Icons.keyboard_arrow_down_rounded,
              color: WebPlayerColors.white92,
            ),
          ],
        ),
      ),
    );
  }

  Widget _divider() =>
      const Divider(height: 1, thickness: 1, color: Color(0x14FFFFFF));

  Widget _switchRow(String title, bool value, ValueChanged<bool> onChanged,
      {String? subtitle}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: WebPlayerColors.white92, fontSize: 17)),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(subtitle,
                        style: const TextStyle(
                            color: WebPlayerColors.white45, fontSize: 13)),
                  ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            thumbColor: WidgetStateProperty.resolveWith(
                (s) => s.contains(WidgetState.selected)
                    ? Colors.black
                    : Colors.grey.shade400),
            trackColor: WidgetStateProperty.resolveWith(
                (s) => s.contains(WidgetState.selected)
                    ? Colors.white
                    : const Color(0xFF2A2A2A)),
            trackOutlineColor:
                WidgetStateProperty.all(Colors.transparent),
          ),
        ],
      ),
    );
  }

  Widget _sliderRow(String title, double value, double min, double max,
      ValueChanged<double> onChanged,
      {bool enabled = true}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 14, 6, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: TextStyle(
                  color: enabled
                      ? WebPlayerColors.white92
                      : WebPlayerColors.white45,
                  fontSize: 17)),
          Row(
            children: [
              Expanded(
                child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: Colors.white,
                    inactiveTrackColor: const Color(0x33FFFFFF),
                    thumbColor: Colors.white,
                    overlayColor: const Color(0x22FFFFFF),
                    trackHeight: 4,
                  ),
                  child: Slider(
                    value: value.clamp(min, max),
                    min: min,
                    max: max,
                    onChanged: enabled ? onChanged : null,
                  ),
                ),
              ),
              SizedBox(
                width: 56,
                child: Text('${(value * 100).round()}%',
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                        color: WebPlayerColors.white60, fontSize: 16)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _dropdownRow(String title, String valueKey, Map<String, String> items,
      ValueChanged<String> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(title,
                style: const TextStyle(
                    color: WebPlayerColors.white92, fontSize: 17)),
          ),
          PopupMenuButton<String>(
            color: const Color(0xFF3A3A3C),
            onSelected: onChanged,
            itemBuilder: (_) => [
              for (final e in items.entries)
                PopupMenuItem<String>(
                  value: e.key,
                  child: SizedBox(
                    width: 190,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(e.value,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 17)),
                        ),
                        Icon(
                          e.key == valueKey
                              ? Icons.radio_button_checked
                              : Icons.radio_button_unchecked,
                          color: e.key == valueKey ? _accent : Colors.white70,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: _tile,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(items[valueKey] ?? valueKey,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(width: 18),
                  const Icon(Icons.keyboard_arrow_down_rounded,
                      color: Colors.white, size: 22),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _swatch({
    required bool selected,
    required VoidCallback onTap,
    Color? color,
    Widget? child,
    bool checker = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: selected
                ? Border.all(color: Colors.white, width: 2)
                : Border.all(color: const Color(0x33FFFFFF), width: 1),
          ),
          child: ClipOval(
            child: Stack(
              alignment: Alignment.center,
              children: [
                if (checker) const Positioned.fill(child: _Checker()),
                if (child != null) child,
                if (selected && child == null)
                  Icon(Icons.check_rounded,
                      size: 20,
                      color: (color != null && color.computeLuminance() > 0.5)
                          ? Colors.black
                          : Colors.white),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _colorRow() {
    final cur = WebSubStyle.color.value;
    final custom = !_textColors.contains(cur);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
      child: Row(
        children: [
          const Expanded(
            child: Text('Color',
                style:
                    TextStyle(color: WebPlayerColors.white92, fontSize: 17)),
          ),
          for (final c in _textColors)
            _swatch(
              selected: cur == c,
              color: Color(c),
              onTap: () => WebSubStyle.setColor(c),
            ),
          _swatch(
            selected: custom,
            color: custom ? Color(cur) : const Color(0xFF2C2C2E),
            child: custom
                ? null
                : const Icon(Icons.brush_rounded,
                    size: 20, color: Colors.white54),
            onTap: () => _pickCustomColor(cur, (v) => WebSubStyle.setColor(v)),
          ),
        ],
      ),
    );
  }

  Widget _bgColorRow() {
    final cur = WebSubStyle.bgColor.value;
    final transparent = WebSubStyle.bgOpacity.value < 0.01;
    final custom = !transparent && !_bgColors.contains(cur);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
      child: Row(
        children: [
          const Expanded(
            child: Text('Background\ncolor',
                style:
                    TextStyle(color: WebPlayerColors.white92, fontSize: 17)),
          ),
          _swatch(
            selected: transparent,
            checker: true,
            onTap: () => WebSubStyle.setBgOpacity(0.0),
          ),
          for (final c in _bgColors)
            _swatch(
              selected: !transparent && cur == c,
              color: Color(c),
              onTap: () {
                WebSubStyle.setBgColor(c);
                if (WebSubStyle.bgOpacity.value < 0.01) {
                  WebSubStyle.setBgOpacity(WebSubStyle.dBgOpacity);
                }
              },
            ),
          _swatch(
            selected: custom,
            color: custom ? Color(cur) : const Color(0xFF2C2C2E),
            child: custom
                ? null
                : const Icon(Icons.brush_rounded,
                    size: 20, color: Colors.white54),
            onTap: () => _pickCustomColor(cur, (v) {
              WebSubStyle.setBgColor(v);
              if (WebSubStyle.bgOpacity.value < 0.01) {
                WebSubStyle.setBgOpacity(WebSubStyle.dBgOpacity);
              }
            }),
          ),
        ],
      ),
    );
  }

  Future<void> _pickCustomColor(int current, ValueChanged<int> apply) async {
    const palette = <int>[
      0xFFFFFFFF, 0xFFFF5252, 0xFFFF9800, 0xFFFFEB3B, 0xFF69F0AE, 0xFF00E5FF,
      0xFF448AFF, 0xFFB388FF, 0xFFFF80AB, 0xFF9E9E9E, 0xFF424242, 0xFF000000,
    ];
    final ctrl = TextEditingController(
        text: (current & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase());
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1C1C1E),
        title: const Text('Custom color',
            style: TextStyle(color: Colors.white, fontSize: 18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (final c in palette)
                  GestureDetector(
                    onTap: () {
                      apply(c);
                      Navigator.of(ctx).pop();
                    },
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: Color(c),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0x55FFFFFF)),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl,
              style: const TextStyle(color: Colors.white),
              maxLength: 6,
              decoration: const InputDecoration(
                prefixText: '#',
                labelText: 'Hex (RRGGBB)',
                counterText: '',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              final v = int.tryParse(ctrl.text.trim(), radix: 16);
              if (v != null) apply(0xFF000000 | v);
              Navigator.of(ctx).pop();
            },
            child: const Text('Apply'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }

  List<Widget> _advancedBody() {
    final sign = _delay > 0 ? '+' : '';
    return [
      _switchRow(
        'Native video subtitles',
        WebSubStyle.nativeSubs.value,
        WebSubStyle.setNative,
        subtitle: 'Broadcast subtitles for native fullscreen and PiP',
      ),
      // Subtitle delay
      Padding(
        padding: const EdgeInsets.fromLTRB(6, 18, 6, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Subtitle delay',
                style:
                    TextStyle(color: WebPlayerColors.white92, fontSize: 18)),
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: const Color(0x66FFFFFF),
                inactiveTrackColor: const Color(0x33FFFFFF),
                thumbColor: Colors.white,
                trackHeight: 4,
              ),
              child: Slider(
                min: -10,
                max: 10,
                divisions: 200,
                value: _delay,
                onChanged: _setDelay,
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: _delayBtn('Heard\naudio', Icons.chevron_left_rounded,
                      () => _setDelay(_delay - 0.1), true),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Text('$sign${_delay.toStringAsFixed(1)}s',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w700)),
                ),
                Expanded(
                  child: _delayBtn('Saw\ncaption', Icons.chevron_right_rounded,
                      () => _setDelay(_delay + 0.1), false),
                ),
              ],
            ),
          ],
        ),
      ),
      const SizedBox(height: 10),
      _divider(),
      _switchRow('Fix capitalization', WebSubStyle.fixCaps.value,
          WebSubStyle.setFixCaps),
      _divider(),
      _sliderRow('Background opacity', WebSubStyle.bgOpacity.value, 0, 1,
          WebSubStyle.setBgOpacity),
      _divider(),
      _switchRow(
        'Background blur',
        WebSubStyle.bgBlur.value,
        WebSubStyle.setBgBlur,
        subtitle: 'Disabling may fix flickering issues',
      ),
      _sliderRow('Background blur intensity', WebSubStyle.blurIntensity.value,
          0, 1, WebSubStyle.setBlurIntensity,
          enabled: WebSubStyle.bgBlur.value),
      _divider(),
      _sliderRow('Text size', WebSubStyle.textScale.value, 0.5, 2.0,
          WebSubStyle.setTextScale),
      _divider(),
      _dropdownRow('Text style', WebSubStyle.font.value,
          WebSubStyle.fontLabels, WebSubStyle.setFont),
      _divider(),
      _switchRow('Bold text', WebSubStyle.bold.value, WebSubStyle.setBold),
      _divider(),
      _colorRow(),
      _divider(),
      _bgColorRow(),
      _divider(),
      _sliderRow('Overall transparency', WebSubStyle.overall.value, 0.1, 1.0,
          WebSubStyle.setOverall),
      _divider(),
      _dropdownRow('Text shadow', WebSubStyle.shadow.value,
          WebSubStyle.shadowLabels, WebSubStyle.setShadow),
      _divider(),
      _dropdownRow('Vertical position', WebSubStyle.position.value,
          WebSubStyle.positionLabels, WebSubStyle.setPosition),
      const SizedBox(height: 16),
      Material(
        color: _tile,
        borderRadius: BorderRadius.circular(30),
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: () {
            setState(() => _preset = 'Default');
            WebSubStyle.resetAll();
          },
          child: const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.restart_alt_rounded, color: Colors.white),
                SizedBox(width: 12),
                Text('Reset to Default',
                    style: TextStyle(color: Colors.white, fontSize: 18)),
              ],
            ),
          ),
        ),
      ),
    ];
  }

  Widget _delayBtn(String text, IconData icon, VoidCallback tap, bool left) {
    return Material(
      color: _tile,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: tap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (left) Icon(icon, color: Colors.white, size: 22),
              Flexible(
                child: Text(text,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600)),
              ),
              if (!left) Icon(icon, color: Colors.white, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}

/// Checkerboard used for the "transparent" background swatch.
class _Checker extends StatelessWidget {
  const _Checker();

  @override
  Widget build(BuildContext context) => CustomPaint(painter: _CheckerPainter());
}

class _CheckerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const n = 6;
    final w = size.width / n;
    final h = size.height / n;
    final a = Paint()..color = Colors.white;
    final b = Paint()..color = Colors.black;
    for (var y = 0; y < n; y++) {
      for (var x = 0; x < n; x++) {
        canvas.drawRect(
          Rect.fromLTWH(x * w, y * h, w, h),
          (x + y).isEven ? a : b,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
