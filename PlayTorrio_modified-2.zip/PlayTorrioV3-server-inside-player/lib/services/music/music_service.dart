import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../../models/music/music_track.dart';
import 'deezer_api_client.dart';
import 'lyrics_service.dart';
import 'qobuz_music_service.dart';
import 'youtube_stream_resolver.dart';

enum MusicAudioSource { flac, youtube }

class MusicStreamResult {
  final String url;
  final String? userAgent;
  final String format;
  final String quality;
  final bool isLossless;

  const MusicStreamResult({
    required this.url,
    this.userAgent,
    this.format = 'flac',
    this.quality = 'FLAC Hi-Res',
    this.isLossless = true,
  });
}

class MusicService {
  static final MusicService instance = MusicService._internal();
  MusicService._internal();

  final DeezerApiClient _deezer = DeezerApiClient.instance;
  final QobuzMusicService _qobuz = QobuzMusicService.instance;
  final YoutubeStreamResolver _streamResolver = YoutubeStreamResolver.instance;
  final LyricsService _lyricsService = LyricsService.instance;

  Future<MusicSearchData> searchFull(String query) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return MusicSearchData.empty;

    try {
      final tracksFuture = _deezer.searchTracks(trimmed, limit: 30);
      final artistsFuture = _deezer.searchArtists(trimmed, limit: 15);
      final albumsFuture = _deezer.searchAlbums(trimmed, limit: 15);
      final playlistsFuture = _deezer.searchPlaylists(trimmed, limit: 15);

      final youtubeTracks = await _searchArabicYouTube(trimmed);
      final results = await Future.wait([
        tracksFuture,
        artistsFuture,
        albumsFuture,
        playlistsFuture,
      ]);
      return MusicSearchData(
        tracks: [...youtubeTracks, ...(results[0] as List<MusicTrack>)],
        artists: results[1] as List<MusicArtist>,
        albums: results[2] as List<MusicAlbum>,
        playlists: results[3] as List<MusicPlaylist>,
      );
    } catch (e) {
      debugPrint('searchFull error: $e');
      return MusicSearchData.empty;
    }
  }

  Future<List<MusicTrack>> _searchArabicYouTube(String query) async {
    final hasArabic = RegExp(r'[\u0600-\u06FF]').hasMatch(query);
    final searchQuery = hasArabic ? '$query اغاني عراقية عربية' : query;
    try {
      final uri = Uri.https('www.youtube.com', '/results', {'search_query': searchQuery});
      final response = await http.get(uri, headers: const {
        'User-Agent': 'Mozilla/5.0 (Android 13; Mobile) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',
        'Accept-Language': 'ar-IQ,ar;q=0.9,en;q=0.7',
      }).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return const [];
      final body = response.body;
      final re = RegExp(
        r'"videoRenderer":\{"videoId":"([^"]+)".*?"title":\{"runs":\[\{"text":"((?:\\.|[^"])*)".*?"ownerText":\{"runs":\[\{"text":"((?:\\.|[^"])*)"',
        dotAll: true,
      );
      final tracks = <MusicTrack>[];
      final seen = <String>{};
      for (final match in re.allMatches(body)) {
        final videoId = match.group(1) ?? '';
        if (videoId.isEmpty || !seen.add(videoId)) continue;
        String decode(String value) => jsonDecode('"$value"') as String;
        final title = decode(match.group(2) ?? '').trim();
        final artist = decode(match.group(3) ?? '').trim();
        if (title.isEmpty) continue;
        tracks.add(MusicTrack(
          id: 'yt:$videoId',
          title: title,
          artist: artist.isEmpty ? 'YouTube' : artist,
          album: 'YouTube · Arabic / Iraqi',
          coverUrl: 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg',
          durationSeconds: 0,
        ));
        if (tracks.length >= 20) break;
      }
      return tracks;
    } catch (e) {
      debugPrint('Arabic YouTube music search error: $e');
      return const [];
    }
  }

  Future<List<MusicTrack>> searchTracks(String query) async {
    return _deezer.searchTracks(query);
  }

  Future<List<MusicArtist>> fetchTrendingArtists() async {
    try {
      final artists = await _deezer.getChartArtists(limit: 20);
      if (artists.isNotEmpty) return artists;
    } catch (e) {
      debugPrint('fetchTrendingArtists error: $e');
    }
    return [];
  }

  Future<List<MusicAlbum>> fetchNewReleases() async {
    try {
      final albums = await _deezer.getNewReleases(limit: 20);
      if (albums.isNotEmpty) return albums;
      return await _deezer.getChartAlbums(limit: 20);
    } catch (e) {
      debugPrint('fetchNewReleases error: $e');
      return [];
    }
  }

  Future<List<MusicPlaylist>> fetchCuratedPlaylists() async {
    try {
      final playlists = await _deezer.getChartPlaylists(limit: 20);
      if (playlists.isNotEmpty) return playlists;
      return await _deezer.getEditorialSelection(limit: 20);
    } catch (e) {
      debugPrint('fetchCuratedPlaylists error: $e');
      return [];
    }
  }

  Future<Map<String, List<MusicTrack>>> fetchFeaturedSections() async {
    final results = <String, List<MusicTrack>>{};

    try {
      // الصفحة الرئيسية مخصصة للعراقي والعربي. نستخدم YouTube هنا حتى تظهر
      // نتائج حقيقية قابلة للتشغيل، وليس قوائم Deezer العالمية الافتراضية.
      const queries = <String, String>{
        '🔥 أغاني عراقية ترند': 'اغاني عراقية ترند 2026',
        '🎙️ جديد الأغاني العراقية': 'اغاني عراقية جديدة 2026',
        '💔 أغاني عراقية حزينة': 'اغاني عراقية حزينة',
        '🌙 عراقي رومانسي': 'اغاني عراقية رومانسية',
        '🎼 كاظم الساهر وماجد المهندس': 'كاظم الساهر ماجد المهندس اغاني',
        '⭐ أغاني عربية مختارة': 'اغاني عربية جديدة 2026',
      };

      for (final entry in queries.entries) {
        final tracks = await _searchArabicYouTube(entry.value);
        if (tracks.isNotEmpty) results[entry.key] = tracks;
      }

      // في حال تعذر YouTube بالكامل، لا نترك الصفحة فارغة.
      if (results.isEmpty) {
        final fallback = await _deezer.searchTracks('Iraqi Arabic music', limit: 20);
        if (fallback.isNotEmpty) results['🎵 أغاني عراقية وعربية'] = fallback;
      }
    } catch (e) {
      debugPrint('fetchFeaturedSections error: $e');
    }

    return results;
  }

  Future<MusicArtistDetails?> fetchArtistDetails(String artistId) async {
    return _deezer.getArtistDetails(artistId);
  }

  Future<MusicAlbumDetails?> fetchAlbumDetails(String albumId) async {
    return _deezer.getAlbumDetails(albumId);
  }

  Future<MusicPlaylistDetails?> fetchPlaylistDetails(String playlistId) async {
    return _deezer.getPlaylistDetails(playlistId);
  }

  Future<List<MusicGenre>> fetchGenres() async {
    return _deezer.getGenres();
  }

  Future<List<MusicTrack>> fetchGenreTracks(String genreName) async {
    return _deezer.searchTracks('$genreName Top Hits', limit: 25);
  }

  Future<MusicStreamResult?> getAudioStream(
    MusicTrack track, {
    MusicAudioSource source = MusicAudioSource.flac,
  }) async {
    if (source == MusicAudioSource.flac) {
      try {
        final flac = await _qobuz.resolveLosslessUrl(track);
        if (flac != null && flac.url.isNotEmpty) {
          return MusicStreamResult(
            url: flac.url,
            userAgent: flac.headers['User-Agent'],
            format: flac.format,
            quality: flac.quality,
            isLossless: true,
          );
        }
      } catch (e) {
        debugPrint('Qobuz FLAC error, falling back to YouTube: $e');
      }
    }

    // YouTube Audio Stream (Primary or Fallback)
    final yt = await _streamResolver.resolveUrl(track);
    if (yt != null && yt.url.isNotEmpty) {
      return MusicStreamResult(
        url: yt.url,
        userAgent: yt.userAgent,
        format: 'm4a',
        quality: 'YouTube HQ',
        isLossless: false,
      );
    }

    return null;
  }

  Future<LyricsData> fetchLyrics(MusicTrack track) async {
    return _lyricsService.getLyrics(track);
  }
}
