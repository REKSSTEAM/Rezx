import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class WatchPartyRoom {
  final String code;
  final String hostId;
  final String hostName;
  final int memberCount;
  final bool playing;
  final double position;
  final int revision;

  const WatchPartyRoom({
    required this.code,
    required this.hostId,
    required this.hostName,
    required this.memberCount,
    required this.playing,
    required this.position,
    required this.revision,
  });

  factory WatchPartyRoom.fromJson(Map<String, dynamic> json) {
    final state = json['state'] is Map
        ? Map<String, dynamic>.from(json['state'] as Map)
        : <String, dynamic>{};
    return WatchPartyRoom(
      code: json['code']?.toString() ?? '',
      hostId: json['host_id']?.toString() ?? '',
      hostName: json['host_name']?.toString() ?? '',
      memberCount: int.tryParse(json['member_count']?.toString() ?? '') ?? 1,
      playing: state['playing'] == true,
      position: double.tryParse(state['position']?.toString() ?? '') ?? 0,
      revision: int.tryParse(state['revision']?.toString() ?? '') ?? 0,
    );
  }
}

/// Client for the PHP watch-party endpoints used by the web player
/// (`{site}/watch-party/token|create|join|leave|state|action.php`).
///
/// The PHP side keeps the member in a session cookie and checks a CSRF token,
/// so this class stores the cookies itself and sends `X-CSRF-Token` + `_csrf`
/// exactly like watch-party-ajax.js does.
class WatchPartyService extends ChangeNotifier {
  final http.Client _client = http.Client();
  final Map<String, String> _cookies = {};
  String _csrf = '';
  Timer? _timer;
  int _lastRevision = 0;

  String base = '';
  WatchPartyRoom? room;
  String? memberId;
  String? error;
  bool busy = false;

  /// Set while a remote state is being applied so the player's own
  /// play/pause/seek events are not echoed back to the server.
  bool applying = false;

  /// Called when the host's state changes (members only).
  void Function(bool playing, double positionSec)? onRemoteState;

  bool get inRoom => room != null;
  bool get isHost => room != null && room!.hostId == memberId;

  /// Inside a room only the host controls playback (same rule as the web).
  bool get isLocked => inRoom && !isHost;

  Uri _uri(String file, [Map<String, String>? query]) =>
      Uri.parse('$base/watch-party/$file').replace(queryParameters: query);

  Map<String, String> _headers({bool json = false}) => {
    if (json) 'Content-Type': 'application/json',
    if (_csrf.isNotEmpty && json) 'X-CSRF-Token': _csrf,
    if (_cookies.isNotEmpty)
      'Cookie': _cookies.entries.map((e) => '${e.key}=${e.value}').join('; '),
  };

  void _absorb(http.Response res) {
    final raw = res.headers['set-cookie'];
    if (raw == null || raw.isEmpty) return;
    const attributes = {
      'path', 'expires', 'max-age', 'domain', 'samesite', 'secure', 'httponly',
    };
    for (final match in RegExp(r'([^=;,\s]+)=([^;]*)').allMatches(raw)) {
      final name = match.group(1)!;
      if (attributes.contains(name.toLowerCase())) continue;
      _cookies[name] = match.group(2)!;
    }
  }

  Future<void> _ensureCsrf() async {
    if (_csrf.isNotEmpty) return;
    final res = await _client
        .get(_uri('token.php'), headers: _headers())
        .timeout(const Duration(seconds: 15));
    _absorb(res);
    final data = jsonDecode(res.body);
    if (data is! Map || data['ok'] != true || data['csrf'] == null) {
      throw StateError('Security token unavailable');
    }
    _csrf = data['csrf'].toString();
  }

  Future<Map<String, dynamic>> _post(
    String file,
    Map<String, dynamic> body,
  ) async {
    await _ensureCsrf();
    final res = await _client
        .post(
          _uri(file),
          headers: _headers(json: true),
          body: jsonEncode({...body, '_csrf': _csrf}),
        )
        .timeout(const Duration(seconds: 15));
    _absorb(res);
    final data = jsonDecode(res.body);
    return data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
  }

  void _setRoom(Map<String, dynamic> json) {
    room = WatchPartyRoom.fromJson(json);
    notifyListeners();
  }

  void _startPolling() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _poll());
  }

  Future<void> create({
    required String name,
    required String type,
    required String id,
    int? season,
    int? episode,
    String video = '',
  }) async {
    busy = true;
    error = 'Creating room…';
    notifyListeners();
    try {
      final data = await _post('create.php', {
        'name': name,
        'type': type,
        'id': id,
        'season': season?.toString() ?? '',
        'episode': episode?.toString() ?? '',
        'video': video,
      });
      if (data['ok'] != true) {
        throw StateError(data['error']?.toString() ?? 'Could not create room');
      }
      memberId = data['member_id']?.toString();
      error = null;
      _setRoom(Map<String, dynamic>.from(data['room'] as Map));
      _startPolling();
    } catch (e) {
      error = e.toString().replaceFirst('Bad state: ', '');
      notifyListeners();
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> join(String rawCode, String name) async {
    final code = rawCode.trim().toUpperCase();
    if (!RegExp(r'^AFV-[A-Z0-9]{5}$').hasMatch(code)) {
      error = 'Enter a valid room code, for example AFV-7K29P';
      notifyListeners();
      return;
    }
    busy = true;
    error = 'Connecting…';
    notifyListeners();
    try {
      final data = await _post('join.php', {'code': code, 'name': name});
      if (data['ok'] != true) {
        throw StateError(data['error']?.toString() ?? 'Could not join room');
      }
      memberId = data['member_id']?.toString();
      error = null;
      final json = Map<String, dynamic>.from(data['room'] as Map);
      _setRoom(json);
      _applyRemote(room!);
      _startPolling();
    } catch (e) {
      error = e.toString().replaceFirst('Bad state: ', '');
      notifyListeners();
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> leave() async {
    final current = room;
    _timer?.cancel();
    room = null;
    error = null;
    _lastRevision = 0;
    notifyListeners();
    if (current == null) return;
    try {
      await _post('leave.php', {'code': current.code});
    } catch (_) {}
  }

  Future<void> _poll() async {
    final current = room;
    if (current == null) return;
    try {
      final res = await _client
          .get(_uri('state.php', {'code': current.code}), headers: _headers())
          .timeout(const Duration(seconds: 8));
      _absorb(res);
      final data = jsonDecode(res.body);
      if (data is! Map || data['ok'] != true) {
        error = (data is Map ? data['error']?.toString() : null) ??
            'Room unavailable';
        notifyListeners();
        return;
      }
      memberId = data['member_id']?.toString() ?? memberId;
      error = null;
      _setRoom(Map<String, dynamic>.from(data['room'] as Map));
      _applyRemote(room!);
    } catch (_) {
      error = 'Connection lost — retrying…';
      notifyListeners();
    }
  }

  void _applyRemote(WatchPartyRoom r) {
    if (isHost || applying || r.revision == _lastRevision) return;
    _lastRevision = r.revision;
    onRemoteState?.call(r.playing, r.position);
  }

  /// Host only: report play / pause / seek.
  Future<void> sendAction(
    String event, {
    required double position,
    required bool playing,
  }) async {
    final current = room;
    if (current == null || !isHost || applying) return;
    try {
      final data = await _post('action.php', {
        'code': current.code,
        'event': event,
        'position': position,
        'playing': playing,
      });
      if (data['ok'] == true && data['room'] is Map) {
        final state = (data['room'] as Map)['state'];
        if (state is Map) {
          _lastRevision =
              int.tryParse(state['revision']?.toString() ?? '') ?? _lastRevision;
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    _client.close();
    super.dispose();
  }
}
