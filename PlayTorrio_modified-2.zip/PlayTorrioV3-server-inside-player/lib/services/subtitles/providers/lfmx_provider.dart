import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../../../models/subtitle/subtitle_model.dart';
import '../../scraper/sites/tmdb_helper.dart';
import '../subtitle_extractor.dart';
import '../subtitle_provider.dart';

/// Single subtitle source: LFMX API (stream.lfmx.app).
///
/// GET  {base}/api/subtitles?tmdbId=&mediaType=movie|tv&title=&season=&episode=
/// GET  {base}/api/subtitles/fetch?url=<encoded fetchUrl>   (or an absolute URL)
class LfmxProvider extends SubtitleProvider {
  @override
  String get name => 'LFMX';

  static const String baseStream = 'https://stream.lfmx.app';
  static const String origin = 'https://moanatv.lfmx.app';

  static const Map<String, String> _listHeaders = {
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'user-agent':
        'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua-platform': '"Android"',
    'accept': '*/*',
    'origin': origin,
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': '$origin/',
    'accept-language': 'ar-IQ,ar;q=0.9,en-IQ;q=0.8,en;q=0.7,en-US;q=0.6',
  };

  static const Map<String, String> _fetchHeaders = {
    'user-agent':
        'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'origin': origin,
    'referer': '$origin/',
    'accept': '*/*',
  };

  static const Map<String, String> _langNames = {
    'ara': 'Arabic', 'ar': 'Arabic',
    'eng': 'English', 'en': 'English',
    'spa': 'Spanish', 'es': 'Spanish',
    'fre': 'French', 'fra': 'French', 'fr': 'French',
    'ger': 'German', 'deu': 'German', 'de': 'German',
    'ita': 'Italian', 'it': 'Italian',
    'jpn': 'Japanese', 'ja': 'Japanese',
    'kor': 'Korean', 'ko': 'Korean',
    'rus': 'Russian', 'ru': 'Russian',
    'por': 'Portuguese', 'pt': 'Portuguese',
    'chi': 'Chinese', 'zho': 'Chinese', 'zh': 'Chinese',
    'hin': 'Hindi', 'hi': 'Hindi',
    'tur': 'Turkish', 'tr': 'Turkish',
    'ind': 'Indonesian', 'id': 'Indonesian',
    'per': 'Persian', 'fas': 'Persian', 'fa': 'Persian',
  };

  static String buildFetchUrl(String fetchUrl) {
    if (fetchUrl.startsWith('http')) return fetchUrl; // absolute (os-*)
    return '$baseStream/api/subtitles/fetch?url=${Uri.encodeComponent(fetchUrl)}';
  }

  @override
  Future<List<SubtitleVariant>> search(
    String movieName, {
    String? imdbId,
    int? season,
    int? episode,
    int? year,
    String? tmdbId,
    String? mediaType,
  }) async {
    final results = <SubtitleVariant>[];
    try {
      // Media type: explicit value wins, otherwise infer from season/episode.
      final mt = (mediaType ?? '').toLowerCase();
      final isTv = (mt == 'tv' || mt == 'series')
          ? true
          : (mt == 'movie' ? false : (season != null && episode != null));

      // TMDB id: use the one the app already has; resolve only as a fallback.
      String? resolvedId = (tmdbId ?? '').trim();
      if (!RegExp(r'^\d+$').hasMatch(resolvedId)) {
        final id = await TmdbHelper.resolveTmdbId(
          imdbId: imdbId,
          title: movieName,
          type: isTv ? 'tv' : 'movie',
          year: year,
        );
        resolvedId = id?.toString();
      }
      if (resolvedId == null || resolvedId.isEmpty) return results;

      final query = <String, String>{
        'tmdbId': resolvedId,
        'mediaType': isTv ? 'tv' : 'movie',
        if (movieName.isNotEmpty) 'title': movieName,
        if (isTv && season != null) 'season': season.toString(),
        if (isTv && episode != null) 'episode': episode.toString(),
      };

      final uri = Uri.parse('$baseStream/api/subtitles')
          .replace(queryParameters: query);
      final res = await http
          .get(uri, headers: _listHeaders)
          .timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return results;

      final data = jsonDecode(utf8.decode(res.bodyBytes));
      final list = data is Map ? data['subtitles'] : data;
      if (list is! List) return results;

      for (final item in list) {
        if (item is! Map) continue;
        final map = Map<String, dynamic>.from(item);
        final raw = map['fetchUrl']?.toString();
        if (raw == null || raw.isEmpty) continue;

        final rawLang = (map['language'] ??
                map['lang'] ??
                map['languageCode'] ??
                map['code'] ??
                'en')
            .toString();
        final lowerLang = rawLang.toLowerCase();
        final display = (map['display'] ?? map['languageName'] ?? map['label'])
            ?.toString();
        final language = (display != null && display.isNotEmpty)
            ? display
            : (_langNames[lowerLang] ??
                (lowerLang.length <= 3 ? lowerLang.toUpperCase() : rawLang));

        final title = (map['release'] ??
                map['name'] ??
                map['title'] ??
                map['fileName'] ??
                'LFMX Subtitle')
            .toString();

        final fetchApiUrl = buildFetchUrl(raw);
        results.add(
          SubtitleVariant(
            providerName: name,
            language: language,
            title: title,
            downloadUrl: fetchApiUrl,
            format: (map['format'] ?? 'srt').toString().toLowerCase(),
            extraData: {
              'headers': _fetchHeaders,
              'source': map['source'],
            },
          ),
        );
      }
    } catch (e) {
      // ignore: avoid_print
      print('[LfmxProvider] search error: $e');
    }
    return results;
  }

  @override
  Future<String?> download(SubtitleVariant variant) async {
    final path = await SubtitleExtractor.downloadAndExtract(
      variant.downloadUrl,
      headers: Map<String, String>.from(_fetchHeaders),
      providerName: name,
    );
    if (path == null) return null;

    // LFMX serves VTT; the extractor defaults to .srt when the URL has no
    // extension, so fix the extension based on the actual content.
    try {
      final file = File(path);
      final head = (await file.readAsString()).trimLeft();
      if (head.startsWith('WEBVTT') && !path.endsWith('.vtt')) {
        final fixed = '${path.substring(0, path.lastIndexOf('.'))}.vtt';
        await file.rename(fixed);
        return fixed;
      }
    } catch (_) {}
    return path;
  }
}
