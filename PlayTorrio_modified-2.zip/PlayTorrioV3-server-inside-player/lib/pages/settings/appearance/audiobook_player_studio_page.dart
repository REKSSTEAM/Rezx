import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';

import 'package:liquid_glass_easy/liquid_glass_easy.dart';

import '../../../services/theme/app_theme_service.dart';
import '../../../services/audiobook/audiobook_settings.dart';
import '../../../widgets/audiobook/audiobook_interactive_physics_button.dart';
import '../../../widgets/audiobook/audiobook_waveform_seekbar.dart';

class AudiobookPlayerStudioPage extends StatefulWidget {
  const AudiobookPlayerStudioPage({super.key});

  @override
  State<AudiobookPlayerStudioPage> createState() => _AudiobookPlayerStudioPageState();
}

class _AudiobookPlayerStudioPageState extends State<AudiobookPlayerStudioPage> with SingleTickerProviderStateMixin {
  // Live Studio Preview State
  bool _previewIsPlaying = true;
  Duration _previewPosition = const Duration(minutes: 14, seconds: 32);
  final Duration _previewDuration = const Duration(minutes: 45, seconds: 00);
  double _previewSpeed = 1.0;
  double _previewVolume = 0.85;
  bool _showChaptersPreview = false;

  late AnimationController _discController;
  int _selectedStudioTab = 0; // 0: Layout Drag & Drop, 1: Seekbar Canvas, 2: Buttons & Physics, 3: Artwork & Atmosphere
  int _mobileViewMode = 0; // 0: Studio Designer, 1: Live Interactive Canvas

  @override
  void initState() {
    super.initState();
    _discController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    AudiobookSettings.changeNotifier.addListener(_onSettingsChanged);
  }

  void _onSettingsChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    AudiobookSettings.changeNotifier.removeListener(_onSettingsChanged);
    _discController.dispose();
    super.dispose();
  }

  void _togglePlayPause() {
    setState(() {
      _previewIsPlaying = !_previewIsPlaying;
      if (_previewIsPlaying) {
        _discController.repeat();
      } else {
        _discController.stop();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppThemeService.currentPalette.value;
    final screenW = MediaQuery.sizeOf(context).width;
    final isDesktop = screenW >= 960;

    return Scaffold(
      backgroundColor: const Color(0xFF07090E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D1017),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: screenW < 600
            ? const Text(
                'Player Studio',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
              )
            : Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [palette.primaryColor, palette.accentColor],
                      ),
                    ),
                    child: const Icon(Icons.dashboard_customize_rounded, color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 12),
                  const Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Custom Audiobook Player Studio',
                          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: -0.3),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          'Drag components, transform seekbars, customize button physics',
                          style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.normal),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
        actions: [
          if (screenW < 520)
            IconButton(
              tooltip: 'Apply As Active Player',
              onPressed: () {
                AudiobookSettings.setSelectedPlayerPreset(AudiobookPlayerPreset.customStudio);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Custom Player Studio layout applied & set as active player!'),
                    backgroundColor: palette.primaryColor,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              icon: Icon(Icons.check_circle_rounded, color: palette.primaryColor, size: 24),
            )
          else
            TextButton.icon(
              onPressed: () {
                AudiobookSettings.setSelectedPlayerPreset(AudiobookPlayerPreset.customStudio);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Custom Player Studio layout applied & set as active player!'),
                    backgroundColor: palette.primaryColor,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              icon: const Icon(Icons.check_circle_rounded, color: Colors.white, size: 18),
              label: const Text('Apply As Active Player', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12.5)),
              style: TextButton.styleFrom(
                backgroundColor: palette.primaryColor.withValues(alpha: 0.25),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          const SizedBox(width: 10),
        ],
      ),
      body: isDesktop
          ? Row(
              children: [
                // Left Panel: Interactive Live Player Canvas Preview
                Expanded(
                  flex: 5,
                  child: _buildLivePlayerCanvas(palette, isDesktop: true),
                ),
                VerticalDivider(width: 1, color: Colors.white.withValues(alpha: 0.08)),
                // Right Panel: Customizer Studio Controls
                Expanded(
                  flex: 6,
                  child: _buildStudioControlsPanel(palette),
                ),
              ],
            )
          : Column(
              children: [
                // Mobile Mode Switcher Bar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0C0F17),
                    border: Border(bottom: BorderSide(color: Colors.white.withValues(alpha: 0.08))),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: () => setState(() => _mobileViewMode = 0),
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            decoration: BoxDecoration(
                              color: _mobileViewMode == 0 ? palette.primaryColor.withValues(alpha: 0.2) : Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: _mobileViewMode == 0 ? palette.primaryColor : Colors.white.withValues(alpha: 0.06),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.tune_rounded,
                                  size: 15,
                                  color: _mobileViewMode == 0 ? palette.primaryColor : Colors.white60,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Studio Designer',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: _mobileViewMode == 0 ? FontWeight.bold : FontWeight.w500,
                                    color: _mobileViewMode == 0 ? Colors.white : Colors.white60,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: InkWell(
                          onTap: () => setState(() => _mobileViewMode = 1),
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            decoration: BoxDecoration(
                              color: _mobileViewMode == 1 ? palette.primaryColor.withValues(alpha: 0.2) : Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: _mobileViewMode == 1 ? palette.primaryColor : Colors.white.withValues(alpha: 0.06),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.play_circle_fill_rounded,
                                  size: 15,
                                  color: _mobileViewMode == 1 ? palette.primaryColor : Colors.white60,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Live Preview Canvas',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: _mobileViewMode == 1 ? FontWeight.bold : FontWeight.w500,
                                    color: _mobileViewMode == 1 ? Colors.white : Colors.white60,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Mobile Mode Viewport
                Expanded(
                  child: _mobileViewMode == 0
                      ? Stack(
                          children: [
                            _buildStudioControlsPanel(palette),
                            Positioned(
                              bottom: 16,
                              right: 16,
                              child: FloatingActionButton.extended(
                                onPressed: () => setState(() => _mobileViewMode = 1),
                                backgroundColor: palette.primaryColor,
                                icon: const Icon(Icons.touch_app_rounded, color: Colors.white, size: 18),
                                label: const Text(
                                  'Test Live Canvas',
                                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                                ),
                              ),
                            ),
                          ],
                        )
                      : Stack(
                          children: [
                            _buildLivePlayerCanvas(palette, isDesktop: false),
                            Positioned(
                              bottom: 16,
                              left: 16,
                              child: FloatingActionButton.extended(
                                onPressed: () => setState(() => _mobileViewMode = 0),
                                backgroundColor: const Color(0xFF161A28),
                                icon: Icon(Icons.arrow_back_rounded, color: palette.primaryColor, size: 18),
                                label: const Text(
                                  'Back to Customizer',
                                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                                ),
                              ),
                            ),
                          ],
                        ),
                ),
              ],
            ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // ── LEFT: INTERACTIVE LIVE PLAYER CANVAS PREVIEW ──
  // ═══════════════════════════════════════════════════════════════
  Widget _buildLivePlayerCanvas(AppThemePalette palette, {bool isDesktop = true}) {
    final order = AudiobookSettings.componentOrder.value;
    final seekStyle = AudiobookSettings.customSeekbarStyle.value;
    final artStyle = AudiobookSettings.customArtworkStyle.value;

    return Container(
      color: const Color(0xFF06080D),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Background ambient light orb
          Positioned(
            top: 40,
            child: Container(
              width: 320,
              height: 320,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: palette.primaryColor.withValues(alpha: 0.12),
              ),
            ),
          ),
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
              child: const SizedBox.expand(),
            ),
          ),

          // Player Container
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: isDesktop ? 24 : 12, vertical: 16),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Container(
                  padding: EdgeInsets.all(isDesktop ? 22 : 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F121C).withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(
                      color: palette.primaryColor.withValues(alpha: 0.35),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: palette.primaryColor.withValues(alpha: 0.2),
                        blurRadius: 36,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Badge Header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: palette.primaryColor.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.touch_app_rounded, color: palette.primaryColor, size: 12),
                                const SizedBox(width: 4),
                                Text(
                                  'LIVE INTERACTIVE CANVAS',
                                  style: TextStyle(color: palette.primaryColor, fontSize: 9.5, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            'CUSTOM STUDIO',
                            style: TextStyle(color: Colors.white.withValues(alpha: 0.4), fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Dynamic Components Rendered according to Drag & Drop Order
                      ...order.map((key) => _buildPreviewComponent(key, palette, seekStyle, artStyle)),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Chapters Slide-in Drawer Preview Overlay
          if (_showChaptersPreview)
            Positioned.fill(
              child: _buildChaptersPreviewOverlay(palette),
            ),
        ],
      ),
    );
  }

  Widget _buildPreviewComponent(
    String key,
    AppThemePalette palette,
    AudiobookSeekbarStyle seekStyle,
    AudiobookArtworkStyle artStyle,
  ) {
    switch (key) {
      case 'artwork':
        if (artStyle == AudiobookArtworkStyle.hidden) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: _buildPreviewArtwork(palette, artStyle),
        );

      case 'title':
        return Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Column(
            children: [
              const Text(
                'Chapter 4: The Secrets of the Night',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                'Chapter 4 of 24 • Harry Potter & The Sorcerer\'s Stone',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 11.5),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        );

      case 'seekbar':
        return Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: AudiobookWaveformSeekbar(
            position: _previewPosition,
            duration: _previewDuration,
            isPlaying: _previewIsPlaying,
            style: seekStyle,
            onSeek: (pos) => setState(() => _previewPosition = pos),
          ),
        );

      case 'mainControls':
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildCanvasIconButton(Icons.skip_previous_rounded, 24, palette, () {}),
              _buildCanvasIconButton(
                Icons.replay_10_rounded,
                24,
                palette,
                () => setState(() => _previewPosition = Duration(seconds: max(0, _previewPosition.inSeconds - 10))),
              ),
              _buildCustomPlayPauseButton(palette),
              _buildCanvasIconButton(
                Icons.forward_10_rounded,
                24,
                palette,
                () => setState(() => _previewPosition = Duration(seconds: min(_previewDuration.inSeconds, _previewPosition.inSeconds + 10))),
              ),
              _buildCanvasIconButton(Icons.skip_next_rounded, 24, palette, () {}),
            ],
          ),
        );

      case 'secondaryControls':
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Speed Pill
              InkWell(
                onTap: () {
                  final speeds = [0.75, 1.0, 1.25, 1.5, 2.0];
                  final next = speeds[(speeds.indexOf(_previewSpeed) + 1) % speeds.length];
                  setState(() => _previewSpeed = next);
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
                  ),
                  child: Text(
                    '${_previewSpeed}x Speed',
                    style: TextStyle(color: palette.primaryColor, fontSize: 11.5, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              // Volume Icon
              Icon(Icons.volume_up_rounded, color: palette.primaryColor, size: 20),
              const SizedBox(width: 6),
              SizedBox(
                width: 70,
                child: SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 3,
                    thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 4),
                    activeTrackColor: palette.primaryColor,
                    inactiveTrackColor: Colors.white12,
                    thumbColor: Colors.white,
                  ),
                  child: Slider(
                    value: _previewVolume,
                    min: 0.0,
                    max: 1.0,
                    onChanged: (v) => setState(() => _previewVolume = v),
                  ),
                ),
              ),
            ],
          ),
        );

      case 'chaptersButton':
        return Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: OutlinedButton.icon(
            onPressed: () => setState(() => _showChaptersPreview = true),
            icon: Icon(Icons.format_list_bulleted_rounded, color: palette.primaryColor, size: 16),
            label: const Text('Premade Chapters Panel', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: palette.primaryColor.withValues(alpha: 0.4)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
          ),
        );

      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildPreviewArtwork(AppThemePalette palette, AudiobookArtworkStyle artStyle) {
    if (artStyle == AudiobookArtworkStyle.vinylDisc) {
      return AnimatedBuilder(
        animation: _discController,
        builder: (context, child) => Transform.rotate(
          angle: _previewIsPlaying ? _discController.value * 2 * pi : 0,
          child: child,
        ),
        child: Container(
          width: 130,
          height: 130,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF141724),
            border: Border.all(color: Colors.white.withValues(alpha: 0.15), width: 3),
            boxShadow: [
              BoxShadow(
                color: palette.primaryColor.withValues(alpha: 0.35),
                blurRadius: 20,
              ),
            ],
          ),
          child: Center(
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF080A0F),
                border: Border.all(color: palette.primaryColor, width: 2),
              ),
            ),
          ),
        ),
      );
    }

    if (artStyle == AudiobookArtworkStyle.floatingCard) {
      return Container(
        width: 130,
        height: 130,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(
            colors: [palette.primaryColor.withValues(alpha: 0.4), const Color(0xFF161A28)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: Colors.white.withValues(alpha: 0.18)),
          boxShadow: [
            BoxShadow(
              color: palette.primaryColor.withValues(alpha: 0.3),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: const Icon(Icons.headphones_rounded, color: Colors.white, size: 48),
      );
    }

    // Default: 3D Rounded Square
    return Container(
      width: 130,
      height: 130,
      decoration: BoxDecoration(
        color: const Color(0xFF161A28),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: palette.primaryColor.withValues(alpha: 0.4), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: palette.primaryColor.withValues(alpha: 0.35),
            blurRadius: 22,
          ),
        ],
      ),
      child: const Icon(Icons.menu_book_rounded, color: Colors.white70, size: 46),
    );
  }

  Widget _buildCustomPlayPauseButton(AppThemePalette palette) {
    final style = AudiobookSettings.customPlayButtonStyle.value;
    final hoverEffect = AudiobookSettings.customHoverEffect.value;
    final icon = _previewIsPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded;

    Widget buttonCore;
    BorderRadius borderRadius;

    if (style == AudiobookPlayButtonStyle.liquidGlassNeo) {
      borderRadius = BorderRadius.circular(18);
      final glassStyle = LiquidGlassStyle(
        shape: const LiquidGlassShape.continuousRoundedRectangle(
          cornerRadius: 18,
          clipQuality: LiquidGlassClipQuality.exact,
          borderWidth: 1.5,
          lightIntensity: 1.5,
          lightColor: Color(0xE6FFFFFF),
          lightDirection: 115,
          borderType: OpticalBorder(
            borderSaturation: 1.5,
            ambientIntensity: 1.2,
            borderSolidity: 0.2,
            lightSpread: 0.7,
          ),
        ),
        appearance: LiquidGlassAppearance(
          color: palette.primaryColor.withValues(alpha: 0.15),
          saturation: 1.2,
          blur: const LiquidGlassBlur(sigmaX: 3.0, sigmaY: 3.0),
          shadow: LiquidGlassShadow(
            blur: 16,
            opacity: 0.4,
            color: palette.primaryColor,
          ),
        ),
        refraction: const LiquidGlassRefraction(
          magnification: 1.04,
          chromaticAberration: 0.0035,
          refractionType: OpticalRefraction(
            refraction: 1.55,
            refractionWidth: 22,
            depth: 0.8,
          ),
        ),
      );

      buttonCore = LiquidGlassLens(
        style: glassStyle,
        visibility: true,
        useImpellerBackdrop: true,
        child: Container(
          width: 52,
          height: 52,
          alignment: Alignment.center,
          child: Icon(icon, color: Colors.white, size: 30),
        ),
      );
    } else if (style == AudiobookPlayButtonStyle.roundedSquare) {
      borderRadius = BorderRadius.circular(14);
      buttonCore = Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: palette.primaryColor,
          borderRadius: borderRadius,
          boxShadow: [
            BoxShadow(
              color: palette.primaryColor.withValues(alpha: 0.5),
              blurRadius: 16,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 28),
      );
    } else if (style == AudiobookPlayButtonStyle.accentPill) {
      borderRadius = BorderRadius.circular(20);
      buttonCore = Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: palette.primaryColor,
          borderRadius: borderRadius,
          boxShadow: [
            BoxShadow(
              color: palette.primaryColor.withValues(alpha: 0.4),
              blurRadius: 14,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 4),
            Text(
              _previewIsPlaying ? 'PAUSE' : 'PLAY',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11),
            ),
          ],
        ),
      );
    } else {
      borderRadius = BorderRadius.circular(26);
      buttonCore = Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: palette.primaryColor,
          boxShadow: [
            BoxShadow(
              color: palette.primaryColor.withValues(alpha: 0.6),
              blurRadius: 18,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 32),
      );
    }

    return AudiobookInteractivePhysicsButton(
      effect: hoverEffect,
      glowColor: palette.primaryColor,
      borderRadius: borderRadius,
      onTap: _togglePlayPause,
      child: buttonCore,
    );
  }

  Widget _buildCanvasIconButton(IconData icon, double size, AppThemePalette palette, VoidCallback onTap) {
    return AudiobookInteractivePhysicsButton(
      effect: AudiobookSettings.customHoverEffect.value,
      glowColor: palette.primaryColor,
      borderRadius: BorderRadius.circular(size),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Icon(icon, size: size, color: Colors.white70),
      ),
    );
  }

  Widget _buildChaptersPreviewOverlay(AppThemePalette palette) {
    return GestureDetector(
      onTap: () => setState(() => _showChaptersPreview = false),
      child: Container(
        color: Colors.black.withValues(alpha: 0.7),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: GestureDetector(
            onTap: () {},
            child: Container(
              height: 280,
              decoration: BoxDecoration(
                color: const Color(0xFF0F121C),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
                border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
              ),
              child: Column(
                children: [
                  Container(width: 36, height: 4, margin: const EdgeInsets.only(top: 8, bottom: 6), decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Premade Chapters Panel Preview', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                        IconButton(
                          icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 18),
                          onPressed: () => setState(() => _showChaptersPreview = false),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      children: [
                        _buildSampleChapterTile(1, 'Chapter 1: The Boy Who Lived', false, palette),
                        _buildSampleChapterTile(2, 'Chapter 2: The Vanishing Glass', false, palette),
                        _buildSampleChapterTile(3, 'Chapter 3: The Letters from No One', false, palette),
                        _buildSampleChapterTile(4, 'Chapter 4: The Keeper of the Keys', true, palette),
                        _buildSampleChapterTile(5, 'Chapter 5: Diagon Alley', false, palette),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSampleChapterTile(int num, String title, bool isCurrent, AppThemePalette palette) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: isCurrent ? palette.primaryColor.withValues(alpha: 0.22) : Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: isCurrent ? palette.primaryColor : Colors.white.withValues(alpha: 0.06)),
      ),
      child: Row(
        children: [
          Icon(isCurrent ? Icons.graphic_eq_rounded : Icons.play_arrow_rounded, color: isCurrent ? palette.primaryColor : Colors.white54, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: TextStyle(color: isCurrent ? Colors.white : Colors.white70, fontSize: 12.5, fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // ── RIGHT: STUDIO CUSTOMIZATION CONTROLS PANEL ──
  // ═══════════════════════════════════════════════════════════════
  Widget _buildStudioControlsPanel(AppThemePalette palette) {
    return Container(
      color: const Color(0xFF090B10),
      child: Column(
        children: [
          // Studio Sub-Tabs
          Container(
            height: 52,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF0C0F17),
              border: Border(bottom: BorderSide(color: Colors.white.withValues(alpha: 0.08))),
            ),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildTabChip(0, Icons.drag_indicator_rounded, 'Drag & Drop Layout', palette),
                _buildTabChip(1, Icons.graphic_eq_rounded, 'Seek Bar Canvas', palette),
                _buildTabChip(2, Icons.touch_app_rounded, 'Play Button & Physics', palette),
                _buildTabChip(3, Icons.image_rounded, 'Artwork & Frame', palette),
              ],
            ),
          ),

          // Active Tab Content
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              physics: const BouncingScrollPhysics(),
              children: [
                if (_selectedStudioTab == 0) _buildDragAndDropLayoutSection(palette),
                if (_selectedStudioTab == 1) _buildSeekbarCanvasSection(palette),
                if (_selectedStudioTab == 2) _buildPlayButtonPhysicsSection(palette),
                if (_selectedStudioTab == 3) _buildArtworkFrameSection(palette),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabChip(int index, IconData icon, String label, AppThemePalette palette) {
    final isSelected = _selectedStudioTab == index;

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        avatar: Icon(icon, color: isSelected ? Colors.white : Colors.white54, size: 16),
        label: Text(label),
        selected: isSelected,
        selectedColor: palette.primaryColor,
        backgroundColor: const Color(0xFF121520),
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : Colors.white70,
          fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
          fontSize: 12,
        ),
        side: BorderSide(color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.08)),
        onSelected: (val) {
          if (val) setState(() => _selectedStudioTab = index);
        },
      ),
    );
  }

  // ── Tab 0: Drag & Drop Reorderable Components ──
  Widget _buildDragAndDropLayoutSection(AppThemePalette palette) {
    final componentNames = {
      'artwork': 'Artwork & Vinyl Frame',
      'title': 'Chapter & Book Titles',
      'seekbar': 'Seek Bar Scrubber Canvas',
      'mainControls': 'Primary Controls (Play, Pause, Skip ±10s)',
      'secondaryControls': 'Secondary Controls (Speed Pill & Volume)',
      'chaptersButton': 'Premade Chapters Panel Button',
    };

    final componentIcons = {
      'artwork': Icons.image_rounded,
      'title': Icons.title_rounded,
      'seekbar': Icons.graphic_eq_rounded,
      'mainControls': Icons.play_circle_filled_rounded,
      'secondaryControls': Icons.tune_rounded,
      'chaptersButton': Icons.format_list_bulleted_rounded,
    };

    return ValueListenableBuilder<List<String>>(
      valueListenable: AudiobookSettings.componentOrder,
      builder: (context, order, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.drag_indicator_rounded, color: palette.primaryColor, size: 18),
                const SizedBox(width: 8),
                const Text(
                  'Drag & Drop Component Arranger',
                  style: TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Hold and drag any block to reorder the vertical layout of your audio player in real-time.',
              style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 12),
            ),
            const SizedBox(height: 16),

            ReorderableListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              buildDefaultDragHandles: false,
              onReorder: (oldIdx, newIdx) {
                AudiobookSettings.reorderComponents(oldIdx, newIdx);
              },
              children: List.generate(order.length, (index) {
                final key = order[index];
                final name = componentNames[key] ?? key;
                final icon = componentIcons[key] ?? Icons.widgets_rounded;

                return ReorderableDelayedDragStartListener(
                  key: ValueKey(key),
                  index: index,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF121622),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
                    ),
                    child: Row(
                      children: [
                        ReorderableDragStartListener(
                          index: index,
                          child: Icon(Icons.drag_handle_rounded, color: palette.primaryColor, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          padding: const EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            color: palette.primaryColor.withValues(alpha: 0.18),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(icon, color: palette.primaryColor, size: 16),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Position #${index + 1}',
                                style: TextStyle(color: Colors.white.withValues(alpha: 0.4), fontSize: 10.5),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ],
        );
      },
    );
  }

  // ── Tab 1: Seekbar Canvas Styles ──
  Widget _buildSeekbarCanvasSection(AppThemePalette palette) {
    return ValueListenableBuilder<AudiobookSeekbarStyle>(
      valueListenable: AudiobookSettings.customSeekbarStyle,
      builder: (context, currentStyle, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.graphic_eq_rounded, color: palette.primaryColor, size: 18),
                const SizedBox(width: 8),
                const Text(
                  'Seek Bar Canvas & Scrubber Styles',
                  style: TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Select how your progress bar and scrubber render inside your custom player canvas.',
              style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 12),
            ),
            const SizedBox(height: 16),

            ...AudiobookSeekbarStyle.values.map((s) {
              final isSelected = s == currentStyle;
              return InkWell(
                onTap: () => AudiobookSettings.setCustomSeekbarStyle(s),
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isSelected ? palette.primaryColor.withValues(alpha: 0.16) : const Color(0xFF121622),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.08),
                      width: isSelected ? 1.5 : 1.0,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.06),
                        ),
                        child: Icon(
                          s == AudiobookSeekbarStyle.audioWaveformCanvas
                              ? Icons.graphic_eq_rounded
                              : s == AudiobookSeekbarStyle.gradientProgress
                                  ? Icons.linear_scale_rounded
                                  : s == AudiobookSeekbarStyle.standardSlider
                                      ? Icons.tune_rounded
                                      : Icons.radio_button_checked_rounded,
                          color: isSelected ? Colors.white : Colors.white70,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              s.label,
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.white.withValues(alpha: 0.9),
                                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                fontSize: 13.5,
                              ),
                            ),
                            Text(
                              s.description,
                              style: TextStyle(color: Colors.white.withValues(alpha: 0.5), fontSize: 11.5),
                            ),
                          ],
                        ),
                      ),
                      if (isSelected)
                        Icon(Icons.check_circle_rounded, color: palette.primaryColor, size: 20),
                    ],
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }

  // ── Tab 2: Play Button & Hover Physics ──
  Widget _buildPlayButtonPhysicsSection(AppThemePalette palette) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.touch_app_rounded, color: palette.primaryColor, size: 18),
            const SizedBox(width: 8),
            const Text(
              'Play / Pause Button Style',
              style: TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.w800),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ValueListenableBuilder<AudiobookPlayButtonStyle>(
          valueListenable: AudiobookSettings.customPlayButtonStyle,
          builder: (context, currentBtnStyle, _) {
            return Column(
              children: AudiobookPlayButtonStyle.values.map((b) {
                final isSelected = b == currentBtnStyle;
                return InkWell(
                  onTap: () => AudiobookSettings.setCustomPlayButtonStyle(b),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isSelected ? palette.primaryColor.withValues(alpha: 0.16) : const Color(0xFF121622),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.08),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isSelected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                          color: isSelected ? palette.primaryColor : Colors.white38,
                          size: 18,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          b.label,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.white70,
                            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),

        const SizedBox(height: 20),

        Row(
          children: [
            Icon(Icons.animation_rounded, color: palette.primaryColor, size: 18),
            const SizedBox(width: 8),
            const Text(
              'Hover & Touch Physics',
              style: TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.w800),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ValueListenableBuilder<AudiobookHoverEffect>(
          valueListenable: AudiobookSettings.customHoverEffect,
          builder: (context, currentHover, _) {
            return Column(
              children: AudiobookHoverEffect.values.map((h) {
                final isSelected = h == currentHover;
                return InkWell(
                  onTap: () => AudiobookSettings.setCustomHoverEffect(h),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isSelected ? palette.primaryColor.withValues(alpha: 0.16) : const Color(0xFF121622),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.08),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isSelected ? Icons.check_circle_rounded : Icons.circle_outlined,
                          color: isSelected ? palette.primaryColor : Colors.white38,
                          size: 18,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          h.label,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.white70,
                            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),

        const SizedBox(height: 20),

        // Live Touch & Hover Physics Playground
        ValueListenableBuilder<AudiobookHoverEffect>(
          valueListenable: AudiobookSettings.customHoverEffect,
          builder: (context, currentHover, _) {
            return Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF101420),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: palette.primaryColor.withValues(alpha: 0.4), width: 1.2),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.touch_app_rounded, color: palette.primaryColor, size: 18),
                      const SizedBox(width: 8),
                      const Text(
                        'Live Touch & Hover Physics Playground',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13.5),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Hover your cursor or tap below to feel "${currentHover.label}" in real-time:',
                    style: TextStyle(color: Colors.white.withValues(alpha: 0.6), fontSize: 12),
                  ),
                  const SizedBox(height: 18),
                  Center(
                    child: AudiobookInteractivePhysicsButton(
                      effect: currentHover,
                      glowColor: palette.primaryColor,
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {},
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [palette.primaryColor, palette.accentColor],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: palette.primaryColor.withValues(alpha: 0.4),
                              blurRadius: 16,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.touch_app_rounded, color: Colors.white, size: 22),
                            const SizedBox(width: 10),
                            Text(
                              'Test "${currentHover.label}"',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                letterSpacing: 0.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  // ── Tab 3: Artwork & Frame Styles ──
  Widget _buildArtworkFrameSection(AppThemePalette palette) {
    return ValueListenableBuilder<AudiobookArtworkStyle>(
      valueListenable: AudiobookSettings.customArtworkStyle,
      builder: (context, currentArtStyle, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.image_rounded, color: palette.primaryColor, size: 18),
                const SizedBox(width: 8),
                const Text(
                  'Artwork Display Mode',
                  style: TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 14),

            ...AudiobookArtworkStyle.values.map((a) {
              final isSelected = a == currentArtStyle;
              return InkWell(
                onTap: () => AudiobookSettings.setCustomArtworkStyle(a),
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isSelected ? palette.primaryColor.withValues(alpha: 0.16) : const Color(0xFF121622),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.08),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isSelected ? palette.primaryColor : Colors.white.withValues(alpha: 0.06),
                        ),
                        child: Icon(
                          a == AudiobookArtworkStyle.square3D
                              ? Icons.crop_square_rounded
                              : a == AudiobookArtworkStyle.vinylDisc
                                  ? Icons.album_rounded
                                  : a == AudiobookArtworkStyle.floatingCard
                                      ? Icons.layers_rounded
                                      : Icons.visibility_off_rounded,
                          color: isSelected ? Colors.white : Colors.white70,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          a.label,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.white.withValues(alpha: 0.9),
                            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                            fontSize: 13.5,
                          ),
                        ),
                      ),
                      if (isSelected)
                        Icon(Icons.check_circle_rounded, color: palette.primaryColor, size: 20),
                    ],
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}
