import 'package:flutter/material.dart';

/// Picture settings from the "Video" panel (brightness, contrast, saturation,
/// aspect ratio, ASCII / VR modes). Kept in memory for the whole session.
abstract final class WebVideoStyle {
  static final brightness = ValueNotifier<double>(1.0); // 0 … 2
  static final contrast = ValueNotifier<double>(1.0); // 0 … 2
  static final saturation = ValueNotifier<double>(1.0); // 0 … 2
  static final asciiMode = ValueNotifier<bool>(false);
  static final asciiColor = ValueNotifier<bool>(true);
  static final vrMode = ValueNotifier<bool>(false);
  static final aspect = ValueNotifier<String>('fit'); // fit | fill | stretch

  static BoxFit fitFor(String key) {
    switch (key) {
      case 'fill':
        return BoxFit.cover;
      case 'stretch':
        return BoxFit.fill;
      default:
        return BoxFit.contain;
    }
  }

  static const Map<String, String> aspectLabels = {
    'fit': 'Fit',
    'fill': 'Fill',
    'stretch': 'Stretch',
  };

  static bool get hasColorChange =>
      (brightness.value - 1).abs() > 0.01 ||
      (contrast.value - 1).abs() > 0.01 ||
      (saturation.value - 1).abs() > 0.01;

  /// 4x5 colour matrix: saturation, then contrast around mid-grey, then
  /// brightness (multiplier).
  static List<double> colorMatrix() {
    final b = brightness.value;
    final c = contrast.value;
    final s = saturation.value;
    const lr = 0.2126, lg = 0.7152, lb = 0.0722;
    final k = b * c;
    final o = b * (0.5 - 0.5 * c) * 255.0;
    double r(double a) => a * k;
    return <double>[
      r(lr * (1 - s) + s), r(lg * (1 - s)), r(lb * (1 - s)), 0, o,
      r(lr * (1 - s)), r(lg * (1 - s) + s), r(lb * (1 - s)), 0, o,
      r(lr * (1 - s)), r(lg * (1 - s)), r(lb * (1 - s) + s), 0, o,
      0, 0, 0, 1, 0,
    ];
  }

  static void reset() {
    brightness.value = 1.0;
    contrast.value = 1.0;
    saturation.value = 1.0;
    asciiMode.value = false;
    asciiColor.value = true;
    vrMode.value = false;
    aspect.value = 'fit';
  }
}
