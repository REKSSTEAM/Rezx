<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

// استلام البرامترات
$action   = $_GET['action'] ?? 'home';
$provider = strtolower($_GET['provider'] ?? 'dramabox');
$page     = $_GET['page'] ?? 1;
$query    = $_GET['q'] ?? '';
$id       = $_GET['id'] ?? '';

$baseUrl = 'https://vdrama.fans/api';

// قائمة جميع المزودات الـ 17 المدعومة
$supported_providers = [
    'dramabox', 'freereels', 'shortmax', 'hishort', 'meloshort', 
    'sodareels', 'haloreels', 'netshort', 'pinedrama', 'goodshort', 
    'dramawave', 'wetv', 'flickreels', 'shortswave', 'dotdrama', 
    'bonustv', 'happyshort'
];

if (!in_array($provider, $supported_providers)) {
    $provider = 'dramabox';
}

// بناء المسار بناءً على نوع الحركة (Action)
switch ($action) {
    case 'home':
        $endpoint = "/{$provider}/list?page={$page}&limit=20";
        break;
    case 'sections':
        $endpoint = "/{$provider}/categories";
        break;
    case 'search':
        $endpoint = "/{$provider}/search?keyword=" . urlencode($query) . "&page={$page}";
        break;
    case 'detail':
        $endpoint = "/{$provider}/detail?id={$id}";
        break;
    case 'stream':
        $endpoint = "/{$provider}/stream?episode_id={$id}";
        break;
    default:
        echo json_encode(['status' => false, 'message' => 'Action غير مدعوم'], JSON_UNESCAPED_UNICODE);
        exit;
}

// تنفيذ طلب cURL المطور للحماية
$ch = curl_init();
$headers = [
    'User-Agent: Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
    'Accept: application/json, text/plain, */*',
    'Accept-Language: ar-IQ,ar;q=0.9,en-US;q=0.8',
    'Origin: https://vdrama.fans',
    'Referer: https://vdrama.fans/',
    'x-app-id: vdrama-app',
    'x-client-version: 2.1.0'
];

curl_setopt_array($ch, [
    CURLOPT_URL => $baseUrl . $endpoint,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_HTTPHEADER => $headers
]);

$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// التحقق هل الاستجابة JSON أم تم إرجاع صفحة حماية HTML
if ($httpCode !== 200 || json_decode($result) === null) {
    echo json_encode([
        'status' => false,
        'code' => $httpCode,
        'message' => 'فشل الجلب من المصدر بسبب تفعيل الحماية. يرجى إعادة محاولة الطلب.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo $result;
