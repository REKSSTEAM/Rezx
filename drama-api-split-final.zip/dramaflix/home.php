<?php
require __DIR__.'/common.php';
try { $sections=allSections(); out(array_merge(commonOptions('home.php'),['source'=>['key'=>'vdrama','name'=>'vDrama'],'sections'=>$sections])); } catch(Throwable $e) { fail('home.php',$e); }
