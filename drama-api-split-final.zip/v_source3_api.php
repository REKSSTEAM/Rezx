<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

// استلام الإجراء والبرامترات من المنصة
$action = $_GET['action'] ?? 'home';
$page   = intval($_GET['page'] ?? 1);
$query  = trim($_GET['q'] ?? '');
$id     = trim($_GET['id'] ?? '');

// السيرفر الرئيسي للمصدر الثالث
$baseUrl = 'https://vdrama.fans/api';

// بناء الرابط المناسب لكل إجراء (Action)
switch ($action) {
    case 'home':
        // قائمة الأعمال في الصفحة الرئيسية
        $endpoint = "/drama/list?page={$page}&limit=20";
        break;

    case 'sections':
        // أقسام وتصنيفات الدراما
        $endpoint = "/drama/categories";
        break;

    case 'search':
        // البحث عن عمل
        if (empty($query)) {
            echo json_encode(['status' => false, 'message' => 'يرجى إدخال كلمة البحث'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $endpoint = "/drama/search?keyword=" . urlencode($query) . "&page={$page}";
        break;

    case 'detail':
        // تفاصيل الدراما وقائمة الحلقات
        if (empty($id)) {
            echo json_encode(['status' => false, 'message' => 'معرف الدراما مطلوب'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $endpoint = "/drama/detail?drama_id=" . urlencode($id);
        break;

    case 'stream':
        // جلب رابط التشغيل والستريم المباشر للحلقة
        if (empty($id)) {
            echo json_encode(['status' => false, 'message' => 'معرف الحلقة مطلوب'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $endpoint = "/episode/stream?episode_id=" . urlencode($id);
        break;

    default:
        echo json_encode(['status' => false, 'message' => 'الإجراء غير مدعوم'], JSON_UNESCAPED_UNICODE);
        exit;
}

// تنفيذ الطلب مع التواصيف المخصصة لتجاوز حظر المتصفحات
$response = execute_source3_curl($baseUrl . $endpoint);
echo $response;

/**
 * دالة جلب البيانات الخاصة بالمصدر الثالث
 */
function execute_source3_curl($url) {
    $ch = curl_init();

    // الترويسات الخاصة بتطبيقات المصدر الثالث المأخوذة من حزم الطلبات
    $headers = [
        'User-Agent: Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
        'Accept: application/json, text/plain, */*',
        'Accept-Language: ar-IQ,ar;q=0.9,en-US;q=0.8,en;q=0.7',
        'Origin: https://vdrama.fans',
        'Referer: https://vdrama.fans/',
        'x-app-id: com.v_mps.crazymaplestudios',
        'x-client-version: 3.1.0',
        'Connection: keep-alive'
    ];

    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => $headers
    ]);

    $result   = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($result === false) {
        return json_encode([
            'status'  => false,
            'message' => 'تعذر الاتصال بالمصدر الثالث: ' . $curlErr
        ], JSON_UNESCAPED_UNICODE);
    }

    // التأكد من استلام نص JSON نقي وليس صفحة HTML أو كابتشا
    $decoded = json_decode($result, true);
    if ($httpCode !== 200 || $decoded === null) {
        return json_encode([
            'status'  => false,
            'code'    => $httpCode,
            'message' => 'فشل الجلب بسبب تفعيل حماية المصدر. أعد محاولة الطلب.'
        ], JSON_UNESCAPED_UNICODE);
    }

    return $result;
}
