import '../addon/addon.dart';
import 'movie.dart';

class MovieSection {
  final String title;
  final String subtitle;
  final String contentType;
  final String addonBaseUrl;
  final AddonCatalog catalog;
  final List<Movie> movies;

  /// Extras (e.g. {'genre': 'Action'}) pre-selected when opening See-All.
  final Map<String, String> initialExtras;

  MovieSection({
    required this.title,
    required this.subtitle,
    required this.contentType,
    required this.addonBaseUrl,
    required this.catalog,
    required this.movies,
    this.initialExtras = const {},
  });
}
