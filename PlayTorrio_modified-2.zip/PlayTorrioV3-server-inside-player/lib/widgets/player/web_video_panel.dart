import 'package:flutter/material.dart';

import '../../services/player/web_video_style.dart';
import 'web_player_panels.dart';

/// "Video" panel: Brightness / Contrast / Saturation, ASCII, VR and Aspect
/// ratio, bound to [WebVideoStyle].
class WebVideoPanel extends StatelessWidget {
  final VoidCallback onBack;
  final ValueChanged<BoxFit> onFit;

  const WebVideoPanel({super.key, required this.onBack, required this.onFit});

  Widget _slider(String label, ValueNotifier<double> n) {
    return ValueListenableBuilder<double>(
      valueListenable: n,
      builder: (context, v, _) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
        child: Row(
          children: [
            SizedBox(
              width: 130,
              child: Text(label,
                  style: const TextStyle(color: Colors.white, fontSize: 18)),
            ),
            Expanded(
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: const Color(0x66FFFFFF),
                  inactiveTrackColor: const Color(0x33FFFFFF),
                  thumbColor: Colors.white,
                  trackHeight: 4,
                ),
                child: Slider(
                  value: v.clamp(0.0, 2.0),
                  min: 0,
                  max: 2,
                  onChanged: (x) => n.value =
                      (x - 1).abs() < 0.04 ? 1.0 : x, // snaps to default
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _switch(String title, ValueNotifier<bool> n, {String? hint}) {
    return ValueListenableBuilder<bool>(
      valueListenable: n,
      builder: (context, v, _) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 12, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(title,
                      style:
                          const TextStyle(color: Colors.white, fontSize: 19)),
                ),
                Switch(
                  value: v,
                  onChanged: (x) => n.value = x,
                  thumbColor: WidgetStateProperty.resolveWith((s) =>
                      s.contains(WidgetState.selected)
                          ? Colors.black
                          : Colors.grey.shade400),
                  trackColor: WidgetStateProperty.resolveWith((s) =>
                      s.contains(WidgetState.selected)
                          ? Colors.white
                          : const Color(0xFF2A2A2A)),
                  trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
                ),
              ],
            ),
            if (hint != null)
              Text(hint,
                  style: const TextStyle(
                      color: WebPlayerColors.white45, fontSize: 15)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(title: 'Video', onBack: onBack),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 16),
            children: [
              _slider('Brightness', WebVideoStyle.brightness),
              _slider('Contrast', WebVideoStyle.contrast),
              _slider('Saturation', WebVideoStyle.saturation),
              const Divider(color: WebPlayerColors.white12, height: 28),
              _switch('ASCII Mode', WebVideoStyle.asciiMode,
                  hint: 'May cause lag on some devices.'),
              _switch('ASCII Color', WebVideoStyle.asciiColor),
              _switch('VR Mode', WebVideoStyle.vrMode,
                  hint: 'Point your phone around to look inside the video.'),
              const Padding(
                padding: EdgeInsets.fromLTRB(24, 22, 24, 6),
                child: Text('ASPECT RATIO',
                    style: TextStyle(
                        color: WebPlayerColors.white45,
                        fontSize: 15,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w700)),
              ),
              ValueListenableBuilder<String>(
                valueListenable: WebVideoStyle.aspect,
                builder: (context, cur, _) => Column(
                  children: [
                    for (final e in WebVideoStyle.aspectLabels.entries)
                      ListTile(
                        onTap: () {
                          WebVideoStyle.aspect.value = e.key;
                          onFit(WebVideoStyle.fitFor(e.key));
                        },
                        leading: Icon(
                          cur == e.key
                              ? Icons.radio_button_checked
                              : Icons.radio_button_unchecked,
                          color: Colors.white,
                        ),
                        title: Text(e.value,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 19,
                                fontWeight: cur == e.key
                                    ? FontWeight.w700
                                    : FontWeight.w400)),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                child: Material(
                  color: const Color(0xFF141414),
                  borderRadius: BorderRadius.circular(30),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(30),
                    onTap: () {
                      WebVideoStyle.reset();
                      onFit(BoxFit.contain);
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.restart_alt_rounded, color: Colors.white),
                          SizedBox(width: 12),
                          Text('Reset to Default',
                              style:
                                  TextStyle(color: Colors.white, fontSize: 18)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
