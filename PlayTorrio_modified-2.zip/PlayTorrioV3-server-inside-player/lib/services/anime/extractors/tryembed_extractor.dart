import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

class TryEmbedTrack {
  final String file;
  final String label;
  final String lang;
  final bool isDefault;

  const TryEmbedTrack({
    required this.file,
    required this.label,
    required this.lang,
    this.isDefault = false,
  });

  factory TryEmbedTrack.fromJson(Map<String, dynamic> json) {
    return TryEmbedTrack(
      file: (json['url'] ?? json['file'] ?? '').toString(),
      label: (json['label'] ?? json['title'] ?? 'Subtitles').toString(),
      lang: (json['lang'] ?? json['language'] ?? 'und').toString(),
      isDefault: json['default'] == true,
    );
  }
}

class TryEmbedQualityVariant {
  final String quality;
  final String url;

  const TryEmbedQualityVariant({required this.quality, required this.url});
}

class TryEmbedResult {
  final String url;
  final String serverName;
  final String providerId;
  final String quality;
  final bool isM3u8;
  final Map<String, String> headers;
  final List<TryEmbedTrack> tracks;
  final Map<String, dynamic>? intro;
  final Map<String, dynamic>? outro;
  final String category;

  const TryEmbedResult({
    required this.url,
    required this.serverName,
    required this.providerId,
    required this.quality,
    required this.isM3u8,
    required this.headers,
    this.tracks = const [],
    this.intro,
    this.outro,
    required this.category,
  });
}

class _TryEmbedResponse {
  final int statusCode;
  final Uri uri;
  final String body;
  final String? location;

  const _TryEmbedResponse({
    required this.statusCode,
    required this.uri,
    required this.body,
    this.location,
  });
}

class TryEmbedExtractor {
  static final TryEmbedExtractor instance = TryEmbedExtractor._internal();

  TryEmbedExtractor._internal();

  static const String baseUrl = 'https://tryembed.us.cc';
  static const String _userAgent =
      'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36';
  static const List<String> _knownProviders = ['astra', 'beta', 'sora'];

  final HttpClient _httpClient = HttpClient()
    ..connectionTimeout = const Duration(seconds: 15);

  Map<String, String> _browserHeaders({
    String accept = '*/*',
    String? referer,
  }) => {
    'User-Agent': _userAgent,
    'Accept': accept,
    'Accept-Language': 'ar-IQ,ar;q=0.9,en-IQ;q=0.8,en;q=0.7,en-US;q=0.6',
    'Origin': baseUrl,
    'Referer': referer ?? '$baseUrl/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
  };

  Map<String, String> _resolverHeaders(String embedUrl, {bool mp4 = false}) => {
    ..._browserHeaders(referer: embedUrl),
    if (mp4) 'Range': 'bytes=0-',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': mp4 ? 'no-cors' : 'cors',
    'Sec-Fetch-Dest': mp4 ? 'video' : 'empty',
  };

  /// Performs one HTTP request, retaining TryEmbed cookies and following
  /// redirects explicitly so cookies are never forwarded to a media CDN.
  Future<_TryEmbedResponse> _request(
    String method,
    Uri uri, {
    required Map<String, String> cookies,
    Map<String, String>? headers,
    String? body,
    int maxRedirects = 0,
    Duration timeout = const Duration(seconds: 25),
  }) async {
    var currentUri = uri;
    var currentMethod = method;
    var currentBody = body;
    var currentHeaders = Map<String, String>.from(
      headers ?? const <String, String>{},
    );

    for (var redirect = 0; redirect <= maxRedirects; redirect++) {
      final request = await _httpClient
          .openUrl(currentMethod, currentUri)
          .timeout(timeout);
      request.followRedirects = false;
      request.maxRedirects = 0;
      for (final entry in currentHeaders.entries) {
        request.headers.set(entry.key, entry.value);
      }
      if (_isTryEmbedHost(currentUri) && cookies.isNotEmpty) {
        request.headers.set(
          HttpHeaders.cookieHeader,
          cookies.entries
              .map((entry) => '${entry.key}=${entry.value}')
              .join('; '),
        );
      }
      if (currentBody != null) request.write(currentBody);

      final response = await request.close().timeout(timeout);
      for (final cookie in response.cookies) {
        cookies[cookie.name] = cookie.value;
      }
      final responseBody = currentMethod == 'HEAD'
          ? ''
          : await response.transform(utf8.decoder).join().timeout(timeout);
      final location = response.headers.value(HttpHeaders.locationHeader);
      if (response.isRedirect && location != null && redirect < maxRedirects) {
        if ((response.statusCode == HttpStatus.movedPermanently ||
                response.statusCode == HttpStatus.found ||
                response.statusCode == HttpStatus.seeOther) &&
            currentMethod != 'GET' &&
            currentMethod != 'HEAD') {
          currentMethod = 'GET';
          currentBody = null;
        }
        final previousUri = currentUri;
        currentUri = currentUri.resolve(location);
        if (_isTryEmbedHost(previousUri) && !_isTryEmbedHost(currentUri)) {
          // Match the PHP resolver: don't forward session cookies or fetch
          // metadata to a third-party CDN.
          currentHeaders = {
            'User-Agent': _userAgent,
            'Accept': currentHeaders['Accept'] ?? '*/*',
            'Origin': baseUrl,
            'Referer': '$baseUrl/',
          };
        }
        continue;
      }

      return _TryEmbedResponse(
        statusCode: response.statusCode,
        uri: currentUri,
        body: responseBody,
        location: location,
      );
    }

    throw const HttpException('Too many redirects while contacting TryEmbed.');
  }

  bool _isTryEmbedHost(Uri uri) => uri.host == Uri.parse(baseUrl).host;

  Map<String, dynamic>? _asMap(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) {
      return value.map((key, value) => MapEntry(key.toString(), value));
    }
    return null;
  }

  List<Map<String, dynamic>> _asMapList(dynamic value) {
    final entries = value is List
        ? value
        : value is Map
        ? value.values.toList()
        : const <dynamic>[];
    return entries.map(_asMap).whereType<Map<String, dynamic>>().toList();
  }

  Map<String, dynamic>? _decodeJsonMap(String body) {
    try {
      return _asMap(jsonDecode(body));
    } on FormatException catch (error) {
      if (kDebugMode) debugPrint('[TryEmbed] Invalid JSON response: $error');
      return null;
    }
  }

  String _providerKey(Map<String, dynamic> provider) {
    final id =
        (provider['id'] ?? provider['provider'] ?? provider['providerId'] ?? '')
            .toString()
            .trim()
            .toLowerCase();
    if (id.isNotEmpty) return id;
    final name = (provider['name'] ?? 'server').toString().trim().toLowerCase();
    return name.replaceAll(RegExp(r'[^a-z0-9]+'), '_');
  }

  List<Map<String, dynamic>> _qualitiesOf(Map<String, dynamic> provider) =>
      _asMapList(provider['qualities']);

  void _mergeProvider(
    Map<String, Map<String, dynamic>> providers,
    Map<String, dynamic> incoming,
  ) {
    final id = _providerKey(incoming);
    final previous = providers[id];
    final merged = <String, dynamic>{...?previous, ...incoming};

    final qualityMap = <String, Map<String, dynamic>>{};
    for (final quality in [
      ..._qualitiesOf(previous ?? const <String, dynamic>{}),
      ..._qualitiesOf(incoming),
    ]) {
      final token =
          (quality['token'] ?? quality['url'] ?? quality['directUrl'] ?? '')
              .toString()
              .trim();
      final key = token.isNotEmpty
          ? token
          : (quality['name'] ?? jsonEncode(quality)).toString();
      qualityMap[key] = {...?qualityMap[key], ...quality};
    }
    if (qualityMap.isNotEmpty) {
      merged['qualities'] = qualityMap.values.toList(growable: false);
    }

    final oldCaptions = previous == null
        ? const <Map<String, dynamic>>[]
        : _asMapList(previous['captions']);
    final newCaptions = _asMapList(incoming['captions']);
    final captions = <String, Map<String, dynamic>>{};
    for (final caption in [...oldCaptions, ...newCaptions]) {
      final key =
          '${caption['lang'] ?? caption['language'] ?? ''}|'
          '${caption['url'] ?? caption['file'] ?? ''}';
      captions[key] = caption;
    }
    if (captions.isNotEmpty) merged['captions'] = captions.values.toList();
    providers[id] = merged;
  }

  void _mergeProviderList(
    Map<String, Map<String, dynamic>> providers,
    dynamic value,
  ) {
    for (final provider in _asMapList(value)) {
      _mergeProvider(providers, provider);
    }
  }

  Future<Map<String, dynamic>?> _switchProvider({
    required int anilistId,
    required int episodeNumber,
    required String category,
    required String provider,
    required String nonce,
    required String embedUrl,
    required Map<String, String> cookies,
  }) async {
    final uri = Uri.parse('$baseUrl/api/stream_data').replace(
      queryParameters: {
        'id': '$anilistId',
        'episode': '$episodeNumber',
        'audio': category,
        'player': 'jw',
        'server': provider,
        'nonce': nonce,
      },
    );
    final response = await _request(
      'GET',
      uri,
      cookies: cookies,
      headers: {
        ..._browserHeaders(referer: embedUrl),
        'X-Embed-Nonce': nonce,
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
      },
      timeout: const Duration(seconds: 25),
    );
    if (response.statusCode != HttpStatus.ok) {
      if (kDebugMode) {
        debugPrint(
          '[TryEmbed] Provider switch $provider returned ${response.statusCode}',
        );
      }
      return null;
    }
    return _decodeJsonMap(response.body);
  }

  /// Fetches every available TryEmbed provider, each HLS/MP4 quality, and the
  /// captions attached globally or to an individual provider.
  Future<List<TryEmbedResult>> extractAll({
    required int anilistId,
    required int episodeNumber,
    required String category,
  }) async {
    final results = <TryEmbedResult>[];
    if (anilistId <= 0 || episodeNumber <= 0) return results;

    final audio = category.toLowerCase() == 'dub' ? 'dub' : 'sub';
    final embedUrl =
        '$baseUrl/embed/anime/$anilistId/$episodeNumber/$audio?skin=jw';
    final cookies = <String, String>{};

    try {
      final embedPage = await _request(
        'GET',
        Uri.parse(embedUrl),
        cookies: cookies,
        headers: {
          ..._browserHeaders(
            accept:
                'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            referer: '$baseUrl/',
          ),
          'Upgrade-Insecure-Requests': '1',
          'Sec-Fetch-Site': 'same-origin',
          'Sec-Fetch-Mode': 'navigate',
          'Sec-Fetch-User': '?1',
          'Sec-Fetch-Dest': 'iframe',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
        },
        maxRedirects: 5,
      );
      if (embedPage.statusCode != HttpStatus.ok) {
        if (kDebugMode) {
          debugPrint('[TryEmbed] Embed page returned ${embedPage.statusCode}');
        }
        return results;
      }

      final ticket = RegExp(
        r'''window\.BOOTSTRAP_TICKET\s*=\s*["']([^"']+)["']''',
      ).firstMatch(embedPage.body)?.group(1);
      if (ticket == null || ticket.isEmpty) {
        if (kDebugMode)
          debugPrint('[TryEmbed] Bootstrap ticket was not found.');
        return results;
      }

      final bootstrapResponse = await _request(
        'POST',
        Uri.parse('$baseUrl/api/bootstrap'),
        cookies: cookies,
        headers: {
          ..._browserHeaders(referer: embedUrl),
          'Content-Type': 'application/json',
          'X-TryEmbed-Bootstrap': ticket,
          'X-Embed-Nonce': '',
          'X-Requested-With': 'XMLHttpRequest',
          'Sec-Fetch-Site': 'same-origin',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Dest': 'empty',
        },
        body: '',
      );
      if (bootstrapResponse.statusCode != HttpStatus.ok) {
        if (kDebugMode) {
          debugPrint(
            '[TryEmbed] Bootstrap returned ${bootstrapResponse.statusCode}: '
            '${bootstrapResponse.body.substring(0, bootstrapResponse.body.length.clamp(0, 160))}',
          );
        }
        return results;
      }

      final bootstrap = _decodeJsonMap(bootstrapResponse.body);
      if (bootstrap == null) return results;
      var nonce = (bootstrap['embedNonce'] ?? '').toString();
      final providers = <String, Map<String, dynamic>>{};
      _mergeProviderList(providers, bootstrap['providers']);

      final selectedProvider = _asMap(bootstrap['selectedProvider']);
      if (selectedProvider != null) {
        _mergeProvider(providers, selectedProvider);
      }

      // TryEmbed's stream_data endpoint returns provider-specific results when
      // `server` is selected. Query each supported server in the same session;
      // otherwise the bootstrap list may omit Sora (or provider qualities).
      for (final providerId in _knownProviders) {
        try {
          final switched = await _switchProvider(
            anilistId: anilistId,
            episodeNumber: episodeNumber,
            category: audio,
            provider: providerId,
            nonce: nonce,
            embedUrl: embedUrl,
            cookies: cookies,
          );
          if (switched == null) continue;
          final updatedNonce = (switched['embedNonce'] ?? '').toString();
          if (updatedNonce.isNotEmpty) nonce = updatedNonce;
          _mergeProviderList(providers, switched['providers']);
          final switchedSelection = _asMap(switched['selectedProvider']);
          if (switchedSelection != null) {
            _mergeProvider(providers, {
              ...switchedSelection,
              'id': switchedSelection['id'] ?? providerId,
            });
          }
        } catch (error) {
          if (kDebugMode) {
            debugPrint('[TryEmbed] Could not switch to $providerId: $error');
          }
        }
      }

      final providerEntries = providers.entries.toList()
        ..sort((left, right) {
          int order(String id) {
            final index = _knownProviders.indexOf(id);
            return index < 0 ? _knownProviders.length : index;
          }

          return order(left.key).compareTo(order(right.key));
        });

      final globalTracks = <TryEmbedTrack>[];
      _appendTracks(globalTracks, bootstrap['captions'], embedUrl);
      if (selectedProvider != null) {
        _appendTracks(globalTracks, selectedProvider['captions'], embedUrl);
      }
      for (final entry in providerEntries) {
        _appendTracks(globalTracks, entry.value['captions'], embedUrl);
      }
      final intro = _validMarker(bootstrap['intro']);
      final outro = _validMarker(bootstrap['outro']);
      final headers = Map<String, String>.unmodifiable(
        _browserHeaders(referer: embedUrl),
      );
      final seenResults = <String>{};

      for (final entry in providerEntries) {
        final provider = entry.value;
        final providerId = entry.key;
        final serverName = (provider['name'] ?? providerId).toString();
        final providerType = (provider['type'] ?? '').toString().toLowerCase();
        final providerTracks = <TryEmbedTrack>[];
        _appendTracks(providerTracks, provider['captions'], embedUrl);
        final tracks = _dedupeTracks([...globalTracks, ...providerTracks]);

        for (final qualityData in _qualitiesOf(provider)) {
          final token = (qualityData['token'] ?? '').toString().trim();
          final directUrl =
              (qualityData['directUrl'] ?? qualityData['url'] ?? '')
                  .toString()
                  .trim();
          if (token.isEmpty && directUrl.isEmpty) continue;

          final rawQuality = (qualityData['name'] ?? 'Auto').toString().trim();
          final isMp4 =
              providerType == 'mp4' ||
              providerId == 'sora' ||
              (qualityData['type'] ?? '').toString().toLowerCase() == 'mp4';

          try {
            if (isMp4) {
              final mediaUri = directUrl.isNotEmpty
                  ? Uri.parse(directUrl)
                  : Uri.parse('$baseUrl/s/${Uri.encodeComponent(token)}.mp4');
              final media = await _request(
                'HEAD',
                mediaUri,
                cookies: cookies,
                headers: _resolverHeaders(embedUrl, mp4: true),
                maxRedirects: 5,
              );
              if (media.statusCode != HttpStatus.ok &&
                  media.statusCode != HttpStatus.partialContent &&
                  media.statusCode != HttpStatus.found &&
                  media.statusCode != HttpStatus.temporaryRedirect) {
                if (kDebugMode) {
                  debugPrint(
                    '[TryEmbed] MP4 resolve failed for $serverName/${rawQuality}: '
                    '${media.statusCode}',
                  );
                }
                continue;
              }
              final quality = _qualityLabel(rawQuality);
              final resultKey = '$providerId|$audio|$quality|${media.uri}';
              if (seenResults.add(resultKey)) {
                results.add(
                  TryEmbedResult(
                    url: media.uri.toString(),
                    serverName: serverName,
                    providerId: providerId,
                    quality: quality,
                    isM3u8: false,
                    headers: headers,
                    tracks: tracks,
                    intro: intro,
                    outro: outro,
                    category: audio,
                  ),
                );
              }
              continue;
            }

            final playlistUri = directUrl.isNotEmpty
                ? Uri.parse(directUrl)
                : Uri.parse('$baseUrl/s/${Uri.encodeComponent(token)}.m3u8');
            final playlist = await _request(
              'GET',
              playlistUri,
              cookies: cookies,
              headers: _resolverHeaders(embedUrl),
              maxRedirects: 5,
            );
            if (playlist.statusCode != HttpStatus.ok) {
              if (kDebugMode) {
                debugPrint(
                  '[TryEmbed] HLS resolve failed for $serverName/$rawQuality: '
                  '${playlist.statusCode}',
                );
              }
              continue;
            }

            final variants = parseHlsVariants(playlist.body, playlist.uri);
            final choices = variants.isEmpty
                ? [
                    TryEmbedQualityVariant(
                      quality: _qualityLabel(rawQuality),
                      url: playlist.uri.toString(),
                    ),
                  ]
                : variants;
            for (final choice in choices) {
              final resultKey =
                  '$providerId|$audio|${choice.quality}|${choice.url}';
              if (!seenResults.add(resultKey)) continue;
              results.add(
                TryEmbedResult(
                  url: choice.url,
                  serverName: serverName,
                  providerId: providerId,
                  quality: choice.quality,
                  isM3u8: true,
                  headers: headers,
                  tracks: tracks,
                  intro: intro,
                  outro: outro,
                  category: audio,
                ),
              );
            }
          } catch (error) {
            if (kDebugMode) {
              debugPrint(
                '[TryEmbed] Quality resolve failed for $serverName/$rawQuality: $error',
              );
            }
          }
        }
      }
    } catch (error) {
      if (kDebugMode) debugPrint('[TryEmbed] Extraction error: $error');
    }
    return results;
  }

  void _appendTracks(
    List<TryEmbedTrack> output,
    dynamic rawTracks,
    String embedUrl,
  ) {
    if (rawTracks is! List) return;
    for (final rawTrack in rawTracks) {
      final map = _asMap(rawTrack);
      if (map == null) continue;
      final track = TryEmbedTrack.fromJson(map);
      if (track.file.isEmpty) continue;
      final uri = Uri.tryParse(track.file);
      final file = uri != null && uri.hasScheme
          ? track.file
          : Uri.parse(embedUrl).resolve(track.file).toString();
      output.add(
        TryEmbedTrack(
          file: file,
          label: track.label,
          lang: track.lang,
          isDefault: track.isDefault,
        ),
      );
    }
  }

  List<TryEmbedTrack> _dedupeTracks(List<TryEmbedTrack> tracks) {
    final seen = <String>{};
    return tracks
        .where((track) => seen.add('${track.lang.toLowerCase()}|${track.file}'))
        .toList(growable: false);
  }

  Map<String, dynamic>? _validMarker(dynamic raw) {
    final map = _asMap(raw);
    if (map == null) return null;
    final start = map['start'];
    final end = map['end'];
    if (start is num && end is num && end > start) {
      return {'start': start, 'end': end};
    }
    return null;
  }

  static String _qualityLabel(String preferred, {String? resolution}) {
    final dimension = RegExp(
      r'(\d{2,5})\s*x\s*(\d{2,5})',
      caseSensitive: false,
    ).firstMatch(resolution ?? '');
    if (dimension != null) return '${dimension.group(2)}p';
    final named = RegExp(
      r'\b(\d{3,4})\s*p\b',
      caseSensitive: false,
    ).firstMatch(preferred);
    if (named != null) return '${named.group(1)}p';
    return preferred.isEmpty ? 'Auto' : preferred;
  }

  @visibleForTesting
  static List<TryEmbedQualityVariant> parseHlsVariants(
    String playlist,
    Uri playlistUri,
  ) {
    final lines = playlist.split(RegExp(r'\r\n|\r|\n'));
    final variants = <TryEmbedQualityVariant>[];
    final seen = <String>{};
    for (var index = 0; index < lines.length; index++) {
      final line = lines[index].trim();
      if (!line.startsWith('#EXT-X-STREAM-INF:')) continue;
      final resolution = RegExp(
        r'RESOLUTION\s*=\s*(\d+\s*x\s*\d+)',
        caseSensitive: false,
      ).firstMatch(line)?.group(1);
      final namedQuality = RegExp(
        r'NAME\s*=\s*"?([^,"]+)"?',
        caseSensitive: false,
      ).firstMatch(line)?.group(1)?.trim();

      String? child;
      for (var next = index + 1; next < lines.length; next++) {
        final candidate = lines[next].trim();
        if (candidate.isEmpty) continue;
        if (candidate.startsWith('#')) continue;
        child = candidate;
        index = next;
        break;
      }
      if (child == null) continue;

      final childUri = playlistUri.resolve(child);
      final fallback = namedQuality?.isNotEmpty == true
          ? namedQuality!
          : 'Auto';
      final quality = _qualityLabel(fallback, resolution: resolution);
      if (seen.add(childUri.toString())) {
        variants.add(
          TryEmbedQualityVariant(quality: quality, url: childUri.toString()),
        );
      }
    }
    return variants;
  }
}
