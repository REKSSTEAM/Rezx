import 'package:flutter_test/flutter_test.dart';
import 'package:playtorrio/services/anime/extractors/tryembed_extractor.dart';

void main() {
  group('TryEmbed quality parsing', () {
    test('extracts all resolutions and resolves relative playlist URLs', () {
      const master = '''#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=5800000,RESOLUTION=1920x1080
1080/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1280x720
../720/index.m3u8
''';

      final variants = TryEmbedExtractor.parseHlsVariants(
        master,
        Uri.parse('https://cdn.example/anime/master.m3u8'),
      );

      expect(variants, hasLength(2));
      expect(variants[0].quality, '1080p');
      expect(variants[0].url, 'https://cdn.example/anime/1080/index.m3u8');
      expect(variants[1].quality, '720p');
      expect(variants[1].url, 'https://cdn.example/720/index.m3u8');
    });

    test('uses playlist names when resolution metadata is absent', () {
      const master = '''#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=1200000,NAME="480p"
480.m3u8
''';

      final variants = TryEmbedExtractor.parseHlsVariants(
        master,
        Uri.parse('https://cdn.example/master.m3u8'),
      );

      expect(variants, hasLength(1));
      expect(variants.single.quality, '480p');
      expect(variants.single.url, 'https://cdn.example/480.m3u8');
    });
  });

  test('reads TryEmbed caption labels, language, URL, and default flag', () {
    final track = TryEmbedTrack.fromJson({
      'url': 'https://subs.example/episode.vtt',
      'label': 'Arabic',
      'lang': 'ar',
      'default': true,
    });

    expect(track.file, 'https://subs.example/episode.vtt');
    expect(track.label, 'Arabic');
    expect(track.lang, 'ar');
    expect(track.isDefault, isTrue);
  });
}
