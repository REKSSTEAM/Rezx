import 'dart:async';
import 'dart:ui';

import 'package:better_player_plus/better_player_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/download/download_task_model.dart';
import '../../models/movie/video.dart';
import '../../models/stream/stream_model.dart';
import '../../services/download/download_service.dart';
import '../../services/player/watch_party_service.dart';
import '../../models/subtitle/subtitle_model.dart';
import '../../services/subtitles/subtitle_parser.dart';
import 'web_subtitle_overlay.dart';
import 'web_video_effects.dart';
import 'web_video_panel.dart';
import '../../services/player/web_video_style.dart';
import 'sub_sync_bar.dart';
import 'web_player_panels.dart';

enum _Panel { none, main, sources, subtitles, download, speed, quality, episodes, party, video }

/// Controls laid out exactly like the web player (index.html):
///
///   top bar     : back · title · episode badge ······················ download
///   seek row    : current time · [──────────seek bar──────────] · duration
///   bottom row  : play · time ·················· subtitles · episodes · pip · settings · fullscreen
///
/// The settings button opens a centered dialog with 4 tiles (Quality / Source /
/// Subtitles / Speed), the Download row and a separate Close pill. Episodes
/// opens the same kind of dialog (seasons list -> episodes list).
///
/// Plug it in through BetterPlayerControlsConfiguration.customControlsBuilder.
class WebStyleControls extends StatefulWidget {
  final BetterPlayerController controller;
  final void Function(bool)? onVisibilityChanged;

  final String title;
  final String? episodeBadge;
  final VoidCallback onBack;

  // Servers
  final Listenable sourcesRefresh;
  final List<StreamSource> Function() getSources;
  final StreamSource? Function() getCurrentSource;
  final bool Function() isDiscovering;
  final String Function(StreamSource) providerOf;
  final String Function(StreamSource) labelOf;
  final bool Function(StreamSource) isTorrent;
  final ValueChanged<StreamSource> onSelectSource;

  // Subtitles
  final Future<List<SubtitleLanguageGroup>> Function() loadSubtitles;
  final ValueChanged<SubtitleVariant> onPickSubtitle;
  final VoidCallback onSubtitleOff;
  final VoidCallback onAutoSubtitle;
  final ValueChanged<double> onSubtitleDelay;
  final List<SubCue>? Function() getSubtitleCues;
  final String? Function() activeSubtitleLabel;

  // Download
  final String mediaId; // id used by the PHP site (tmdb id)
  final String downloadMediaId; // id stored on in-app download tasks
  final int? season;
  final int? episode;
  final VoidCallback onSaveCurrent;

  // Seasons / episodes (empty list = movie, no episodes button)
  final List<Video> episodes;
  final Video? currentEpisode;
  final ValueChanged<Video> onSelectEpisode;

  // Watch party
  final WatchPartyService party;
  final String mediaType; // 'movie' | 'tv'
  final String Function() currentVideoUrl;

  const WebStyleControls({
    super.key,
    required this.controller,
    required this.onVisibilityChanged,
    required this.title,
    required this.episodeBadge,
    required this.onBack,
    required this.sourcesRefresh,
    required this.getSources,
    required this.getCurrentSource,
    required this.isDiscovering,
    required this.providerOf,
    required this.labelOf,
    required this.isTorrent,
    required this.onSelectSource,
    required this.loadSubtitles,
    required this.onPickSubtitle,
    required this.onSubtitleOff,
    required this.onAutoSubtitle,
    required this.onSubtitleDelay,
    required this.getSubtitleCues,
    required this.activeSubtitleLabel,
    required this.mediaId,
    required this.downloadMediaId,
    required this.season,
    required this.episode,
    required this.onSaveCurrent,
    required this.episodes,
    required this.currentEpisode,
    required this.onSelectEpisode,
    required this.party,
    required this.mediaType,
    required this.currentVideoUrl,
  });

  @override
  State<WebStyleControls> createState() => _WebStyleControlsState();
}

double _clampD(double v, double lo, double hi) => v < lo ? lo : (v > hi ? hi : v);

class _WebStyleControlsState extends State<WebStyleControls> {
  static const String _delayKey = 'subDelay'; // same key name as the web player

  // The video controller type comes from BetterPlayer's bundled video_player;
  // it is used dynamically so this file does not depend on that export.
  dynamic _vp;
  Timer? _hideTimer;
  bool _visible = true;
  _Panel _panel = _Panel.none;
  bool _showSyncBar = false;
  double _subDelay = 0;
  bool _dragging = false;
  double _dragMs = 0;
  double _speed = 1.0;
  bool _muted = false;
  double _lastVolume = 1.0;

  // Swipe gestures kept from the old BetterPlayer controls:
  // left side = brightness, right side = volume, horizontal = seek.
  // Brightness is a software dimmer (no extra plugin needed).
  static double _brightnessMemory = 1.0;
  double _brightness = _brightnessMemory;
  Offset _panStart = Offset.zero;
  String? _panKind; // 'b' | 'v' | 's' | 'x' (ignored)
  double _panStartValue = 0;
  double _seekPreviewMs = 0;
  IconData? _hudIcon;
  String? _hudText;
  Timer? _hudTimer;

  bool get _locked => widget.party.isLocked;

  @override
  void initState() {
    super.initState();
    _vp = widget.controller.videoPlayerController;
    _vp?.addListener(_tick);
    widget.party.addListener(_tick);
    _restoreDelay();
    _scheduleHide();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _hudTimer?.cancel();
    widget.party.removeListener(_tick);
    try {
      _vp?.removeListener(_tick);
    } catch (_) {}
    super.dispose();
  }

  Future<void> _restoreDelay() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = double.tryParse(prefs.getString(_delayKey) ?? '') ?? 0;
    if (!mounted) return;
    setState(() => _subDelay = saved);
    if (saved != 0) widget.onSubtitleDelay(saved);
  }

  Future<void> _saveDelay(double v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_delayKey, v.toStringAsFixed(1));
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  // ── visibility ────────────────────────────────────────────────────────
  void _setVisible(bool v) {
    if (_visible == v) return;
    setState(() => _visible = v);
    widget.onVisibilityChanged?.call(v);
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (!mounted || _panel != _Panel.none || _dragging) return;
      if (_vp?.value.isPlaying == true) _setVisible(false);
    });
  }

  void _toggleVisible() {
    if (_panel != _Panel.none) {
      setState(() => _panel = _Panel.none);
      return;
    }
    _setVisible(!_visible);
    if (_visible) _scheduleHide();
  }

  // ── helpers ───────────────────────────────────────────────────────────
  Duration get _position => (_vp?.value.position as Duration?) ?? Duration.zero;
  Duration get _duration => (_vp?.value.duration as Duration?) ?? Duration.zero;
  bool get _playing => _vp?.value.isPlaying == true;

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(h > 0 ? 2 : 1, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  void _seekBy(int seconds) {
    if (_locked) return;
    final target = _position + Duration(seconds: seconds);
    final max = _duration;
    final clamped = target < Duration.zero
        ? Duration.zero
        : (max > Duration.zero && target > max ? max : target);
    widget.controller.seekTo(clamped);
    _scheduleHide();
  }

  void _togglePlay() {
    if (_locked) return;
    if (_playing) {
      widget.controller.pause();
    } else {
      widget.controller.play();
    }
    _scheduleHide();
  }

  Future<void> _pip() async {
    try {
      final key = widget.controller.betterPlayerGlobalKey;
      if (key != null) await widget.controller.enablePictureInPicture(key);
    } catch (_) {}
  }

  void _openPanel(_Panel p) {
    HapticFeedback.selectionClick();
    _hideTimer?.cancel();
    setState(() {
      _panel = p;
      _visible = true;
    });
  }

  void _showHud(IconData icon, String text) {
    _hudTimer?.cancel();
    setState(() {
      _hudIcon = icon;
      _hudText = text;
    });
    _hudTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _hudText = null);
    });
  }

  void _onPanStart(DragStartDetails d) {
    _panStart = d.localPosition;
    _panKind = null;
  }

  void _onPanUpdate(DragUpdateDetails d, Size size) {
    final dx = d.localPosition.dx - _panStart.dx;
    final dy = d.localPosition.dy - _panStart.dy;
    if (_panKind == null) {
      if (dx.abs() < 14 && dy.abs() < 14) return;
      if (dx.abs() > dy.abs()) {
        _panKind = _locked ? 'x' : 's';
        _panStartValue = _position.inMilliseconds.toDouble();
      } else if (_panStart.dx < size.width / 2) {
        _panKind = 'b';
        _panStartValue = _brightness;
      } else {
        _panKind = 'v';
        _panStartValue =
            _muted ? 0.0 : ((_vp?.value.volume as double?) ?? 1.0);
      }
    }
    final kind = _panKind;
    if (kind == 'b') {
      final v = _clampD(_panStartValue - dy / (size.height * 0.7), 0.0, 1.0);
      _brightnessMemory = v;
      setState(() => _brightness = v);
      _showHud(Icons.brightness_6_rounded, '${(v * 100).round()}%');
    } else if (kind == 'v') {
      final v = _clampD(_panStartValue - dy / (size.height * 0.7), 0.0, 1.0);
      widget.controller.setVolume(v);
      if (v > 0) _lastVolume = v;
      _muted = v == 0;
      _showHud(
        v == 0 ? Icons.volume_off_rounded : Icons.volume_up_rounded,
        '${(v * 100).round()}%',
      );
    } else if (kind == 's') {
      final total = _duration.inMilliseconds.toDouble();
      _seekPreviewMs = _clampD(
        _panStartValue + dx / size.width * 90000,
        0.0,
        total > 0 ? total : 0.0,
      );
      _showHud(
        Icons.fast_forward_rounded,
        _fmt(Duration(milliseconds: _seekPreviewMs.toInt())),
      );
    }
  }

  void _onPanEnd(DragEndDetails d) {
    if (_panKind == 's') {
      widget.controller.seekTo(Duration(milliseconds: _seekPreviewMs.toInt()));
    }
    _panKind = null;
    _scheduleHide();
  }

  void _onDelay(double v) {
    setState(() => _subDelay = v);
    _saveDelay(v);
    widget.onSubtitleDelay(v);
  }

  // ── build ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final size = MediaQuery.sizeOf(context);
    return Stack(
      fit: StackFit.expand,
      children: [
        // Brightness / contrast / saturation / VR applied to the video.
        const Positioned.fill(child: WebVideoEffects()),
        // Tap / double-tap / swipe layer (double tap left/right = ∓10s).
        Positioned.fill(
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: _toggleVisible,
            onDoubleTapDown: (d) {
              _seekBy(d.localPosition.dx < width / 2 ? -10 : 10);
            },
            onDoubleTap: () {},
            onPanStart: _onPanStart,
            onPanUpdate: (d) => _onPanUpdate(d, size),
            onPanEnd: _onPanEnd,
          ),
        ),
        // Software brightness dimmer.
        Positioned.fill(
          child: IgnorePointer(
            child: ColoredBox(
              color: Colors.black.withValues(alpha: (1 - _brightness) * 0.85),
            ),
          ),
        ),
        // Custom subtitle overlay (all Customize Subtitles options).
        Positioned.fill(
          child: WebSubtitleOverlay(
            getCues: widget.getSubtitleCues,
            getPosition: () => _position,
          ),
        ),
        AnimatedOpacity(
          opacity: _visible ? 1 : 0,
          duration: const Duration(milliseconds: 180),
          child: IgnorePointer(
            ignoring: !_visible,
            // Compact mode when the player box is short (portrait, not
            // fullscreen) so the bars never overflow.
            child: LayoutBuilder(
              builder: (context, box) {
                final compact = box.maxHeight < 300;
                return Column(
                  children: [
                    _buildTopBar(context, compact),
                    const Spacer(),
                    _buildBottom(context, width, compact),
                  ],
                );
              },
            ),
          ),
        ),
        if (_hudText != null)
          Center(
            child: IgnorePointer(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xB3000000),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(_hudIcon, color: Colors.white, size: 22),
                    const SizedBox(width: 8),
                    Text(
                      _hudText!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        if (_showSyncBar)
          Positioned(
            left: 0,
            right: 0,
            bottom: 96,
            child: SubSyncBar(
              delaySec: _subDelay,
              onDelayChanged: _onDelay,
              isTextSyncAvailable: false,
              onClose: () => setState(() => _showSyncBar = false),
              onSave: () => _saveDelay(_subDelay),
            ),
          ),
        if (_panel != _Panel.none) ...[
          Positioned.fill(
            child: GestureDetector(
              onTap: () => setState(() => _panel = _Panel.none),
              child: Container(color: Colors.black54),
            ),
          ),
          Positioned.fill(child: _buildDialog(context, size)),
        ],
      ],
    );
  }

  // Centered dialog (+ separate "Close" pill underneath) shared by every panel.
  Widget _buildDialog(BuildContext context, Size size) {
    final pad = MediaQuery.paddingOf(context);
    final dialogW = size.width < 520
        ? size.width * 0.92
        : _clampD(size.width * 0.667, 420.0, 640.0);
    const closeH = 52.0;
    const gap = 12.0;
    final maxDialogH = size.height - pad.top - pad.bottom - 16 - closeH - gap;
    final dialogH = _clampD(
      size.height * 0.70,
      120.0,
      maxDialogH < 120 ? 120.0 : maxDialogH,
    );
    const bg = Color(0xF2080808);
    final radius = BorderRadius.circular(22);

    final Widget body = _panel == _Panel.episodes
        ? _EpisodesDialogBody(
            title: widget.title,
            videos: widget.episodes,
            current: widget.currentEpisode,
            onClose: () => setState(() => _panel = _Panel.none),
            onSelect: (v) {
              if (_locked) return;
              setState(() => _panel = _Panel.none);
              widget.onSelectEpisode(v);
            },
          )
        : _buildPanel();

    return Center(
      child: SizedBox(
        width: dialogW,
        height: dialogH + gap + closeH,
        child: Column(
          children: [
            SizedBox(
              height: dialogH,
              child: ClipRRect(
                borderRadius: radius,
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: Container(
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: radius,
                      border: Border.all(color: WebPlayerColors.white12),
                    ),
                    child: Material(
                      type: MaterialType.transparency,
                      child: body,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: gap),
            SizedBox(
              height: closeH,
              width: double.infinity,
              child: Material(
                color: bg,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(26),
                  side: const BorderSide(color: WebPlayerColors.white12),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(26),
                  onTap: () => setState(() => _panel = _Panel.none),
                  child: const Center(
                    child: Text(
                      'Close',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _iconBtn(
    IconData icon,
    VoidCallback onTap, {
    String? tooltip,
    double size = 24,
    Color color = Colors.white,
  }) {
    return IconButton(
      onPressed: onTap,
      tooltip: tooltip,
      icon: Icon(icon, color: color, size: size),
      visualDensity: VisualDensity.compact,
    );
  }

  bool _matchesTask(DownloadTask t) =>
      t.mediaId == widget.downloadMediaId &&
      t.season == widget.season &&
      t.episode == widget.episode;

  // Top bar: back · title · episode badge ······ download
  Widget _buildTopBar(BuildContext context, bool compact) {
    // The status-bar inset only matters when the player really is fullscreen.
    final topInset =
        widget.controller.isFullScreen ? MediaQuery.paddingOf(context).top : 0.0;
    return Container(
      padding: EdgeInsets.fromLTRB(
        8,
        topInset + (compact ? 0 : 6),
        8,
        compact ? 6 : 22,
      ),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xB3000000), Colors.transparent],
        ),
      ),
      child: Row(
        children: [
          _iconBtn(Icons.arrow_back_rounded, widget.onBack, tooltip: 'Back'),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              widget.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          if (widget.episodeBadge != null) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: WebPlayerColors.white12,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                widget.episodeBadge!,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
          const Spacer(),
          ValueListenableBuilder<List<DownloadTask>>(
            valueListenable: DownloadService.instance.tasksNotifier,
            builder: (context, tasks, _) {
              DownloadTask? active;
              for (final t in tasks) {
                if (_matchesTask(t) && t.isDownloading) active = t;
              }
              return IconButton(
                onPressed: () => _openPanel(_Panel.download),
                tooltip: 'Download',
                visualDensity: VisualDensity.compact,
                icon: active == null
                    ? const Icon(
                        Icons.file_download_outlined,
                        color: Colors.white,
                        size: 24,
                      )
                    : SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.4,
                          value: active.progressPercent > 0
                              ? active.progressPercent
                              : null,
                          color: WebPlayerColors.online,
                        ),
                      ),
              );
            },
          ),
        ],
      ),
    );
  }

  // Seek row + control row
  Widget _buildBottom(BuildContext context, double width, bool compact) {
    final bottomInset =
        widget.controller.isFullScreen ? MediaQuery.paddingOf(context).bottom : 0.0;
    final dur = _duration;
    final totalMs = dur.inMilliseconds.toDouble();
    final maxMs = totalMs > 0 ? totalMs : 1.0;
    final double posMs = _dragging
        ? _dragMs
        : _clampD(_position.inMilliseconds.toDouble(), 0.0, maxMs);
    double bufferedMs = 0;
    try {
      final ranges = _vp?.value.buffered as List?;
      if (ranges != null && ranges.isNotEmpty) {
        bufferedMs = (ranges.last.end as Duration).inMilliseconds.toDouble();
      }
    } catch (_) {}
    final showEpisodesLabel = width >= 640;

    return Container(
      padding: EdgeInsets.fromLTRB(
        14,
        compact ? 8 : 26,
        14,
        bottomInset + (compact ? 2 : 8),
      ),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Color(0xD9000000), Color(0x73000000), Colors.transparent],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // seek row: current · track · duration
          Row(
            children: [
              Text(
                _fmt(_dragging ? Duration(milliseconds: posMs.toInt()) : _position),
                style: const TextStyle(color: Colors.white, fontSize: 11),
              ),
              Expanded(
                child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 4,
                    thumbShape: const RoundSliderThumbShape(
                      enabledThumbRadius: 6,
                    ),
                    overlayShape: const RoundSliderOverlayShape(
                      overlayRadius: 14,
                    ),
                    activeTrackColor: Colors.white,
                    inactiveTrackColor: WebPlayerColors.white12,
                    secondaryActiveTrackColor: const Color(0x55FFFFFF),
                    thumbColor: Colors.white,
                  ),
                  child: Slider(
                    min: 0,
                    max: maxMs,
                    value: _clampD(posMs, 0.0, maxMs),
                    secondaryTrackValue: _clampD(bufferedMs, 0.0, maxMs),
                    onChangeStart: (v) {
                      _hideTimer?.cancel();
                      setState(() {
                        _dragging = true;
                        _dragMs = v;
                      });
                    },
                    onChanged: (v) => setState(() => _dragMs = v),
                    onChangeEnd: (v) {
                      if (!_locked) {
                        widget.controller.seekTo(Duration(milliseconds: v.toInt()));
                      }
                      setState(() => _dragging = false);
                      _scheduleHide();
                    },
                  ),
                ),
              ),
              Text(
                _fmt(dur),
                style: const TextStyle(color: Colors.white, fontSize: 11),
              ),
            ],
          ),
          // control row: [play · time] ············ [subs · episodes · pip · settings · fullscreen]
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    _iconBtn(
                      _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      _togglePlay,
                      size: 34,
                    ),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: _fmt(
                                _dragging
                                    ? Duration(milliseconds: posMs.toInt())
                                    : _position,
                              ),
                            ),
                            const TextSpan(
                              text: ' / ',
                              style: TextStyle(color: WebPlayerColors.white60),
                            ),
                            TextSpan(text: _fmt(dur)),
                          ],
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              _iconBtn(
                Icons.subtitles_rounded,
                () => _openPanel(_Panel.subtitles),
                tooltip: 'Subtitles',
              ),
              if (widget.episodes.length > 1)
                showEpisodesLabel
                    ? TextButton.icon(
                        onPressed: () => _openPanel(_Panel.episodes),
                        icon: const Icon(
                          Icons.video_library_rounded,
                          color: Colors.white,
                          size: 24,
                        ),
                        label: const Text(
                          'Episodes',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          minimumSize: const Size(0, 40),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      )
                    : _iconBtn(
                        Icons.video_library_rounded,
                        () => _openPanel(_Panel.episodes),
                        tooltip: 'Episodes',
                      ),
              _iconBtn(
                Icons.picture_in_picture_alt_rounded,
                _pip,
                tooltip: 'Picture in picture',
              ),
              _iconBtn(
                Icons.settings_rounded,
                () => _openPanel(_Panel.main),
                tooltip: 'Settings',
              ),
              _iconBtn(
                widget.controller.isFullScreen
                    ? Icons.fullscreen_exit_rounded
                    : Icons.fullscreen_rounded,
                () {
                  widget.controller.toggleFullScreen();
                  _scheduleHide();
                },
                size: 28,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── panels ────────────────────────────────────────────────────────────
  Widget _buildPanel() {
    void back() => setState(() => _panel = _Panel.main);
    switch (_panel) {
      case _Panel.sources:
        return WebSourcesPanel(
          refresh: widget.sourcesRefresh,
          getSources: widget.getSources,
          getCurrent: widget.getCurrentSource,
          isDiscovering: widget.isDiscovering,
          providerOf: widget.providerOf,
          labelOf: widget.labelOf,
          isTorrent: widget.isTorrent,
          onSelect: (s) {
            if (_locked) return;
            setState(() => _panel = _Panel.none);
            widget.onSelectSource(s);
          },
          onBack: back,
        );
      case _Panel.subtitles:
        return WebSubtitlesPanel(
          load: widget.loadSubtitles,
          activeLabel: widget.activeSubtitleLabel(),
          onPick: (v) {
            setState(() => _panel = _Panel.none);
            widget.onPickSubtitle(v);
            setState(() => _showSyncBar = false);
          },
          onOff: () {
            setState(() => _panel = _Panel.none);
            widget.onSubtitleOff();
          },
          onAuto: () {
            setState(() => _panel = _Panel.none);
            widget.onAutoSubtitle();
          },
          delay: _subDelay,
          onDelay: _onDelay,
          onBack: back,
        );
      case _Panel.download:
        return WebDownloadPanel(
          mediaId: widget.mediaId,
          season: widget.season,
          episode: widget.episode,
          matchesTask: _matchesTask,
          canSaveCurrent: widget.getCurrentSource() != null,
          onSaveCurrent: () {
            setState(() => _panel = _Panel.none);
            widget.onSaveCurrent();
          },
          onBack: back,
        );
      case _Panel.party:
        return WebPartyPanel(
          party: widget.party,
          type: widget.mediaType,
          mediaId: widget.mediaId,
          season: widget.season,
          episode: widget.episode,
          videoUrl: widget.currentVideoUrl(),
          onBack: back,
        );
      case _Panel.episodes:
        return const SizedBox.shrink();
      case _Panel.speed:
        return _buildSpeed(back);
      case _Panel.video:
        return WebVideoPanel(
          onBack: back,
          onFit: (fit) {
            try {
              widget.controller.setOverriddenFit(fit);
            } catch (_) {}
          },
        );
      case _Panel.quality:
        return _buildQuality(back);
      case _Panel.main:
      case _Panel.none:
        return _buildMain();
    }
  }

  // Main settings view: 2x2 centered tiles + list (web: #settings-view-main)
  Widget _buildMain() {
    final current = widget.getCurrentSource();
    final sourceLabel = current == null ? 'Loading' : widget.providerOf(current);
    final subLabel = widget.activeSubtitleLabel() ?? 'Off';

    Widget tile(String label, String value, _Panel target) => Material(
      color: WebPlayerColors.white08,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () => _openPanel(target),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: WebPlayerColors.white60,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    Widget item(String label, VoidCallback onTap) => InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: const TextStyle(color: Colors.white, fontSize: 17),
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: WebPlayerColors.white60,
            ),
          ],
        ),
      ),
    );

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      children: [
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 3.0,
          children: [
            tile('Quality', 'Auto', _Panel.quality),
            tile('Source', sourceLabel, _Panel.sources),
            tile('Subtitles', subLabel, _Panel.subtitles),
            tile(
              'Video',
              WebVideoStyle.aspectLabels[WebVideoStyle.aspect.value] ?? 'Fit',
              _Panel.video,
            ),
          ],
        ),
        const Divider(color: WebPlayerColors.white12, height: 28),
        item('Playback speed (${_speed}x)', () => _openPanel(_Panel.speed)),
        item('Download', () => _openPanel(_Panel.download)),
        item('Watch Party', () => _openPanel(_Panel.party)),
        if (widget.episodes.length > 1)
          item('Episodes', () => _openPanel(_Panel.episodes)),
        item('Subtitle delay (${_subDelay.toStringAsFixed(1)}s)', () {
          setState(() {
            _panel = _Panel.none;
            _showSyncBar = true;
          });
        }),
      ],
    );
  }

  Widget _buildSpeed(VoidCallback back) {
    const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(title: 'Playback speed', onBack: back),
        for (final s in speeds)
          ListTile(
            onTap: () {
              widget.controller.setSpeed(s);
              setState(() => _speed = s);
            },
            title: Text(
              s == 1.0 ? 'Normal' : '${s}x',
              style: const TextStyle(color: Colors.white),
            ),
            trailing: _speed == s
                ? const Icon(Icons.check_rounded, color: Colors.white)
                : null,
          ),
      ],
    );
  }

  Widget _buildQuality(VoidCallback back) {
    List<BetterPlayerAsmsTrack> tracks = const [];
    try {
      tracks = widget.controller.betterPlayerAsmsTracks;
    } catch (_) {}
    final sorted = [...tracks]
      ..sort((a, b) => (b.height ?? 0).compareTo(a.height ?? 0));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(title: 'Quality', onBack: back),
        ListTile(
          onTap: () {
            widget.controller.setTrack(BetterPlayerAsmsTrack.defaultTrack());
            back();
          },
          title: const Text('Auto', style: TextStyle(color: Colors.white)),
        ),
        for (final t in sorted)
          if ((t.height ?? 0) > 0)
            ListTile(
              onTap: () {
                widget.controller.setTrack(t);
                back();
              },
              title: Text(
                '${t.height}p',
                style: const TextStyle(color: Colors.white),
              ),
            ),
      ],
    );
  }
}

/// Episodes dialog: header (X · TITLE) -> seasons list -> episodes list.
/// A series with a single season opens its episodes directly.
class _EpisodesDialogBody extends StatefulWidget {
  final String title;
  final List<Video> videos;
  final Video? current;
  final ValueChanged<Video> onSelect;
  final VoidCallback onClose;

  const _EpisodesDialogBody({
    required this.title,
    required this.videos,
    required this.current,
    required this.onSelect,
    required this.onClose,
  });

  @override
  State<_EpisodesDialogBody> createState() => _EpisodesDialogBodyState();
}

class _EpisodesDialogBodyState extends State<_EpisodesDialogBody> {
  final Map<int, List<Video>> _bySeason = {};
  List<int> _seasons = [];
  int? _season; // null = seasons list

  bool _isCurrent(Video v) {
    final c = widget.current;
    if (c == null) return false;
    if (v.id.isNotEmpty && v.id == c.id) return true;
    return v.episode != null && v.season == c.season && v.episode == c.episode;
  }

  @override
  void initState() {
    super.initState();
    for (final v in widget.videos) {
      _bySeason.putIfAbsent(v.season ?? 1, () => <Video>[]).add(v);
    }
    _seasons = _bySeason.keys.toList()..sort();
    for (final list in _bySeason.values) {
      list.sort((a, b) => (a.episode ?? 0).compareTo(b.episode ?? 0));
    }
    // More than one season: always start with the seasons list.
    // A single season has nothing to choose, so show its episodes directly.
    if (_seasons.length == 1) _season = _seasons.first;
  }

  @override
  Widget build(BuildContext context) {
    final inEpisodes = _season != null;
    final canGoBack = inEpisodes && _seasons.length > 1;
    final headerTitle = inEpisodes && _seasons.length > 1
        ? 'Season $_season'
        : widget.title.toUpperCase();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 12, 10, 6),
          child: Row(
            children: [
              IconButton(
                onPressed: canGoBack
                    ? () => setState(() => _season = null)
                    : widget.onClose,
                icon: Icon(
                  canGoBack ? Icons.arrow_back_rounded : Icons.close_rounded,
                  color: Colors.white,
                ),
                visualDensity: VisualDensity.compact,
              ),
              Expanded(
                child: Text(
                  headerTitle,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 40),
            ],
          ),
        ),
        Expanded(
          child: inEpisodes ? _episodesList() : _seasonsList(),
        ),
      ],
    );
  }

  Widget _seasonsList() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      itemCount: _seasons.length,
      itemBuilder: (context, i) {
        final s = _seasons[i];
        return InkWell(
          onTap: () => setState(() => _season = s),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 17),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Season $s',
                    style: const TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Text(
                    '${_bySeason[s]?.length ?? 0}',
                    style: const TextStyle(
                      color: WebPlayerColors.white60,
                      fontSize: 14,
                    ),
                  ),
                ),
                const Icon(
                  Icons.chevron_right_rounded,
                  color: WebPlayerColors.white60,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _episodesList() {
    final list = _bySeason[_season] ?? const <Video>[];
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final v = list[i];
        final cur = _isCurrent(v);
        final thumb = v.thumbnail;
        final epNum = v.episode ?? i + 1;
        return InkWell(
          onTap: () => widget.onSelect(v),
          borderRadius: BorderRadius.circular(12),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cur ? WebPlayerColors.white12 : WebPlayerColors.white08,
              borderRadius: BorderRadius.circular(12),
              border: cur
                  ? Border.all(color: const Color(0x66FFFFFF))
                  : null,
            ),
            child: Row(
              children: [
                // Episode image
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox(
                    width: 112,
                    height: 63,
                    child: (thumb == null || thumb.isEmpty)
                        ? _thumbPlaceholder(epNum)
                        : Image.network(
                            thumb,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _thumbPlaceholder(epNum),
                            loadingBuilder: (context, child, progress) =>
                                progress == null
                                    ? child
                                    : _thumbPlaceholder(epNum),
                          ),
                  ),
                ),
                const SizedBox(width: 12),
                // Number + name
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Episode $epNum',
                        style: const TextStyle(
                          color: WebPlayerColors.white60,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        v.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: cur ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                if (cur)
                  const Padding(
                    padding: EdgeInsets.only(left: 6),
                    child: Icon(
                      Icons.play_circle_fill_rounded,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _thumbPlaceholder(int n) {
    return Container(
      color: const Color(0xFF1A1A1A),
      alignment: Alignment.center,
      child: Text(
        '$n',
        style: const TextStyle(
          color: WebPlayerColors.white45,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
