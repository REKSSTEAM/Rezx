<?php
require __DIR__.'/common.php';
try {
    $provider=strtolower(trim((string)($_GET['provider']??'')));
    if ($provider && isset(VD_PROVIDERS[$provider])) {
        [$items,$status,$type]=providerPage($provider);
        out(array_merge(commonOptions('sections.php'),['sections'=>[['key'=>$provider,'title'=>VD_PROVIDERS[$provider],'items'=>$items,'upstream_http'=>$status,'content_type'=>$type]],'items'=>$items,'total'=>count($items)]));
    }
    $sections=allSections(); $all=[]; foreach($sections as $section) $all=array_merge($all,$section['items']??[]);
    $limit=min(48,max(8,(int)($_GET['limit']??24))); $page=max(1,(int)($_GET['page']??1)); $items=array_slice($all,($page-1)*$limit,$limit);
    out(array_merge(commonOptions('sections.php'),['sections'=>$sections,'page'=>$page,'items'=>$items,'total'=>count($all),'limit'=>$limit,'has_next'=>$page*$limit<count($all)]));
} catch(Throwable $e) { fail('sections.php',$e); }
