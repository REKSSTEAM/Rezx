import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// All subtitle appearance settings shown in "Customize Subtitles".
/// Every value is a [ValueNotifier] so the overlay updates live, and every
/// change is saved to SharedPreferences.
abstract final class WebSubStyle {
  static const _p = 'wsub_';

  // ── Defaults (same values the settings screens show) ───────────────────
  static const bool dNative = false;
  static const bool dFixCaps = false;
  static const double dBgOpacity = 0.75;
  static const bool dBlur = true;
  static const double dBlurIntensity = 1.0;
  static const double dTextScale = 1.0;
  static const String dFont = 'default';
  static const bool dBold = false;
  static const int dColor = 0xFFFFFFFF;
  static const int dBgColor = 0xFF000000;
  static const double dOverall = 0.74;
  static const String dShadow = 'shadow';
  static const String dPosition = 'bottom';

  // ── State ──────────────────────────────────────────────────────────────
  static final nativeSubs = ValueNotifier<bool>(dNative);
  static final fixCaps = ValueNotifier<bool>(dFixCaps);
  static final bgOpacity = ValueNotifier<double>(dBgOpacity);
  static final bgBlur = ValueNotifier<bool>(dBlur);
  static final blurIntensity = ValueNotifier<double>(dBlurIntensity);
  static final textScale = ValueNotifier<double>(dTextScale);
  static final font = ValueNotifier<String>(dFont);
  static final bold = ValueNotifier<bool>(dBold);
  static final color = ValueNotifier<int>(dColor);
  static final bgColor = ValueNotifier<int>(dBgColor);
  static final overall = ValueNotifier<double>(dOverall);
  static final shadow = ValueNotifier<String>(dShadow); // none|shadow|outline|both
  static final position = ValueNotifier<String>(dPosition); // very_bottom|bottom|mid

  /// Bumps on any change (listen to this to rebuild the preview / overlay).
  static final changed = ValueNotifier<int>(0);

  static bool _loaded = false;

  static const Map<String, String> fontLabels = {
    'default': 'Default',
    'serif': 'Serif',
    'mono': 'Monospace',
    'rounded': 'Rounded',
  };

  static const Map<String, String> shadowLabels = {
    'none': 'None',
    'shadow': 'Shadow',
    'outline': 'Outline',
    'both': 'Both',
  };

  static const Map<String, String> positionLabels = {
    'very_bottom': 'Very Bottom',
    'bottom': 'Bottom',
    'mid': 'Mid',
  };

  static String? fontFamily(String key) {
    switch (key) {
      case 'serif':
        return 'serif';
      case 'mono':
        return 'monospace';
      case 'rounded':
        return 'Poppins';
      default:
        return null;
    }
  }

  /// Vertical alignment (-1 top … 1 bottom) for each position choice.
  static double alignY(String pos) {
    switch (pos) {
      case 'very_bottom':
        return 0.97;
      case 'bottom':
        return 0.90;
      default:
        return 0.30;
    }
  }

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    final prefs = await SharedPreferences.getInstance();
    nativeSubs.value = prefs.getBool('${_p}native') ?? dNative;
    fixCaps.value = prefs.getBool('${_p}fixcaps') ?? dFixCaps;
    bgOpacity.value = prefs.getDouble('${_p}bgopacity') ?? dBgOpacity;
    bgBlur.value = prefs.getBool('${_p}blur') ?? dBlur;
    blurIntensity.value = prefs.getDouble('${_p}blurint') ?? dBlurIntensity;
    textScale.value = prefs.getDouble('${_p}scale') ?? dTextScale;
    font.value = prefs.getString('${_p}font') ?? dFont;
    bold.value = prefs.getBool('${_p}bold') ?? dBold;
    color.value = prefs.getInt('${_p}color') ?? dColor;
    bgColor.value = prefs.getInt('${_p}bgcolor') ?? dBgColor;
    overall.value = prefs.getDouble('${_p}overall') ?? dOverall;
    shadow.value = prefs.getString('${_p}shadow') ?? dShadow;
    position.value = prefs.getString('${_p}position2') ?? dPosition;
    changed.value++;
  }

  static Future<void> _save(void Function(SharedPreferences p) w) async {
    changed.value++;
    final prefs = await SharedPreferences.getInstance();
    w(prefs);
  }

  static Future<void> setNative(bool v) {
    nativeSubs.value = v;
    return _save((p) => p.setBool('${_p}native', v));
  }

  static Future<void> setFixCaps(bool v) {
    fixCaps.value = v;
    return _save((p) => p.setBool('${_p}fixcaps', v));
  }

  static Future<void> setBgOpacity(double v) {
    bgOpacity.value = v.clamp(0.0, 1.0);
    return _save((p) => p.setDouble('${_p}bgopacity', bgOpacity.value));
  }

  static Future<void> setBgBlur(bool v) {
    bgBlur.value = v;
    return _save((p) => p.setBool('${_p}blur', v));
  }

  static Future<void> setBlurIntensity(double v) {
    blurIntensity.value = v.clamp(0.0, 1.0);
    return _save((p) => p.setDouble('${_p}blurint', blurIntensity.value));
  }

  static Future<void> setTextScale(double v) {
    textScale.value = v.clamp(0.5, 2.0);
    return _save((p) => p.setDouble('${_p}scale', textScale.value));
  }

  static Future<void> setFont(String v) {
    font.value = v;
    return _save((p) => p.setString('${_p}font', v));
  }

  static Future<void> setBold(bool v) {
    bold.value = v;
    return _save((p) => p.setBool('${_p}bold', v));
  }

  static Future<void> setColor(int v) {
    color.value = v;
    return _save((p) => p.setInt('${_p}color', v));
  }

  static Future<void> setBgColor(int v) {
    bgColor.value = v;
    return _save((p) => p.setInt('${_p}bgcolor', v));
  }

  static Future<void> setOverall(double v) {
    overall.value = v.clamp(0.1, 1.0);
    return _save((p) => p.setDouble('${_p}overall', overall.value));
  }

  static Future<void> setShadow(String v) {
    shadow.value = v;
    return _save((p) => p.setString('${_p}shadow', v));
  }

  static Future<void> setPosition(String v) {
    position.value = v;
    return _save((p) => p.setString('${_p}position2', v));
  }

  // ── Quick styles ───────────────────────────────────────────────────────
  static const List<String> presetNames = [
    'Default',
    'Clean',
    'High Contrast',
    'Cinema',
  ];

  static Future<void> applyPreset(String name) async {
    switch (name) {
      case 'Clean':
        await setColor(0xFFFFFFFF);
        await setBgOpacity(0.0);
        await setShadow('both');
        await setFont('default');
        await setBold(false);
        await setOverall(1.0);
        break;
      case 'High Contrast':
        await setColor(0xFFFFFFFF);
        await setBgColor(0xFF000000);
        await setBgOpacity(1.0);
        await setShadow('outline');
        await setFont('default');
        await setBold(true);
        await setOverall(1.0);
        break;
      case 'Cinema':
        await setColor(0xFFFFEB3B);
        await setBgColor(0xFF000000);
        await setBgOpacity(0.6);
        await setShadow('shadow');
        await setFont('serif');
        await setBold(false);
        await setOverall(1.0);
        break;
      default:
        await setColor(dColor);
        await setBgColor(dBgColor);
        await setBgOpacity(dBgOpacity);
        await setShadow(dShadow);
        await setFont(dFont);
        await setBold(dBold);
        await setOverall(dOverall);
    }
  }

  static Future<void> resetAll() async {
    nativeSubs.value = dNative;
    fixCaps.value = dFixCaps;
    bgOpacity.value = dBgOpacity;
    bgBlur.value = dBlur;
    blurIntensity.value = dBlurIntensity;
    textScale.value = dTextScale;
    font.value = dFont;
    bold.value = dBold;
    color.value = dColor;
    bgColor.value = dBgColor;
    overall.value = dOverall;
    shadow.value = dShadow;
    position.value = dPosition;
    changed.value++;
    final prefs = await SharedPreferences.getInstance();
    for (final k in const [
      'native', 'fixcaps', 'bgopacity', 'blur', 'blurint', 'scale', 'font',
      'bold', 'color', 'bgcolor', 'overall', 'shadow', 'position2',
    ]) {
      await prefs.remove('$_p$k');
    }
  }

  // ── Text helpers ───────────────────────────────────────────────────────
  /// Removes HTML / ASS tags from a cue.
  static String clean(String raw) {
    var t = raw
        .replaceAll(RegExp(r'\{\\[^}]*\}'), '')
        .replaceAll(RegExp(r'<[^>]+>'), '')
        .replaceAll('\\N', '\n')
        .replaceAll('\\n', '\n');
    return t.trim();
  }

  /// "FIX CAPITALIZATION": turns ALL-CAPS text into normal sentence case.
  static String fixCapitalization(String text) {
    final letters = text.replaceAll(RegExp(r'[^A-Za-z]'), '');
    if (letters.length < 4) return text;
    final upper = letters.replaceAll(RegExp(r'[^A-Z]'), '').length;
    if (upper / letters.length < 0.7) return text;
    final lower = text.toLowerCase();
    final sb = StringBuffer();
    var capNext = true;
    for (var i = 0; i < lower.length; i++) {
      final ch = lower[i];
      if (capNext && RegExp(r'[a-z]').hasMatch(ch)) {
        sb.write(ch.toUpperCase());
        capNext = false;
      } else {
        sb.write(ch);
      }
      if (ch == '.' || ch == '!' || ch == '?' || ch == '\n') capNext = true;
    }
    return sb.toString().replaceAll(RegExp(r'\bi\b'), 'I');
  }

  /// Text shadows for the chosen shadow mode.
  static List<Shadow> shadows(String mode) {
    final out = <Shadow>[];
    if (mode == 'outline' || mode == 'both') {
      const r = 1.6;
      const d = 1.13;
      const c = Color(0xFF000000);
      out.addAll(const [
        Shadow(color: c, offset: Offset(-r, 0)),
        Shadow(color: c, offset: Offset(r, 0)),
        Shadow(color: c, offset: Offset(0, -r)),
        Shadow(color: c, offset: Offset(0, r)),
        Shadow(color: c, offset: Offset(-d, -d)),
        Shadow(color: c, offset: Offset(d, -d)),
        Shadow(color: c, offset: Offset(-d, d)),
        Shadow(color: c, offset: Offset(d, d)),
      ]);
    }
    if (mode == 'shadow' || mode == 'both') {
      out.add(const Shadow(
        color: Color(0xCC000000),
        offset: Offset(1.5, 1.5),
        blurRadius: 4,
      ));
    }
    return out;
  }
}
