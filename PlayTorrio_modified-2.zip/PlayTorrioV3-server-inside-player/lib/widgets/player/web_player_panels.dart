import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/download/download_task_model.dart';
import '../../models/stream/stream_model.dart';
import '../../services/download/download_service.dart';
import '../../services/player/watch_party_service.dart';
import '../../models/subtitle/subtitle_model.dart';
import 'web_sub_customize_page.dart';

/// Visual tokens copied from the web player (css/base/variables.css and
/// css/views/sources.css) so the Flutter player looks the same.
class WebPlayerColors {
  static const Color panelBg = Color(0xE6060606);
  static const Color white92 = Color(0xEBFFFFFF);
  static const Color white60 = Color(0x99FFFFFF);
  static const Color white45 = Color(0x73FFFFFF);
  static const Color white12 = Color(0x1FFFFFFF);
  static const Color white08 = Color(0x14FFFFFF);
  static const Color online = Color(0xFF43E28C);
  static const Color checking = Color(0xFFF5C451);
  static const Color offline = Color(0xFFFF6874);
}

/// Shared header: back arrow, title, optional trailing action.
class WebPanelHeader extends StatelessWidget {
  final String title;
  final VoidCallback onBack;
  final Widget? trailing;

  const WebPanelHeader({
    super.key,
    required this.title,
    required this.onBack,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 8, 10, 6),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            visualDensity: VisualDensity.compact,
          ),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// SERVERS (web: buildSourceList → .source-group / .source-branch)
// ─────────────────────────────────────────────────────────────────────────

/// Servers grouped by provider. Each group header shows the provider name,
/// an Online / Checking / Offline status, the number of playable servers and
/// the subtitle counter (CC icon). Tapping a header expands its branches.
class WebSourcesPanel extends StatefulWidget {
  final Listenable refresh;
  final List<StreamSource> Function() getSources;
  final StreamSource? Function() getCurrent;
  final bool Function() isDiscovering;
  final String Function(StreamSource) providerOf;
  final String Function(StreamSource) labelOf;
  final bool Function(StreamSource) isTorrent;
  final ValueChanged<StreamSource> onSelect;
  final VoidCallback onBack;

  const WebSourcesPanel({
    super.key,
    required this.refresh,
    required this.getSources,
    required this.getCurrent,
    required this.isDiscovering,
    required this.providerOf,
    required this.labelOf,
    required this.isTorrent,
    required this.onSelect,
    required this.onBack,
  });

  @override
  State<WebSourcesPanel> createState() => _WebSourcesPanelState();
}

class _WebSourcesPanelState extends State<WebSourcesPanel> {
  final Set<String> _expanded = <String>{};
  bool _seeded = false;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.refresh,
      builder: (context, _) {
        final sources = widget.getSources();
        final current = widget.getCurrent();
        final groups = <String, List<StreamSource>>{};
        for (final s in sources) {
          groups.putIfAbsent(widget.providerOf(s), () => <StreamSource>[]).add(s);
        }
        if (!_seeded && current != null) {
          _expanded.add(widget.providerOf(current));
          _seeded = true;
        }
        final discovering = widget.isDiscovering();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WebPanelHeader(title: 'Sources', onBack: widget.onBack),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 14),
                children: [
                  for (final entry in groups.entries)
                    _buildGroup(entry.key, entry.value, current, discovering),
                  if (groups.isEmpty && !discovering)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(
                        child: Text(
                          'No sources available',
                          style: TextStyle(color: WebPlayerColors.white45),
                        ),
                      ),
                    ),
                  if (discovering)
                    const Padding(
                      padding: EdgeInsets.all(14),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white70,
                            ),
                          ),
                          SizedBox(width: 10),
                          Text(
                            'Checking…',
                            style: TextStyle(
                              color: WebPlayerColors.white60,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildGroup(
    String name,
    List<StreamSource> items,
    StreamSource? current,
    bool discovering,
  ) {
    final playable = items.where((s) => !s.isFailed).toList();
    final status = playable.isNotEmpty
        ? 'online'
        : (discovering ? 'checking' : 'offline');
    final statusColor = status == 'online'
        ? WebPlayerColors.online
        : status == 'checking'
        ? WebPlayerColors.checking
        : WebPlayerColors.offline;
    final statusLabel = status == 'online'
        ? 'Online'
        : status == 'checking'
        ? 'Checking'
        : 'Offline';
    final branchLabel = playable.isNotEmpty
        ? '${playable.length} source${playable.length == 1 ? '' : 's'}'
        : (status == 'checking' ? 'Checking…' : 'Unavailable');

    // Subtitle counter: the biggest number of subtitle files any server in the
    // group ships with (same rule as groupSubtitleCount in the web player).
    var subtitleCount = 0;
    for (final s in items) {
      final n = s.subtitles?.length ?? 0;
      if (n > subtitleCount) subtitleCount = n;
    }

    final open = _expanded.contains(name);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: WebPlayerColors.white08,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() {
                if (!_expanded.add(name)) _expanded.remove(name);
              });
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Row(
                children: [
                  AnimatedRotation(
                    turns: open ? 0.25 : 0,
                    duration: const Duration(milliseconds: 160),
                    child: const Icon(
                      Icons.chevron_right_rounded,
                      color: WebPlayerColors.white60,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: statusColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    statusLabel,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    branchLabel,
                    style: const TextStyle(
                      color: WebPlayerColors.white60,
                      fontSize: 11,
                    ),
                  ),
                  if (subtitleCount > 0) ...[
                    const SizedBox(width: 8),
                    const Icon(
                      Icons.closed_caption_rounded,
                      size: 14,
                      color: WebPlayerColors.white60,
                    ),
                    const SizedBox(width: 2),
                    Text(
                      '$subtitleCount',
                      style: const TextStyle(
                        color: WebPlayerColors.white60,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (open)
            for (final s in playable) _buildBranch(s, current),
        ],
      ),
    );
  }

  Widget _buildBranch(StreamSource s, StreamSource? current) {
    final active = current != null && identical(current, s) ||
        (current != null &&
            current.url == s.url &&
            current.infoHash == s.infoHash);
    final quality = s.quality;
    return InkWell(
      onTap: active
          ? null
          : () {
              HapticFeedback.mediumImpact();
              widget.onSelect(s);
            },
      child: Container(
        padding: const EdgeInsets.fromLTRB(36, 10, 12, 10),
        decoration: BoxDecoration(
          color: active ? WebPlayerColors.white12 : Colors.transparent,
          border: const Border(top: BorderSide(color: WebPlayerColors.white08)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                widget.labelOf(s),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: active ? Colors.white : WebPlayerColors.white92,
                  fontSize: 13,
                  fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
            if (quality != null && quality.isNotEmpty) ...[
              const SizedBox(width: 8),
              _tag(quality),
            ],
            const SizedBox(width: 6),
            _tag(widget.isTorrent(s) ? 'P2P' : 'HTTP'),
            if (active) ...[
              const SizedBox(width: 8),
              const Icon(Icons.check_rounded, color: Colors.white, size: 18),
            ],
          ],
        ),
      ),
    );
  }

  Widget _tag(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
    decoration: BoxDecoration(
      color: WebPlayerColors.white12,
      borderRadius: BorderRadius.circular(4),
    ),
    child: Text(
      text.toUpperCase(),
      style: const TextStyle(
        color: WebPlayerColors.white60,
        fontSize: 9.5,
        fontWeight: FontWeight.w800,
      ),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────
// SUBTITLES (web: renderSubtitleList / #settings-view-subtitles)
// ─────────────────────────────────────────────────────────────────────────

enum _SubView { languages, entries, customize }

/// Language groups with a counter badge (slg-count), entries inside a group,
/// Off / Auto select rows and a Customize page with the delay controls.
class WebSubtitlesPanel extends StatefulWidget {
  final Future<List<SubtitleLanguageGroup>> Function() load;
  final String? activeLabel;
  final ValueChanged<SubtitleVariant> onPick;
  final VoidCallback onOff;
  final VoidCallback onAuto;
  final double delay;
  final ValueChanged<double> onDelay;
  final VoidCallback onBack;

  const WebSubtitlesPanel({
    super.key,
    required this.load,
    required this.activeLabel,
    required this.onPick,
    required this.onOff,
    required this.onAuto,
    required this.delay,
    required this.onDelay,
    required this.onBack,
  });

  @override
  State<WebSubtitlesPanel> createState() => _WebSubtitlesPanelState();
}

class _WebSubtitlesPanelState extends State<WebSubtitlesPanel> {
  late Future<List<SubtitleLanguageGroup>> _future;
  _SubView _view = _SubView.languages;
  SubtitleLanguageGroup? _group;
  late double _delay;

  @override
  void initState() {
    super.initState();
    _future = widget.load();
    _delay = widget.delay;
  }

  @override
  Widget build(BuildContext context) {
    switch (_view) {
      case _SubView.customize:
        return _buildCustomize();
      case _SubView.entries:
        return _buildEntries();
      case _SubView.languages:
        return _buildLanguages();
    }
  }

  Widget _row({
    required String label,
    VoidCallback? onTap,
    Widget? trailing,
    bool checked = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: checked ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
            if (trailing != null) trailing,
            if (checked)
              const Padding(
                padding: EdgeInsets.only(left: 8),
                child: Icon(Icons.check_rounded, color: Colors.white, size: 18),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguages() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(
          title: 'Subtitles',
          onBack: widget.onBack,
          trailing: TextButton(
            onPressed: () => setState(() => _view = _SubView.customize),
            child: const Text(
              'Customize',
              style: TextStyle(color: Colors.white70, fontSize: 12.5),
            ),
          ),
        ),
        _row(
          label: 'Off',
          onTap: widget.onOff,
          checked: widget.activeLabel == null,
        ),
        _row(label: 'Auto select (Arabic)', onTap: widget.onAuto),
        const Divider(height: 1, color: WebPlayerColors.white12),
        Expanded(
          child: FutureBuilder<List<SubtitleLanguageGroup>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white70,
                    ),
                  ),
                );
              }
              final groups = snap.data ?? const <SubtitleLanguageGroup>[];
              if (groups.isEmpty) {
                return const Center(
                  child: Text(
                    'None available',
                    style: TextStyle(color: WebPlayerColors.white45),
                  ),
                );
              }
              return ListView(
                children: [
                  for (final g in groups)
                    _row(
                      label: g.language,
                      onTap: () => setState(() {
                        _group = g;
                        _view = _SubView.entries;
                      }),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: WebPlayerColors.white12,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '${g.variants.length}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          const Icon(
                            Icons.chevron_right_rounded,
                            color: WebPlayerColors.white45,
                          ),
                        ],
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildEntries() {
    final g = _group!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(
          title: '${g.language} (${g.variants.length})',
          onBack: () => setState(() => _view = _SubView.languages),
        ),
        Expanded(
          child: ListView(
            children: [
              for (final v in g.variants)
                _row(
                  label: v.title.isNotEmpty ? v.title : v.language,
                  checked: widget.activeLabel != null &&
                      widget.activeLabel!.contains(v.providerName) &&
                      widget.activeLabel!.contains(v.language),
                  trailing: Text(
                    '${v.providerName} · ${v.format.toUpperCase()}',
                    style: const TextStyle(
                      color: WebPlayerColors.white45,
                      fontSize: 11,
                    ),
                  ),
                  onTap: () => widget.onPick(v),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCustomize() {
    return WebSubCustomizePage(
      delay: _delay,
      onDelay: (v) {
        _delay = v;
        widget.onDelay(v);
      },
      onBack: () => setState(() => _view = _SubView.languages),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// DOWNLOAD (web: #main-pip-btn → GET {base}/downloads/movie|tv/... )
// ─────────────────────────────────────────────────────────────────────────

class WebDownloadItem {
  final String url;
  final String quality;
  final String? size;
  final String? format;

  const WebDownloadItem({
    required this.url,
    required this.quality,
    this.size,
    this.format,
  });
}

/// Same request the web player makes. The base URL is the address of the PHP
/// site, stored once in SharedPreferences ('web_player_api_base').
class WebDownloadApi {
  static const String prefsKey = 'web_player_api_base';

  static Future<String> getBase() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getString(prefsKey) ?? '').trim().replaceAll(RegExp(r'/+$'), '');
  }

  static Future<void> setBase(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(prefsKey, value.trim().replaceAll(RegExp(r'/+$'), ''));
  }

  /// Retries up to 3 times (1s, 2s, 4s) exactly like the web player.
  static Future<List<WebDownloadItem>> fetch({
    required String base,
    required String id,
    int? season,
    int? episode,
  }) async {
    final path = season != null
        ? '/downloads/tv/$id/$season/${episode ?? 1}'
        : '/downloads/movie/$id';
    final delays = [1000, 2000, 4000];
    Object? lastError;
    for (var attempt = 0; attempt <= 2; attempt++) {
      final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
      try {
        final req = await client.getUrl(Uri.parse('$base$path'));
        final res = await req.close().timeout(const Duration(seconds: 20));
        if (res.statusCode != 200) throw HttpException('HTTP ${res.statusCode}');
        final body = await res.transform(utf8.decoder).join();
        final json = jsonDecode(body);
        final list = (json is Map ? json['downloads'] : null) as List? ?? const [];
        return [
          for (final d in list)
            if (d is Map && (d['url']?.toString().isNotEmpty ?? false))
              WebDownloadItem(
                url: d['url'].toString(),
                quality: d['quality']?.toString() ?? 'Download',
                size: d['size']?.toString(),
                format: d['format']?.toString(),
              ),
        ];
      } catch (e) {
        lastError = e;
        if (attempt < 2) await Future<void>.delayed(Duration(milliseconds: delays[attempt]));
      } finally {
        client.close(force: true);
      }
    }
    throw lastError ?? StateError('Failed to fetch downloads.');
  }
}

/// Download panel: (1) save the playing server inside the app with the app's
/// own downloader, (2) the link list coming from the PHP site.
class WebDownloadPanel extends StatefulWidget {
  final String mediaId;
  final int? season;
  final int? episode;
  final bool canSaveCurrent;
  final VoidCallback onSaveCurrent;
  final bool Function(DownloadTask) matchesTask;
  final VoidCallback onBack;

  const WebDownloadPanel({
    super.key,
    required this.mediaId,
    required this.season,
    required this.episode,
    required this.canSaveCurrent,
    required this.onSaveCurrent,
    required this.matchesTask,
    required this.onBack,
  });

  @override
  State<WebDownloadPanel> createState() => _WebDownloadPanelState();
}

class _WebDownloadPanelState extends State<WebDownloadPanel> {
  final TextEditingController _baseCtrl = TextEditingController();
  Future<List<WebDownloadItem>>? _future;
  String _base = '';
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final base = await WebDownloadApi.getBase();
    if (!mounted) return;
    setState(() {
      _base = base;
      _baseCtrl.text = base;
      _ready = true;
      if (base.isNotEmpty) _load();
    });
  }

  void _load() {
    _future = WebDownloadApi.fetch(
      base: _base,
      id: widget.mediaId,
      season: widget.season,
      episode: widget.episode,
    );
  }

  @override
  void dispose() {
    _baseCtrl.dispose();
    super.dispose();
  }

  Future<void> _open(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        WebPanelHeader(title: 'Download', onBack: widget.onBack),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
            children: [
              ValueListenableBuilder<List<DownloadTask>>(
                valueListenable: DownloadService.instance.tasksNotifier,
                builder: (context, tasks, _) {
                  final matching = tasks.where(widget.matchesTask).toList()
                    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
                  if (matching.isEmpty) return const SizedBox.shrink();
                  return _taskCard(matching.first);
                },
              ),
              _tile(
                icon: Icons.file_download_outlined,
                title: 'Save current server in the app',
                subtitle: widget.canSaveCurrent
                    ? 'Uses the app downloader (Downloads page)'
                    : 'No active server',
                onTap: widget.canSaveCurrent ? widget.onSaveCurrent : null,
              ),
              const SizedBox(height: 14),
              const Padding(
                padding: EdgeInsets.only(left: 4, bottom: 6),
                child: Text(
                  'Download links',
                  style: TextStyle(
                    color: WebPlayerColors.white60,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (!_ready)
                const Center(child: CircularProgressIndicator(strokeWidth: 2))
              else ...[
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _baseCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 13),
                        keyboardType: TextInputType.url,
                        decoration: InputDecoration(
                          isDense: true,
                          hintText: 'https://your-site.com',
                          hintStyle: const TextStyle(color: WebPlayerColors.white45),
                          filled: true,
                          fillColor: WebPlayerColors.white08,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    FilledButton(
                      onPressed: () async {
                        await WebDownloadApi.setBase(_baseCtrl.text);
                        final base = await WebDownloadApi.getBase();
                        if (!mounted) return;
                        setState(() {
                          _base = base;
                          if (base.isNotEmpty) _load();
                        });
                      },
                      child: const Text('Save'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                if (_base.isEmpty)
                  const Text(
                    'Enter the address of your site to list its download links.',
                    style: TextStyle(color: WebPlayerColors.white45, fontSize: 12),
                  )
                else
                  FutureBuilder<List<WebDownloadItem>>(
                    future: _future,
                    builder: (context, snap) {
                      if (snap.connectionState != ConnectionState.done) {
                        return const Padding(
                          padding: EdgeInsets.all(18),
                          child: Center(
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        );
                      }
                      if (snap.hasError) {
                        return const Padding(
                          padding: EdgeInsets.all(18),
                          child: Center(
                            child: Text(
                              'Failed to fetch downloads.',
                              style: TextStyle(color: WebPlayerColors.white45),
                            ),
                          ),
                        );
                      }
                      final items = snap.data ?? const <WebDownloadItem>[];
                      if (items.isEmpty) {
                        return const Padding(
                          padding: EdgeInsets.all(18),
                          child: Center(
                            child: Text(
                              'No downloads available.',
                              style: TextStyle(color: WebPlayerColors.white45),
                            ),
                          ),
                        );
                      }
                      return Column(
                        children: [
                          for (final d in items)
                            _tile(
                              icon: Icons.download_rounded,
                              title: d.size != null && d.size!.isNotEmpty
                                  ? '${d.quality}  ·  ${d.size}'
                                  : d.quality,
                              subtitle: d.format,
                              onTap: () => _open(d.url),
                              onLongPress: () {
                                Clipboard.setData(ClipboardData(text: d.url));
                                HapticFeedback.lightImpact();
                              },
                            ),
                        ],
                      );
                    },
                  ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _taskCard(DownloadTask t) {
    final label = switch (t.status) {
      DownloadStatus.completed => 'Downloaded',
      DownloadStatus.failed => 'Failed${t.error != null ? ' · ${t.error}' : ''}',
      DownloadStatus.paused => 'Paused',
      DownloadStatus.queued => 'Queued',
      DownloadStatus.canceled => 'Canceled',
      DownloadStatus.downloading => 'Downloading',
    };
    final active = t.status == DownloadStatus.downloading ||
        t.status == DownloadStatus.paused ||
        t.status == DownloadStatus.queued;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: WebPlayerColors.white08,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: WebPlayerColors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            (t.episodeTitle?.isNotEmpty ?? false) ? t.episodeTitle! : t.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: t.status == DownloadStatus.completed
                  ? 1.0
                  : t.progressPercent,
              minHeight: 5,
              backgroundColor: WebPlayerColors.white12,
              color: t.status == DownloadStatus.failed
                  ? WebPlayerColors.offline
                  : WebPlayerColors.online,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: Text(
                  t.isDownloading
                      ? '$label · ${(t.progressPercent * 100).toStringAsFixed(0)}% · ${t.speedLabel} · ${t.etaLabel}'
                      : '$label · ${(t.progressPercent * 100).toStringAsFixed(0)}%',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: WebPlayerColors.white60,
                    fontSize: 11.5,
                  ),
                ),
              ),
              if (t.isDownloading)
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.pause_rounded, color: Colors.white),
                  onPressed: () =>
                      DownloadService.instance.pauseDownload(t.id),
                ),
              if (t.isPaused || t.isFailed)
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(
                    Icons.play_arrow_rounded,
                    color: Colors.white,
                  ),
                  onPressed: () =>
                      DownloadService.instance.resumeDownload(t.id),
                ),
              if (active)
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.close_rounded, color: Colors.white),
                  onPressed: () =>
                      DownloadService.instance.cancelDownload(t.id),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _tile({
    required IconData icon,
    required String title,
    String? subtitle,
    VoidCallback? onTap,
    VoidCallback? onLongPress,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: WebPlayerColors.white08,
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        enabled: onTap != null,
        onTap: onTap,
        onLongPress: onLongPress,
        dense: true,
        leading: Icon(icon, color: Colors.white),
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13.5,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: subtitle == null || subtitle.isEmpty
            ? null
            : Text(
                subtitle,
                style: const TextStyle(
                  color: WebPlayerColors.white45,
                  fontSize: 11.5,
                ),
              ),
      ),
    );
  }
}


// ─────────────────────────────────────────────────────────────────────────
// WATCH PARTY (web: watch-party-ajax.js / #settings-view-watchparty)
// ─────────────────────────────────────────────────────────────────────────

class WebPartyPanel extends StatefulWidget {
  final WatchPartyService party;
  final String type; // 'movie' | 'tv'
  final String mediaId;
  final int? season;
  final int? episode;
  final String videoUrl;
  final VoidCallback onBack;

  const WebPartyPanel({
    super.key,
    required this.party,
    required this.type,
    required this.mediaId,
    required this.season,
    required this.episode,
    required this.videoUrl,
    required this.onBack,
  });

  @override
  State<WebPartyPanel> createState() => _WebPartyPanelState();
}

class _WebPartyPanelState extends State<WebPartyPanel> {
  static const String _nameKey = 'watch_party_name';
  final TextEditingController _name = TextEditingController();
  final TextEditingController _code = TextEditingController();
  final TextEditingController _base = TextEditingController();
  String? _note;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final base = await WebDownloadApi.getBase();
    if (!mounted) return;
    setState(() {
      _name.text = prefs.getString(_nameKey) ?? '';
      _base.text = base;
      widget.party.base = base;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _code.dispose();
    _base.dispose();
    super.dispose();
  }

  Future<void> _saveBase() async {
    await WebDownloadApi.setBase(_base.text);
    final base = await WebDownloadApi.getBase();
    widget.party.base = base;
    if (mounted) setState(() => _note = 'Site address saved');
  }

  Future<void> _rememberName() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_nameKey, _name.text.trim());
  }

  String _shareUrl(String code) => '${widget.party.base}/?party=$code';

  InputDecoration _dec(String hint) => InputDecoration(
    isDense: true,
    hintText: hint,
    hintStyle: const TextStyle(color: WebPlayerColors.white45),
    filled: true,
    fillColor: WebPlayerColors.white08,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide.none,
    ),
  );

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.party,
      builder: (context, _) {
        final party = widget.party;
        final room = party.room;
        final message = party.error ?? _note;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            WebPanelHeader(title: 'Watch Party', onBack: widget.onBack),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 16),
                children: [
                  if (room == null) ..._startView(party) else ..._roomView(party, room),
                  if (message != null && message.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Text(
                        message,
                        style: const TextStyle(
                          color: WebPlayerColors.checking,
                          fontSize: 12,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  List<Widget> _startView(WatchPartyService party) {
    return [
      const Text(
        'Site address',
        style: TextStyle(color: WebPlayerColors.white60, fontSize: 12),
      ),
      const SizedBox(height: 6),
      Row(
        children: [
          Expanded(
            child: TextField(
              controller: _base,
              keyboardType: TextInputType.url,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: _dec('https://your-site.com'),
            ),
          ),
          const SizedBox(width: 8),
          FilledButton(onPressed: _saveBase, child: const Text('Save')),
        ],
      ),
      const SizedBox(height: 14),
      TextField(
        controller: _name,
        maxLength: 40,
        onChanged: (_) => _rememberName(),
        style: const TextStyle(color: Colors.white, fontSize: 14),
        decoration: _dec('Your name').copyWith(counterText: ''),
      ),
      const SizedBox(height: 10),
      FilledButton.icon(
        onPressed: party.busy || party.base.isEmpty
            ? null
            : () => party.create(
                name: _name.text.trim(),
                type: widget.type,
                id: widget.mediaId,
                season: widget.season,
                episode: widget.episode,
                video: widget.videoUrl,
              ),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Create Room'),
      ),
      const SizedBox(height: 14),
      Row(
        children: [
          Expanded(
            child: TextField(
              controller: _code,
              maxLength: 12,
              textCapitalization: TextCapitalization.characters,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: _dec('AFV-XXXXX').copyWith(counterText: ''),
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            onPressed: party.busy || party.base.isEmpty
                ? null
                : () => party.join(_code.text, _name.text.trim()),
            child: const Text('Join'),
          ),
        ],
      ),
    ];
  }

  List<Widget> _roomView(WatchPartyService party, WatchPartyRoom room) {
    return [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: WebPlayerColors.white08,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    room.code,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: room.code));
                    setState(() => _note = 'Room code copied');
                  },
                  child: const Text('Copy'),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              party.isHost ? 'You are the Host' : 'Host: ${room.hostName}',
              style: const TextStyle(color: Colors.white, fontSize: 13),
            ),
            Text(
              'People watching: ${room.memberCount}',
              style: const TextStyle(
                color: WebPlayerColors.white60,
                fontSize: 12.5,
              ),
            ),
            if (party.isLocked)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'Only the host controls playback.',
                  style: TextStyle(
                    color: WebPlayerColors.white45,
                    fontSize: 12,
                  ),
                ),
              ),
          ],
        ),
      ),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () {
          Clipboard.setData(ClipboardData(text: _shareUrl(room.code)));
          setState(() => _note = 'Room link copied');
        },
        icon: const Icon(Icons.link_rounded),
        label: const Text('Copy room link'),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        style: OutlinedButton.styleFrom(foregroundColor: WebPlayerColors.offline),
        onPressed: () => party.leave(),
        icon: const Icon(Icons.logout_rounded),
        label: const Text('Leave Room'),
      ),
    ];
  }
}
