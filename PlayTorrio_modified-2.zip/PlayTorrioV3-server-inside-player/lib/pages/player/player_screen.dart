import 'dart:async';
import 'dart:io';

import 'package:better_player_plus/better_player_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../models/movie/movie_detail.dart';
import '../../models/movie/video.dart';
import '../../models/stream/stream_model.dart';
import '../../models/subtitle/subtitle_model.dart';
import '../../services/debrid/debrid_service.dart';
import '../../services/player/player_settings.dart';
import '../../services/stream/stream_service.dart';
import '../../services/stream/torrent_stream_service.dart';
import '../../services/download/download_service.dart';
import '../../services/player/watch_party_service.dart';
import '../../services/player/web_sub_style.dart';
import '../../models/movie/movie.dart';
import '../details/details_page.dart';
import '../../services/subtitles/subtitle_parser.dart';
import '../../services/subtitles/subtitle_service.dart';
import '../../services/subtitles/subtitle_sync_helper.dart';
import '../../widgets/player/web_style_controls.dart';

/// FlixQuest BetterPlayer based video screen.
///
/// BetterPlayer owns the in-player controls for play/pause, seeking, fullscreen,
/// audio tracks, subtitles, quality and playback speed. The source queue is
/// kept outside the player so a failed URL can be replaced without showing a
/// server-selection screen to the user.
class PlayerScreen extends StatefulWidget {
  final StreamSource? source;
  final String title;
  final String? backdropUrl;
  final String? logoUrl;
  final MovieDetail? detail;
  final Video? episode;
  final Duration? initialPosition;
  final List<SubtitleVariant>? initialSubtitles;
  final ValueListenable<List<StreamSource>>? fallbackSources;
  final bool discoverStreams;
  final String? streamType;
  final bool isCollection;

  /// When given, minimizing the player returns to the details layout with
  /// the live player in place of the poster.
  final Movie? movie;

  const PlayerScreen({
    super.key,
    this.movie,
    this.source,
    required this.title,
    this.backdropUrl,
    this.logoUrl,
    this.detail,
    this.episode,
    this.initialPosition,
    this.initialSubtitles,
    this.fallbackSources,
    this.discoverStreams = false,
    this.streamType,
    this.isCollection = false,
  });

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  BetterPlayerController? _controller;
  StreamSource? _currentSource;
  final ValueNotifier<List<StreamSource>> _discoveredSources = ValueNotifier(
    const <StreamSource>[],
  );
  StreamSubscription<StreamSource>? _discoverySubscription;
  final Set<String> _attemptedSources = <String>{};
  bool _isLoading = true;
  bool _isDiscovering = false;
  bool _isRetrying = false;
  bool _hasFatalError = false;
  String _status = 'Preparing video…';
  String? _error;
  int _openGeneration = 0;

  // Current episode (changes when the user switches episode from the player).
  Video? _episode;
  bool _episodeSwitched = false;
  final WatchPartyService _party = WatchPartyService();

  // Web-player style panels (servers / subtitles / download).
  late final Listenable _sourcesRefresh;
  Future<List<SubtitleLanguageGroup>>? _subtitleFuture;
  List<SubCue>? _baseCues;
  List<SubCue>? _shownCues; // cues (delay applied) drawn by WebSubtitleOverlay
  bool _nativeSubActive = false;
  bool _minimized = false; // true after leaving fullscreen
  bool _leaving = false;
  String? _subLabel;
  double _subDelay = 0;
  Timer? _delayTimer;
  int _subFileCounter = 0;

  @override
  void initState() {
    super.initState();
    _currentSource = widget.source;
    _episode = widget.episode;
    _party.onRemoteState = _applyRemoteState;
    _sourcesRefresh = Listenable.merge([
      _discoveredSources,
      if (widget.fallbackSources != null) widget.fallbackSources!,
    ]);
    widget.fallbackSources?.addListener(_onFallbackQueueChanged);
    _discoveredSources.addListener(_onFallbackQueueChanged);
    WebSubStyle.load();
    WebSubStyle.nativeSubs.addListener(_onNativeSubsToggled);
    WakelockPlus.enable();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    final existingSources =
        widget.fallbackSources?.value ?? const <StreamSource>[];
    if (_currentSource == null && existingSources.isNotEmpty) {
      _currentSource = existingSources.first;
    }
    if (_currentSource != null) {
      _attemptedSources.add(_sourceKey(_currentSource!));
      _openCurrentSource();
    } else if (widget.discoverStreams) {
      _startStreamDiscovery();
    } else {
      _isLoading = false;
      _error = 'No playable source was provided.';
    }
  }

  bool _isPlayableSource(StreamSource source) {
    final url = source.url?.trim();
    return (url != null && url.isNotEmpty) ||
        (source.infoHash?.trim().isNotEmpty ?? false);
  }

  void _onFallbackQueueChanged() {
    if (!mounted) return;
    if (_currentSource == null) {
      for (final candidate in _availableSources) {
        final key = _sourceKey(candidate);
        if (_isPlayableSource(candidate) && !_attemptedSources.contains(key)) {
          _currentSource = candidate;
          _attemptedSources.add(key);
          _openCurrentSource();
          return;
        }
      }
    }
    setState(() {});
    if (_hasFatalError && !_isRetrying) {
      _tryNextSource(reason: 'A new source became available');
    }
  }

  void _addDiscoveredSource(StreamSource source) {
    if (!mounted) return;
    if (!_isPlayableSource(source)) return;
    final key = _sourceKey(source);
    if (_discoveredSources.value.any(
      (existing) => _sourceKey(existing) == key,
    )) {
      return;
    }
    _discoveredSources.value = List.unmodifiable([
      ..._discoveredSources.value,
      source,
    ]);
  }

  Future<void> _startStreamDiscovery() async {
    final detail = widget.detail;
    if ((!widget.discoverStreams && !_episodeSwitched) || detail == null) {
      return;
    }
    await _discoverySubscription?.cancel();
    if (!mounted) return;

    _discoveredSources.value = const <StreamSource>[];
    _attemptedSources.clear();
    _currentSource = null;
    _isDiscovering = true;
    setState(() {
      _isLoading = true;
      _error = null;
      _status = 'Searching for servers…';
    });

    final episode = _episode;
    final isCollection =
        widget.isCollection ||
        detail.isCollection ||
        (episode != null &&
            episode.id.startsWith('tt') &&
            (detail.type == 'collections' || detail.type == 'collection'));
    final effectiveTitle = isCollection && episode != null
        ? episode.title
        : detail.name;
    final release = episode?.released;
    final year = isCollection && release != null && release.length >= 4
        ? int.tryParse(release.substring(0, 4))
        : int.tryParse(detail.year ?? '');

    for (final source in episode?.streams ?? const <StreamSource>[]) {
      _addDiscoveredSource(source);
    }

    _discoverySubscription =
        StreamService.fetchStreams(
          type: isCollection ? 'movie' : (widget.streamType ?? detail.type),
          id: episode?.id ?? detail.id,
          title: effectiveTitle,
          year: year,
          season: isCollection ? null : episode?.season,
          episode: isCollection ? null : episode?.episode,
          genres: detail.genres,
        ).listen(
          _addDiscoveredSource,
          onError: (Object error) => _finishStreamDiscovery(error: error),
          onDone: () => _finishStreamDiscovery(),
        );
  }

  void _finishStreamDiscovery({Object? error}) {
    if (!mounted) return;
    _isDiscovering = false;
    if (_currentSource == null && _availableSources.isEmpty) {
      setState(() {
        _isLoading = false;
        _error = error?.toString() ?? 'No servers found for this title.';
        _status = '';
      });
      return;
    }
    setState(() {});
  }

  String _sourceKey(StreamSource source) {
    final url = source.url?.trim();
    if (url != null && url.isNotEmpty) return 'url:$url';
    final hash = source.infoHash?.trim();
    if (hash != null && hash.isNotEmpty) {
      return 'hash:$hash:${source.fileIdx ?? ''}';
    }
    return 'source:${source.addonName}:${source.name}:${source.title}';
  }

  List<StreamSource> get _availableSources {
    final result = <StreamSource>[];
    final seen = <String>{};
    final current = _currentSource;
    final sources = <StreamSource>[
      if (current != null) current,
      ..._discoveredSources.value,
      if (!_episodeSwitched) ...?widget.fallbackSources?.value,
    ];
    for (final source in sources) {
      if (_isPlayableSource(source) && seen.add(_sourceKey(source))) {
        result.add(source);
      }
    }
    return result;
  }

  bool _isTorrentSource(StreamSource source) {
    final url = source.url?.toLowerCase() ?? '';
    return source.infoHash?.isNotEmpty == true ||
        url.startsWith('magnet:') ||
        url.startsWith('torrent:');
  }

  String _sourceProvider(StreamSource source) {
    final value = source.providerName?.trim().isNotEmpty == true
        ? source.providerName!.trim()
        : source.addonName.trim();
    return value.isEmpty ? 'Unknown source' : value;
  }

  String _serverLabel(StreamSource source) {
    final value = source.name?.trim().isNotEmpty == true
        ? source.name!.trim()
        : source.title?.trim().isNotEmpty == true
        ? source.title!.trim()
        : source.displayTitle;
    return value.isEmpty ? 'Server' : value;
  }

  String _protocolLabel(StreamSource source) {
    if (_isTorrentSource(source)) return 'Torrent';
    final url = source.url?.toLowerCase() ?? '';
    if (url.contains('.m3u8')) return 'HTTP · HLS';
    if (url.contains('.mpd')) return 'HTTP · DASH';
    return 'HTTP';
  }

  /// Switch to another episode without leaving the player (web: episodes
  /// panel → season → episode). Servers are searched again for that episode.
  Future<void> _switchEpisode(Video ep) async {
    if (_party.isLocked) return;
    if (_episode?.id == ep.id && _controller != null) return;
    _openGeneration++;
    await _discoverySubscription?.cancel();
    StreamService.stopAllScrapers();
    _controller?.dispose();
    _controller = null;
    _episodeSwitched = true;
    _episode = ep;
    _subtitleFuture = null;
    _baseCues = null;
    _shownCues = null;
    _nativeSubActive = false;
    _subLabel = null;
    await _startStreamDiscovery();
  }

  /// Watch party: apply the host's play/pause/position (members only).
  Future<void> _applyRemoteState(bool playing, double positionSec) async {
    final c = _controller;
    if (c == null) return;
    _party.applying = true;
    try {
      final vp = c.videoPlayerController;
      final cur = (vp?.value.position.inMilliseconds ?? 0) / 1000.0;
      if ((cur - positionSec).abs() > 1.2) {
        await c.seekTo(Duration(milliseconds: (positionSec * 1000).round()));
      }
      if (playing) {
        await c.play();
      } else {
        await c.pause();
      }
    } catch (_) {
    } finally {
      Future<void>.delayed(const Duration(milliseconds: 120), () {
        _party.applying = false;
      });
    }
  }

  Future<void> _selectSource(StreamSource source) async {
    if (_currentSource != null &&
        _sourceKey(source) == _sourceKey(_currentSource!) &&
        _controller != null) {
      return;
    }
    _openGeneration++;
    _controller?.dispose();
    _controller = null;
    _attemptedSources.add(_sourceKey(source));
    setState(() {
      _currentSource = source;
      _isLoading = true;
      _error = null;
      _hasFatalError = false;
      _status = 'Switching to ${_serverLabel(source)}…';
    });
    await _openCurrentSource();
  }

  Future<String?> _resolveUrl(StreamSource source) async {
    final rawUrl = source.url;
    if (rawUrl != null &&
        (File(rawUrl).existsSync() || source.name == 'Downloaded')) {
      return rawUrl;
    }

    final isMagnet = rawUrl?.startsWith('magnet:') == true;
    final isTorrent = (source.infoHash?.isNotEmpty ?? false) || isMagnet;
    if (!isTorrent) {
      if (rawUrl == null || rawUrl.trim().isEmpty) return null;
      return rawUrl;
    }

    late String magnet;
    if (rawUrl != null && rawUrl.isNotEmpty) {
      magnet = rawUrl;
    } else {
      magnet = 'magnet:?xt=urn:btih:${source.infoHash}';
      for (final item in source.sources ?? const <String>[]) {
        if (item.startsWith('tracker:')) {
          magnet += '&tr=${Uri.encodeComponent(item.substring(8))}';
        }
      }
    }

    final useDebrid = await DebridService().isDebridActiveForStreams();
    if (useDebrid) {
      final service = await DebridService().getSelectedService();
      if (mounted) setState(() => _status = 'Resolving with $service…');
      final files = await DebridService().resolveMagnet(
        magnet: magnet,
        fileIndex: source.fileIdx,
        filename: widget.title,
        season: _episode?.season,
        episode: _episode?.episode,
        episodeTitle: _episode?.title,
      );
      if (files.isEmpty || files.first.downloadUrl.isEmpty) return null;
      return files.first.downloadUrl;
    }

    if (mounted) setState(() => _status = 'Connecting to torrent stream…');
    return TorrentStreamService().streamTorrent(
      magnet,
      season: _episode?.season,
      episode: _episode?.episode,
      episodeTitle: _episode?.title,
      fileIdx: source.fileIdx,
    );
  }

  List<BetterPlayerSubtitlesSource> _subtitleSources(StreamSource source) {
    final all = <SubtitleVariant>[
      ...?widget.initialSubtitles,
      ...?source.subtitles,
    ];
    final seen = <String>{};
    return all
        .where((subtitle) => seen.add(subtitle.downloadUrl.toLowerCase()))
        .map(
          (subtitle) => BetterPlayerSubtitlesSource(
            type: BetterPlayerSubtitlesSourceType.network,
            name: subtitle.title.isNotEmpty
                ? subtitle.title
                : subtitle.language,
            urls: [subtitle.downloadUrl],
            headers: subtitle.extraData['headers'] is Map
                ? Map<String, String>.from(subtitle.extraData['headers'] as Map)
                : null,
          ),
        )
        .toList();
  }

  String? _subtitleImdbId() {
    final candidates = <String>[
      widget.detail?.id ?? '',
      _episode?.id ?? '',
      widget.title,
      for (final link in widget.detail?.links ?? const []) ...[
        link.url,
        link.name,
      ],
    ];
    final pattern = RegExp(r'\btt\d{7,8}\b', caseSensitive: false);
    for (final candidate in candidates) {
      final match = pattern.firstMatch(candidate);
      if (match != null) return match.group(0)?.toLowerCase();
    }
    return null;
  }

  // ── Subtitles (web player: language groups with counters + delay) ─────

  /// Anime comes from its own sources (AniList / Arabic anime) and brings its
  /// own subtitles, so the movies/series subtitle API must not be used for it.
  bool get _isAnime {
    final d = widget.detail;
    final epId = (_episode?.id ?? widget.episode?.id ?? '').toLowerCase();
    if (epId.startsWith('anilist:') || epId.startsWith('arabic_anime:')) {
      return true;
    }
    if (d == null) return false;
    final type = d.type.toLowerCase();
    final id = d.id.toLowerCase();
    return type == 'anime' ||
        id.startsWith('anilist:') ||
        id.startsWith('arabic_anime:');
  }

  Future<List<SubtitleLanguageGroup>> _loadSubtitleGroups() {
    return _subtitleFuture ??= () async {
      final variants = <SubtitleVariant>[
        ...?widget.initialSubtitles,
        ...?_currentSource?.subtitles,
      ];
      final detailTitle = widget.detail?.name.trim() ?? '';
      final searchTitle = detailTitle.isNotEmpty ? detailTitle : widget.title;
      final yearMatch = RegExp(
        r'\b(?:19|20)\d{2}\b',
      ).firstMatch(widget.detail?.year ?? '');
      final year = yearMatch == null ? null : int.tryParse(yearMatch.group(0)!);
      if (_isAnime) {
        // Only the subtitles that the anime source itself provides.
        return SubtitleService.groupVariantsByLanguage(variants);
      }
      try {
        final groups = await SubtitleService()
            .fetchAllSubtitles(
              searchTitle,
              imdbId: _subtitleImdbId(),
              season: _episode?.season,
              episode: _episode?.episode,
              year: year,
              tmdbId: widget.detail?.tmdbId,
              mediaType: widget.detail?.type,
            )
            .timeout(const Duration(seconds: 18));
        for (final g in groups) {
          variants.addAll(g.variants);
        }
      } catch (error) {
        debugPrint('[PlayerScreen] subtitle search failed: $error');
      }
      return SubtitleService.groupVariantsByLanguage(variants);
    }();
  }

  Future<void> _applySubtitleVariant(SubtitleVariant variant) async {
    final player = _controller;
    if (player == null) {
      _showSubtitleMessage('The player is not ready yet.');
      return;
    }
    try {
      _showSubtitleMessage(
        'Loading ${variant.language} subtitles from ${variant.providerName}…',
      );
      final path = await SubtitleService().downloadSubtitle(variant);
      if (path == null || path.isEmpty || !File(path).existsSync()) {
        throw StateError('The subtitle server did not return a readable file.');
      }
      final raw = SubtitleParser.decodeBytesWithFallback(
        await File(path).readAsBytes(),
      );
      final parsed = SubtitleParser.parse(raw);
      if (parsed.cues.isEmpty) {
        throw StateError('The subtitle file contains no captions.');
      }
      if (!mounted || !identical(player, _controller)) return;
      _baseCues = parsed.cues;
      _subLabel = '${variant.language} · ${variant.providerName}';
      await _pushSubtitles();
      if (mounted) _showSubtitleMessage('Loaded ${variant.language} subtitles.');
    } catch (error) {
      if (mounted) _showSubtitleMessage('Could not load subtitles: $error');
    }
  }

  /// Writes the cues (shifted by the current delay) to a temp SRT and loads it.
  Future<void> _pushSubtitles() async {
    final player = _controller;
    final base = _baseCues;
    if (player == null || base == null) return;
    final cues = _subDelay == 0
        ? base
        : SubtitleSyncHelper.applyLinearSync(
            cues: base,
            points: const [],
            nudge: _subDelay,
          );
    _shownCues = cues;

    // Default: our own overlay draws the captions (full styling).
    // "Native video subtitles" ON: hand them to the platform player instead.
    if (!WebSubStyle.nativeSubs.value) {
      if (_nativeSubActive) {
        _nativeSubActive = false;
        await player.setupSubtitleSource(
          BetterPlayerSubtitlesSource(type: BetterPlayerSubtitlesSourceType.none),
          sourceInitialize: true,
        );
      }
      if (mounted) setState(() {});
      return;
    }

    final file = File(
      '${Directory.systemTemp.path}/pt_sub_${DateTime.now().millisecondsSinceEpoch}_${_subFileCounter++}.srt',
    );
    await file.writeAsString(SubtitleParser.toSrt(cues));
    await player.setupSubtitleSource(
      BetterPlayerSubtitlesSource(
        type: BetterPlayerSubtitlesSourceType.file,
        name: _subLabel ?? 'Subtitles',
        urls: [file.path],
        selectedByDefault: true,
      ),
      sourceInitialize: true,
    );
    _nativeSubActive = true;
    if (mounted) setState(() {});
  }

  void _onNativeSubsToggled() {
    if (_baseCues != null) unawaited(_pushSubtitles());
  }

  void _setSubtitleDelay(double seconds) {
    _subDelay = seconds;
    _delayTimer?.cancel();
    if (_baseCues == null) return;
    _delayTimer = Timer(
      const Duration(milliseconds: 450),
      () => unawaited(_pushSubtitles()),
    );
  }

  Future<void> _subtitlesOff() async {
    final player = _controller;
    _baseCues = null;
    _shownCues = null;
    _nativeSubActive = false;
    _subLabel = null;
    if (player == null) return;
    await player.setupSubtitleSource(
      BetterPlayerSubtitlesSource(type: BetterPlayerSubtitlesSourceType.none),
      sourceInitialize: true,
    );
    if (mounted) setState(() {});
  }

  /// Same idea as _autoSelectArabic() in the web player.
  Future<void> _autoSelectArabicSubtitle() async {
    final groups = await _loadSubtitleGroups();
    for (final g in groups) {
      final l = g.language.toLowerCase();
      if (l.contains('arab') || l.contains('عرب') || l == 'ar') {
        if (g.variants.isNotEmpty) {
          await _applySubtitleVariant(g.variants.first);
          return;
        }
      }
    }
    if (mounted) _showSubtitleMessage('No Arabic subtitles were found.');
  }

  // ── Download (saves the playing server with the app downloader) ──────

  Future<void> _saveCurrentToApp() async {
    final source = _currentSource;
    if (source == null) return;
    try {
      final detail = widget.detail;
      final ep = _episode;
      await DownloadService.instance.startDownload(
        title: (detail?.name.isNotEmpty ?? false) ? detail!.name : widget.title,
        mediaId: detail?.id ?? widget.title,
        type: ep != null ? 'series' : 'movie',
        season: ep?.season,
        episode: ep?.episode,
        episodeTitle: ep?.title,
        backdropUrl: widget.backdropUrl,
        year: detail?.year,
        source: source,
      );
      _showSubtitleMessage('Download started — see the Downloads page.');
    } catch (error) {
      _showSubtitleMessage('Could not start the download: $error');
    }
  }

  String? _episodeBadge() {
    final ep = _episode;
    if (ep?.season != null && ep?.episode != null) {
      return 'S${ep!.season}E${ep.episode}';
    }
    return null;
  }

  void _handleBack() {
    _leaving = true;
    final c = _controller;
    if (c != null && c.isFullScreen) {
      c.exitFullScreen();
      Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (mounted) Navigator.of(context).maybePop();
      });
      return;
    }
    Navigator.of(context).maybePop();
  }

  void _showSubtitleMessage(String message) {
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  Future<void> _openCurrentSource() async {
    final source = _currentSource;
    if (!mounted || source == null) return;
    final generation = ++_openGeneration;
    _baseCues = null;
    _shownCues = null;
    _nativeSubActive = false;
    _subLabel = null;
    setState(() {
      _isLoading = true;
      _hasFatalError = false;
      _error = null;
      _status = 'Opening ${source.displayTitle}…';
    });

    try {
      final url = await _resolveUrl(source);
      if (!mounted || generation != _openGeneration) return;
      if (url == null || url.isEmpty) {
        throw StateError('The source did not return a playable URL.');
      }

      final isLocal = File(url).existsSync();
      final headers = isLocal
          ? null
          : PlayerSettings.resolveStreamHeaders(url, source.headers);
      final proxyHeaders = source.behaviorHints?['proxyHeaders']?['request'];
      if (proxyHeaders is Map && headers != null) {
        headers.addAll(Map<String, String>.from(proxyHeaders));
      }

      final live =
          source.behaviorHints?['isLive'] == true ||
          url.toLowerCase().contains('/live/') ||
          url.toLowerCase().contains('/hls/live');
      final subtitles = _subtitleSources(source);
      final dataSource = isLocal
          ? BetterPlayerDataSource.file(url, subtitles: subtitles)
          : BetterPlayerDataSource.network(
              url,
              headers: headers,
              subtitles: subtitles,
              liveStream: live,
              useAsmsTracks: true,
              useAsmsAudioTracks: true,
              useAsmsSubtitles: true,
            );

      _controller?.dispose();
      final controller = BetterPlayerController(
        BetterPlayerConfiguration(
          autoPlay: true,
          startAt: widget.initialPosition,
          fullScreenByDefault: true,
          allowedScreenSleep: false,
          fit: BoxFit.contain,
          handleLifecycle: true,
          enableAmbientGlow: true,
          errorBuilder: (context, message) => _buildPlayerError(message),
          controlsConfiguration: BetterPlayerControlsConfiguration(
            enableFullscreen: true,
            enableMute: true,
            enableSkips: true,
            enableAudioTracks: true,
            enablePlaybackSpeed: true,
            enableSubtitles: true,
            showSubtitlesButton: true,
            enableQualities: true,
            showQualitiesButton: true,
            enableRetry: true,
            enableThumbnailPreview: true,
            name: 'PlayTorrio · ${_sourceProvider(source)}',
            subtitle: '${_serverLabel(source)} · ${_protocolLabel(source)}',
            playerTheme: BetterPlayerTheme.custom,
            customControlsBuilder: (controller, onVisibilityChanged) =>
                WebStyleControls(
                  controller: controller,
                  onVisibilityChanged: onVisibilityChanged,
                  title: widget.title,
                  episodeBadge: _episodeBadge(),
                  onBack: _handleBack,
                  sourcesRefresh: _sourcesRefresh,
                  getSources: () => _availableSources,
                  getCurrentSource: () => _currentSource,
                  isDiscovering: () => _isDiscovering,
                  providerOf: _sourceProvider,
                  labelOf: _serverLabel,
                  isTorrent: _isTorrentSource,
                  onSelectSource: (s) => unawaited(_selectSource(s)),
                  loadSubtitles: _loadSubtitleGroups,
                  onPickSubtitle: (v) => unawaited(_applySubtitleVariant(v)),
                  onSubtitleOff: () => unawaited(_subtitlesOff()),
                  onAutoSubtitle: () => unawaited(_autoSelectArabicSubtitle()),
                  onSubtitleDelay: _setSubtitleDelay,
                  getSubtitleCues: () => _shownCues,
                  activeSubtitleLabel: () => _subLabel,
                  mediaId: widget.detail?.tmdbId ?? widget.detail?.id ?? '',
                  downloadMediaId: widget.detail?.id ?? widget.title,
                  episodes: _episode == null
                      ? const <Video>[]
                      : (widget.detail?.videos ?? const <Video>[]),
                  currentEpisode: _episode,
                  onSelectEpisode: (v) => unawaited(_switchEpisode(v)),
                  party: _party,
                  mediaType: _episode != null ? 'tv' : 'movie',
                  currentVideoUrl: () => _currentSource?.url ?? '',
                  season: _episode?.season,
                  episode: _episode?.episode,
                  onSaveCurrent: () => unawaited(_saveCurrentToApp()),
                ),
            forwardSkipTimeInMilliseconds: 10000,
            backwardSkipTimeInMilliseconds: 10000,
            controlBarColor: Color(0xD9000000),
            progressBarPlayedColor: Color(0xFFE50914),
            progressBarHandleColor: Color(0xFFE50914),
            gestureConfiguration: BetterPlayerGestureConfiguration(
              enableVolumeSwipe: true,
              enableBrightnessSwipe: true,
              enableSeekSwipe: true,
            ),
          ),
          eventListener: _onPlayerEvent,
        ),
        betterPlayerDataSource: dataSource,
      );
      _controller = controller;
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _status = '';
      });
    } catch (error) {
      await _handleFailure(error.toString());
    }
  }

  Future<void> _handleFailure(String message) async {
    if (!mounted) return;
    _hasFatalError = true;
    if (await _tryNextSource(reason: message)) return;
    setState(() {
      _isLoading = false;
      _error = message;
      _status = 'Unable to play this source.';
    });
  }

  Future<bool> _tryNextSource({required String reason}) async {
    if (_isRetrying || !mounted) return false;
    final queue = _availableSources;
    StreamSource? next;
    for (final candidate in queue) {
      if (candidate.isFailed) continue;
      if (!_attemptedSources.contains(_sourceKey(candidate))) {
        next = candidate;
        _attemptedSources.add(_sourceKey(candidate));
        break;
      }
    }
    if (next == null) return false;
    _isRetrying = true;
    _controller?.dispose();
    _controller = null;
    setState(() {
      _currentSource = next!;
      _isLoading = true;
      _error = null;
      _status = 'Trying another available source…';
    });
    debugPrint('[PlayerScreen] BetterPlayer fallback: $reason');
    try {
      await _openCurrentSource();
      return true;
    } finally {
      _isRetrying = false;
    }
  }

  void _onPlayerEvent(BetterPlayerEvent event) {
    if (!mounted) return;
    final type = event.betterPlayerEventType;
    if (_party.isHost && !_party.applying) {
      final vp = _controller?.videoPlayerController;
      final pos = (vp?.value.position.inMilliseconds ?? 0) / 1000.0;
      if (type == BetterPlayerEventType.play) {
        unawaited(_party.sendAction('play', position: pos, playing: true));
      } else if (type == BetterPlayerEventType.pause) {
        unawaited(_party.sendAction('pause', position: pos, playing: false));
      } else if (type == BetterPlayerEventType.seekTo) {
        unawaited(
          _party.sendAction(
            'seek',
            position: pos,
            playing: vp?.value.isPlaying ?? false,
          ),
        );
      }
    }
    if (widget.movie != null && !_leaving) {
      if (type == BetterPlayerEventType.hideFullscreen && !_minimized) {
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
        setState(() => _minimized = true);
      } else if (type == BetterPlayerEventType.openFullscreen && _minimized) {
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
        setState(() => _minimized = false);
      }
    }
    if (event.betterPlayerEventType == BetterPlayerEventType.exception) {
      final message =
          event.parameters?['exception']?.toString() ?? 'Player error';
      _handleFailure(message);
    }
  }

  Widget _buildPlayerError(String? message) {
    return ColoredBox(
      color: Colors.black,
      child: Center(
        child: Text(
          message ?? _error ?? 'Unable to play this video',
          style: const TextStyle(color: Colors.white70),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (_minimized && widget.movie != null && !_leaving) {
      return DetailsPage(
        movie: widget.movie!,
        embeddedPlayer: controller != null
            ? BetterPlayer(controller: controller)
            : const ColoredBox(
                color: Colors.black,
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFFE50914)),
                ),
              ),
        onPlayEpisode: (v) => unawaited(_switchEpisode(v)),
      );
    }
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (controller != null)
            BetterPlayer(controller: controller)
          else
            const ColoredBox(color: Colors.black),
          if (_isLoading)
            ColoredBox(
              color: Colors.black.withValues(alpha: 0.78),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(color: Color(0xFFE50914)),
                    const SizedBox(height: 16),
                    Text(
                      _status,
                      style: const TextStyle(color: Colors.white70),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          if (!_isLoading && _error != null && controller == null)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      color: Colors.white70,
                      size: 42,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'All available sources failed',
                      style: Theme.of(
                        context,
                      ).textTheme.titleMedium?.copyWith(color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _error!,
                      style: const TextStyle(color: Colors.white54),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      onPressed:
                          widget.discoverStreams && _currentSource == null
                          ? _startStreamDiscovery
                          : _openCurrentSource,
                      icon: const Icon(Icons.refresh),
                      label: Text(
                        widget.discoverStreams && _currentSource == null
                            ? 'Search servers again'
                            : 'Retry',
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    widget.fallbackSources?.removeListener(_onFallbackQueueChanged);
    _discoveredSources.removeListener(_onFallbackQueueChanged);
    WebSubStyle.nativeSubs.removeListener(_onNativeSubsToggled);
    _delayTimer?.cancel();
    _discoverySubscription?.cancel();
    if (widget.discoverStreams || _episodeSwitched) {
      StreamService.stopAllScrapers();
    }
    _party.dispose();
    _discoveredSources.dispose();
    _controller?.dispose();
    WakelockPlus.disable();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}
