import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';

import '../../services/player/web_sub_style.dart';
import '../../services/subtitles/subtitle_parser.dart';

/// Draws the current caption on top of the video using [WebSubStyle], so every
/// option in "Customize Subtitles" (color, background, blur, transparency,
/// shadow, position, size, bold, capitalization…) applies live.
class WebSubtitleOverlay extends StatefulWidget {
  /// Cues with the subtitle delay already applied (seconds).
  final List<SubCue>? Function() getCues;
  final Duration Function() getPosition;

  const WebSubtitleOverlay({
    super.key,
    required this.getCues,
    required this.getPosition,
  });

  @override
  State<WebSubtitleOverlay> createState() => _WebSubtitleOverlayState();
}

class _WebSubtitleOverlayState extends State<WebSubtitleOverlay> {
  Timer? _timer;
  String _text = '';

  @override
  void initState() {
    super.initState();
    WebSubStyle.load();
    WebSubStyle.changed.addListener(_rebuild);
    WebSubStyle.nativeSubs.addListener(_rebuild);
    _timer = Timer.periodic(const Duration(milliseconds: 120), (_) => _poll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    WebSubStyle.changed.removeListener(_rebuild);
    WebSubStyle.nativeSubs.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() {
    if (mounted) setState(() {});
  }

  void _poll() {
    if (!mounted) return;
    String next = '';
    final cues = widget.getCues();
    if (cues != null && !WebSubStyle.nativeSubs.value) {
      final t = widget.getPosition().inMilliseconds / 1000.0;
      final active = <String>[];
      for (final c in cues) {
        if (t >= c.start && t <= c.end) active.add(c.text);
      }
      next = active.join('\n');
    }
    if (next != _text) setState(() => _text = next);
  }

  @override
  Widget build(BuildContext context) {
    if (_text.isEmpty || WebSubStyle.nativeSubs.value) {
      return const SizedBox.shrink();
    }
    var text = WebSubStyle.clean(_text);
    if (text.isEmpty) return const SizedBox.shrink();
    if (WebSubStyle.fixCaps.value) text = WebSubStyle.fixCapitalization(text);

    final size = MediaQuery.sizeOf(context);
    final base = (size.shortestSide * 0.05).clamp(14.0, 30.0);
    final fontSize = base * WebSubStyle.textScale.value;
    final bg = Color(WebSubStyle.bgColor.value)
        .withValues(alpha: WebSubStyle.bgOpacity.value * WebSubStyle.overall.value);
    final hasBg = WebSubStyle.bgOpacity.value > 0.01;
    final blur = WebSubStyle.bgBlur.value && hasBg
        ? 10.0 * WebSubStyle.blurIntensity.value
        : 0.0;

    final label = Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Color(WebSubStyle.color.value),
        fontSize: fontSize,
        height: 1.25,
        fontFamily: WebSubStyle.fontFamily(WebSubStyle.font.value),
        fontWeight: WebSubStyle.bold.value ? FontWeight.w800 : FontWeight.w500,
        shadows: WebSubStyle.shadows(WebSubStyle.shadow.value),
      ),
    );

    Widget box = Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),
      ),
      // Opacity stays inside the blur so the backdrop filter still sees the
      // video behind it.
      child: Opacity(opacity: WebSubStyle.overall.value, child: label),
    );
    if (blur > 0) {
      box = ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: box,
        ),
      );
    }

    return IgnorePointer(
      child: Align(
        alignment: Alignment(0, WebSubStyle.alignY(WebSubStyle.position.value)),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.08),
          child: box,
        ),
      ),
    );
  }
}
